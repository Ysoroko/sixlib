#include "six_header_h.h"

/**
 * \brief Callback for terminal status changes
 * Contains example code for reading TrackData
 * Will be called when status of terminal changes.
 * \param[in] terminal		Terminal instance
 * \param[in] user_pointer	User-pointer which can be set in the terminal listener
 */
void listener_terminal_status_changed(ta_object_t terminal, void* user_pointer) {
	ta_object_t terminal_status = ta_object_invalid;
	ta_object_t card_data = ta_object_invalid;
	ta_object_t card_track_datas = ta_object_invalid;
	ta_object_t card_track_data = ta_object_invalid;
	ta_object_t data = ta_object_invalid;
	char* strptr = NULL;

	// Get terminal status
	ta_terminal_get_terminal_status(terminal, &terminal_status);
	if (terminal_status != ta_object_invalid) {
		// If card data present...
		ta_terminal_status_get_card_data(terminal_status, &card_data);
		if (card_data != ta_object_invalid) {
			// ...try to read track data
			ta_card_data_get_card_track_datas(card_data, &card_track_datas);
			if (card_track_datas != ta_object_invalid) {
				// only read first track-data entry for demo purposes
				ta_list_get_at(card_track_datas, 0, &card_track_data);
				if (card_track_data != ta_object_invalid) {
					ta_card_track_data_get_data(card_track_data, &data);
					if (data != ta_object_invalid) {
						// print track data
						ta_string_get_pointer(data, (const char **)(& strptr));
						if (strptr != NULL) {
							printf("Track data: %s", strptr);
						}
					}
				}
			}
		}
	}

	// implement your code to process status change here...
	//printf(" > listener_terminal_status_changed\n");
}

/**
* \brief Callback for transaction completed
* Contains example code for printing receipt.
* Will be called, when transaction has finished
* \param[in] event Event instance with further information like error code
* \param[in] transaction_response Transaction response data
* \param[in] user_pointer User-pointer which can be set in the terminal listener
*/
void transaction_completed(const ta_s_event_t* event, ta_object_t transaction_response, void* user_pointer) {
	// Check result code and valid response
	if ((event->result_code == ta_c_rc_ok) && (transaction_response != ta_object_invalid)) {
		printf("TRANSACTION OK\n");
	}
	// Error handling
	else {
		printf("TRANSACTION KO\n");
	}
}