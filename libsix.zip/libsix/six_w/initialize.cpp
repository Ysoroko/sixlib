#include "six_header_h.h"

/**
 * \brief Initializes terminal settings
 *
 * \note  Returned terminal-object needs to be released again by caller!
 * \retval ta_object_t	Initialized Terminal-object
 * 
 * NOTE:
 * Default timeout if card is not inserted when prompted / not removed when prompted / commit timeout: 1 minute
 * Default port used by Six: 7784
 */
ta_object_t initialize_terminal_settings(char *terminal_ip) {
	ta_object_t string = ta_object_invalid;
	ta_object_t settings = ta_object_invalid;
	ta_object_t terminal = ta_object_invalid;
	ta_e_result_code_t rc;

	// create settings
	rc = ta_terminal_settings_create(&settings);

	// set connection mode
	if (rc == ta_c_rc_ok) {
		rc = ta_terminal_settings_set_connection_mode(settings, CONNECTION_MODE);
	}

	// set IP
	if (rc == ta_c_rc_ok) {
		ta_string_format(&string, "%s", terminal_ip);
		rc = ta_terminal_settings_set_connection_ip_string(settings, string);

		ta_object_release(string);
		string = ta_object_invalid;
	}

	// set Guides
	if (rc == ta_c_rc_ok) {
		rc = ta_terminal_settings_set_guides(settings, ACTIVE_GUIDES);
	}

	// create terminal
	if (rc == ta_c_rc_ok) {
		rc = ta_terminal_create(&terminal, settings);
	}

	// return NULL if the terminal wasn't instantiated properly
	if (rc != ta_c_rc_ok) {
		ta_object_release_if_valid(settings);
		return NULL;
	}

	// create and add listeners
	ta_object_t listener = ta_object_invalid;
	if (rc == ta_c_rc_ok) {
		ta_s_terminal_listener_t listener_config;
		memset(&listener_config, 0, sizeof(listener_config)); //memset to 0 is required by the documentation
		listener_config.terminal_status_changed = listener_terminal_status_changed;
		listener_config.transaction_completed = transaction_completed;
		rc = ta_terminal_listener_create(&listener, &listener_config);
		if (rc == ta_c_rc_ok) {
			rc = ta_terminal_add_listener(terminal, listener);
		}
	}
	
	// set POS ID
	if (rc == ta_c_rc_ok) {
		ta_string_format(&string, "%s", "1234");
		rc = ta_terminal_set_pos_id(terminal, string);
		ta_object_release(string);
		string = ta_object_invalid;
	}

	int timeout;

	ta_terminal_settings_get_card_removal_timeout(settings, &timeout);
	printf("CARD REMOVAL TIMEOUT: [%d]\n", timeout);

	ta_terminal_settings_get_commit_timeout(settings, &timeout);
	printf("COMMIT TIMEOUT: [%d]\n", timeout);

	ta_terminal_settings_get_connection_ip_port(settings, &timeout);
	printf("CONNECTION IP PORT [%d]\n", timeout);

	ta_terminal_settings_get_connection_listen_ip_port(settings, &timeout);
	printf("CONNECTION LISTEN IP PORT: [%d]\n", timeout);

	// release settings and listener object
	ta_object_release_if_valid(settings);
	ta_object_release_if_valid(listener);

	return terminal;
}