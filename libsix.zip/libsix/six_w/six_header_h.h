#ifndef SIX_HEADER_H
# define SIX_HEADER_H

#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <string.h>
#include <time.h>
#include <windows.h>

#include "timapi/timapi.h"

#ifndef EXPORT
# define EXPORT __declspec(dllexport)
#endif

/**
 * Connection mode:
 *  - ta_c_cm_broadcast : find terminal by listening for its broadcast signal by using its Terminal ID
 *  - ta_c_cm_on_fix_ip : connect to terminal on fix ip
 */
# define CONNECTION_MODE	ta_c_cm_on_fix_ip

# define TERMINAL_ID "31390674"
# define POS_ID "123456"
# define DEFAULT_CURRENCY_NAME "EUR"
# define DEFAULT_CURRENCY_TYPE ta_c_currency_eur
# define ACTIVE_GUIDES (ta_c_guide_retail | ta_c_guide_banking | ta_c_guide_advanced_retail)

ta_object_t initialize_terminal_settings(char *terminal_ip);
void transaction_completed(const ta_s_event_t* event, ta_object_t transaction_response, void* user_pointer);
void listener_terminal_status_changed(ta_object_t terminal, void* user_pointer);
ta_e_boolean_t check_trx_status_idle(ta_object_t terminal);
void perform_transaction(ta_object_t terminal, ta_e_transaction_type transaction, ta_object_t amount);

#endif
