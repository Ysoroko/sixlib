#include "six_header_h.h"

ta_object_t t;

// six_perform_payment(ta_object_t terminal, char* amount, unsigned long reference, char *merchant_receipt, char *customer_receipt, char *card, char *error)
ta_e_result_code_t	perform_payment(ta_object_t terminal, char* amount, unsigned long reference, char* merchant_receipt, char* customer_receipt, char* card, char* error)
{
	ta_object_t param = ta_object_invalid;
	long purchase_amount = strtol(amount, NULL, 10);
	ta_e_result_code_t rc;
	ta_object_t transaction_response = ta_object_invalid;

	ta_amount_create(&param, purchase_amount, DEFAULT_CURRENCY_TYPE);

	// send transaction to terminal
	// ta_c_tt_purchase
	// rc = ta_terminal_transaction(terminal, ta_c_tt_credit, param, &transaction_response);
	rc = ta_terminal_transaction_async(terminal, ta_c_tt_credit, param);
	// wait for terminal to get back to the idle state. calling logout will fail
	// if the terminal is not ready yet
	if (rc == ta_c_rc_ok) {
		while (check_trx_status_idle(terminal) == ta_c_b_false) {
			Sleep(100);
		}
	}

	// --------------- GET CARD DATA [OK] -----------------
	ta_object_t card_data = ta_object_invalid;
	// Card data is not retained, no need to release
	rc = ta_transaction_response_get_card_data(transaction_response, &card_data);

	ta_object_t card_number = ta_object_invalid;
	rc = ta_card_data_get_card_number_printable(card_data, &card_number);

	// get a pointer to the string so we can save it in a format like 'XXXXXXXXXXXXX1017'
	const char* str_ptr = NULL;
	rc = ta_string_get_pointer(card_number, &str_ptr);
	strcpy(card, str_ptr);
	// Card number is not retained, no need to release


	// ---------------- GET RECEIPTS ----------------------
	ta_object_t print_data = ta_object_invalid;
	rc = ta_transaction_response_get_print_data(transaction_response, &print_data);

	// Get receipt list
	ta_object_t receipt_list = ta_object_invalid;
	ta_print_data_get_receipts(print_data, &receipt_list);

	// Get list length
	size_t receipt_count = 0;
	ta_list_get_count(receipt_list, &receipt_count);

	// Loop receipt list
	int i;
	for (i = 0; i < receipt_count; i++) {
		// Get receipt
		ta_object_t receipt = ta_object_invalid;
		ta_list_get_at(receipt_list, i, &receipt);
		if (receipt != ta_object_invalid) {

			// Get receipt-string
			ta_object_t receipt_string = ta_object_invalid;
			ta_receipt_get_value(receipt, &receipt_string);

			// Get string-pointer
			// const char* str_ptr = NULL;
			// ta_string_get_pointer(receipt_string, &str_ptr);
			// printf("RECEIPT: %s\n", str_ptr);

			// Get recipient and print receipt
			ta_e_recipient_t recipient;
			ta_receipt_get_recipient(receipt, &recipient);
			switch (recipient) {
			case ta_c_rcp_merchant:
				ta_string_get_pointer(receipt_string, &str_ptr);
				strcpy(merchant_receipt, str_ptr);
				break;
			case ta_c_rcp_cardholder:
				ta_string_get_pointer(receipt_string, &str_ptr);
				strcpy(customer_receipt, str_ptr);
				break;
			case ta_c_rcp_both:
				ta_string_get_pointer(receipt_string, &str_ptr);
				strcpy(merchant_receipt, str_ptr);
				ta_string_get_pointer(receipt_string, &str_ptr);
				strcpy(customer_receipt, str_ptr);
				break;
			}
		}
	}


	// clean up
	ta_object_release_if_valid(transaction_response);

	// wait at end for user input
	if (rc == ta_c_rc_ok) {
		printf("Finished successfully...\n");
	}
	else {
		printf("Finished with errors...\n");
	}

	return rc;
}

extern "C" {
	EXPORT ta_object_t six_initialize_terminal_settings(char* terminal_ip) {
		// return 1 if terminal was found, 0 otherwise
		t = initialize_terminal_settings(terminal_ip);
		return t;
	}

	EXPORT ta_e_result_code_t six_cancel_transaction(ta_object_t terminal) {
		return ta_terminal_cancel(terminal);
	}

	EXPORT int six_perform_payment(ta_object_t terminal, char* amount, unsigned long reference, char *merchant_receipt, char *customer_receipt, char *card, char *error) {
		return perform_payment(terminal, amount, reference, merchant_receipt, customer_receipt, card, error);
	}

}ma
