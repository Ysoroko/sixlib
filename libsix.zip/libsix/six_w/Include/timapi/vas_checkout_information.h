/**
 * \file
 * \brief Contains VAS checkout information.
 * \details Object type \em vas_checkout_information.
 */

#ifndef TA_VAS_CHECKOUT_INFORMATION_H
#define TA_VAS_CHECKOUT_INFORMATION_H

#include "common/object.h"
#include "common/boolean.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief List of loyalty coupons.
 * 
 * \param[in] vas_checkout_information Object instance of type [vas_checkout_information](\ref vas_checkout_information.h).
 * \param[out] loyalty_coupons Pointer to variable to write object instance to. Object instance
 *                             is of type [list](\ref list.h) and is not retained. The list contains elements
 *                             of type [loyalty_coupon](\ref loyalty_coupon.h). If list is not
 *                             present \em ta_object_invalid is written.
 * 
 * \retval ta_c_rc_ok Object instance written to \em loyalty_coupons.
 * \retval ta_c_rc_invalid_argument \em vas_checkout_information is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em vas_checkout_information is not of type
 *                                  [vas_checkout_information](\ref vas_checkout_information.h).
 * \retval ta_c_rc_invalid_argument \em loyalty_coupons is \em null-pointer.
 */
extern ta_e_result_code_t ta_vas_checkout_information_get_loyalty_coupons(
	ta_object_t vas_checkout_information,
	ta_object_t* loyalty_coupons );

/**
 * \brief List of loyalty information.
 * 
 * \param[in] vas_checkout_information Object instance of type [vas_checkout_information](\ref vas_checkout_information.h).
 * \param[out] loyalty_information Pointer to variable to write object instance to. Object instance
 *                             is of type [list](\ref list.h) and is not retained. The list contains elements
 *                             of type [loyalty_information](\ref loyalty_information.h). If list is not
 *                             present \em ta_object_invalid is written.
 * 
 * \retval ta_c_rc_ok Object instance written to \em loyalty_information.
 * \retval ta_c_rc_invalid_argument \em vas_checkout_information is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em vas_checkout_information is not of type
 *                                  [vas_checkout_information](\ref vas_checkout_information.h).
 * \retval ta_c_rc_invalid_argument \em loyalty_information is \em null-pointer.
 */
extern ta_e_result_code_t ta_vas_checkout_information_get_loyalty_information(
	ta_object_t vas_checkout_information,
	ta_object_t* loyalty_information );

/**
 * \brief List of VAS information lists.
 * 
 * \param[in] vas_checkout_information Object instance of type [vas_checkout_information](\ref vas_checkout_information.h).
 * \param[out] vas_information_list Pointer to variable to write object instance to. Object instance
 *                                  is of type [list](\ref list.h) and is not retained. The map contains
 *                                  entries of type [vas_information_list](\ref vas_information_list.h).
 *                                  If list is not present \em ta_object_invalid is written.
 * 
 * \retval ta_c_rc_ok Object instance written to \em vas_information_lists.
 * \retval ta_c_rc_invalid_argument \em vas_checkout_information is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em vas_checkout_information is not of type
 *                                  [vas_checkout_information](\ref vas_checkout_information.h).
 * \retval ta_c_rc_invalid_argument \em vas_information_list is \em null-pointer.
 */
extern ta_e_result_code_t ta_vas_checkout_information_get_vas_information_list(
	ta_object_t vas_checkout_information,
	ta_object_t* vas_information_list );

/**
 * \brief Indicates if a basket has to be provided.
 * 
 * \param[in] vas_checkout_information Object instance of type [vas_checkout_information](\ref vas_checkout_information.h).
 * \param[out] provide_basket Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em dcc_flag.
 * \retval ta_c_rc_invalid_argument \em vas_checkout_information is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em vas_checkout_information is not of type [vas_checkout_information](\ref vas_checkout_information.h).
 * \retval ta_c_rc_invalid_argument \em provide_basket is \em null-pointer.
 */
extern ta_e_result_code_t ta_vas_checkout_information_get_provide_basket(
	ta_object_t vas_checkout_information,
	ta_e_boolean_t* provide_basket );

#ifdef __cplusplus
}
#endif

#endif
