/**
 * \file
 * \brief Ecr info.
 * \details Object type \em ecr_info.
 */

#ifndef TA_ECR_INFO_H
#define TA_ECR_INFO_H

#include "common/object.h"
#include "common/boolean.h"
#include "constants/ecr_info_type.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create object of type [ecr_info](\ref ecr_info.h).
 * 
 * \param[out] ecr_info Pointer to variable to write created object instance to.
 *                    Created object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em ecr_info.
 * \retval ta_c_rc_invalid_argument \em ecr_info is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_ecr_info_create(
	ta_object_t *ecr_info );



/**
 * \brief Information type.
 * 
 * \param[in] ecr_info Object instance of type [ecr_info](\ref ecr_info.h).
 * \param[out] type Pointer to variable to write value to. Value is \em ta_c_eit_undefined
 *                  if value is not set in \em ecr_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em type.
 * \retval ta_c_rc_invalid_argument \em ecr_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em ecr_info is not of type [ecr_info](\ref ecr_info.h).
 * \retval ta_c_rc_invalid_argument \em type is \em null-pointer.
 */
extern ta_e_result_code_t ta_ecr_info_get_type(
	ta_object_t ecr_info,
	ta_e_ecr_info_type_t *type );

/**
 * \brief Set information type.
 * 
 * \param[in] ecr_info Object instance of type [ecr_info](\ref ecr_info.h).
 * \param[in] type Value to set. Value can be \em ta_c_eit_undefined to clear the value
 *                 in \em ecr_info.
 * 
 * \retval ta_c_rc_ok Value assigned to \em ecr_info.
 * \retval ta_c_rc_invalid_argument \em ecr_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em ecr_info is not of type [ecr_info](\ref ecr_info.h).
 */
extern ta_e_result_code_t ta_ecr_info_set_type(
	ta_object_t ecr_info,
	ta_e_ecr_info_type_t type );



/**
 * \brief Information name.
 * 
 * \param[in] ecr_info Object instance of type [ecr_info](\ref ecr_info.h).
 * \param[out] name Pointer to variable to write object instance to. Object instance is of
 *                  type \em string and is not retained. Object instance is
 *                  \em ta_object_invalid if value is not set in \em ecr_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em name.
 * \retval ta_c_rc_invalid_argument \em ecr_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em ecr_info is not of type [ecr_info](\ref ecr_info.h).
 * \retval ta_c_rc_invalid_argument \em name is \em null-pointer.
 */
extern ta_e_result_code_t ta_ecr_info_get_name(
	ta_object_t ecr_info,
	ta_object_t* name );

/**
 * \brief Set information name.
 * 
 * \param[in] ecr_info Object instance of type [ecr_info](\ref ecr_info.h).
 * \param[in] name Object instance to set. Object instance can be \em ta_object_invalid to
 *                 clear the value in \em ecr_info. If object instance is not ta_object_invalid
 *                 is has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em ecr_info.
 * \retval ta_c_rc_invalid_argument \em ecr_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em ecr_info is not of type [ecr_info](\ref ecr_info.h).
 * \retval ta_c_rc_invalid_argument \em name is not \em ta_object_invalid and is not of
 *                                  type \em string.
 */
extern ta_e_result_code_t ta_ecr_info_set_name(
	ta_object_t ecr_info,
	ta_object_t name );



/**
 * \brief Information manufacturer name.
 * 
 * \param[in] ecr_info Object instance of type [ecr_info](\ref ecr_info.h).
 * \param[out] manufacturer_name Pointer to variable to write object instance to. Object
 *                               instance is of type [string](\ref string.h) and is not retained. Object
 *                               instance is \em ta_object_invalid if value is not set
 *                               in \em ecr_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em manufacturer_name.
 * \retval ta_c_rc_invalid_argument \em ecr_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em ecr_info is not of type [ecr_info](\ref ecr_info.h).
 * \retval ta_c_rc_invalid_argument \em manufacturer_name is \em null-pointer.
 */
extern ta_e_result_code_t ta_ecr_info_get_manufacturer_name(
	ta_object_t ecr_info,
	ta_object_t* manufacturer_name );

/**
 * \brief Set information manufacturer name.
 * 
 * \param[in] ecr_info Object instance of type [ecr_info](\ref ecr_info.h).
 * \param[in] manufacturer_name Object instance to set. Object instance can be
 *                              \em ta_object_invalid to clear the value in \em ecr_info. If
 *                              object instance is not ta_object_invalid is has to be of type
 *                              \em string.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em ecr_info.
 * \retval ta_c_rc_invalid_argument \em ecr_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em ecr_info is not of type [ecr_info](\ref ecr_info.h).
 * \retval ta_c_rc_invalid_argument \em manufacturer_name is not \em ta_object_invalid and is not of
 *                                  type \em string.
 */
extern ta_e_result_code_t ta_ecr_info_set_manufacturer_name(
	ta_object_t ecr_info,
	ta_object_t manufacturer_name );



/**
 * \brief Information version.
 * 
 * \param[in] ecr_info Object instance of type [ecr_info](\ref ecr_info.h).
 * \param[out] version Pointer to variable to write object instance to. Object
 *                     instance is of type [string](\ref string.h) and is not retained. Object
 *                     instance is \em ta_object_invalid if value is not set
 *                     in \em ecr_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em version.
 * \retval ta_c_rc_invalid_argument \em ecr_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em ecr_info is not of type [ecr_info](\ref ecr_info.h).
 * \retval ta_c_rc_invalid_argument \em version is \em null-pointer.
 */
extern ta_e_result_code_t ta_ecr_info_get_version(
	ta_object_t ecr_info,
	ta_object_t* version );

/**
 * \brief Set information version.
 * 
 * \param[in] ecr_info Object instance of type [ecr_info](\ref ecr_info.h).
 * \param[in] version Object instance to set. Object instance can be
 *                    \em ta_object_invalid to clear the value in \em ecr_info. If
 *                    object instance is not ta_object_invalid is has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em ecr_info.
 * \retval ta_c_rc_invalid_argument \em ecr_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em ecr_info is not of type [ecr_info](\ref ecr_info.h).
 * \retval ta_c_rc_invalid_argument \em version is not \em ta_object_invalid and is not of
 *                                  type \em string.
 */
extern ta_e_result_code_t ta_ecr_info_set_version(
	ta_object_t ecr_info,
	ta_object_t version );



/**
 * \brief Information serial number.
 * 
 * \param[in] ecr_info Object instance of type [ecr_info](\ref ecr_info.h).
 * \param[out] serial_number Pointer to variable to write object instance to. Object
 *                           instance is of type [string](\ref string.h) and is not retained. Object
 *                           instance is \em ta_object_invalid if value is not set
 *                           in \em ecr_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em serial_number.
 * \retval ta_c_rc_invalid_argument \em ecr_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em ecr_info is not of type [ecr_info](\ref ecr_info.h).
 * \retval ta_c_rc_invalid_argument \em serial_number is \em null-pointer.
 */
extern ta_e_result_code_t ta_ecr_info_get_serial_number(
	ta_object_t ecr_info,
	ta_object_t* serial_number );

/**
 * \brief Set information serial number.
 * 
 * \param[in] ecr_info Object instance of type [ecr_info](\ref ecr_info.h).
 * \param[in] serial_number Object instance to set. Object instance can be
 *                          \em ta_object_invalid to clear the value in \em ecr_info. If
 *                          object instance is not ta_object_invalid is has to be of type
 *                          \em string.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em ecr_info.
 * \retval ta_c_rc_invalid_argument \em ecr_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em ecr_info is not of type [ecr_info](\ref ecr_info.h).
 * \retval ta_c_rc_invalid_argument \em serial_number is not \em ta_object_invalid and is not
 *                                  of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_ecr_info_set_serial_number(
	ta_object_t ecr_info,
	ta_object_t serial_number );



/**
 * \brief Information architecture.
 * 
 * \param[in] ecr_info Object instance of type [ecr_info](\ref ecr_info.h).
 * \param[out] architecture Pointer to variable to write object instance to. Object
 *                          instance is of type [string](\ref string.h) and is not retained. Object
 *                          instance is \em ta_object_invalid if value is not set
 *                          in \em ecr_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em architecture.
 * \retval ta_c_rc_invalid_argument \em ecr_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em ecr_info is not of type [ecr_info](\ref ecr_info.h).
 * \retval ta_c_rc_invalid_argument \em architecture is \em null-pointer.
 */
extern ta_e_result_code_t ta_ecr_info_get_architecture(
	ta_object_t ecr_info,
	ta_object_t* architecture );

/**
 * \brief Set information architecture.
 * 
 * \param[in] ecr_info Object instance of type [ecr_info](\ref ecr_info.h).
 * \param[in] architecture Object instance to set. Object instance can be
 *                         \em ta_object_invalid to clear the value in \em ecr_info. If
 *                         object instance is not ta_object_invalid is has to be of type
 *                         \em string.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em ecr_info.
 * \retval ta_c_rc_invalid_argument \em ecr_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em ecr_info is not of type [ecr_info](\ref ecr_info.h).
 * \retval ta_c_rc_invalid_argument \em architecture is not \em ta_object_invalid and is not
 *                                  of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_ecr_info_set_architecture(
	ta_object_t ecr_info,
	ta_object_t architecture );



/**
 * \brief Integrator solution.
 * 
 * \param[in] ecr_info Object instance of type [ecr_info](\ref ecr_info.h).
 * \param[out] integrator_solution Pointer to variable to write object instance to. Object
 *                                 instance is of type [string](\ref string.h) and is not retained. Object
 *                                 instance is \em ta_object_invalid if value is not set
 *                                 in \em ecr_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em integrator_solution.
 * \retval ta_c_rc_invalid_argument \em ecr_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em ecr_info is not of type [ecr_info](\ref ecr_info.h).
 * \retval ta_c_rc_invalid_argument \em integrator_solution is \em null-pointer.
 */
extern ta_e_result_code_t ta_ecr_info_get_integrator_solution(
	ta_object_t ecr_info,
	ta_object_t* integrator_solution );

/**
 * \brief Set integrator solution.
 * 
 * \param[in] ecr_info Object instance of type [ecr_info](\ref ecr_info.h).
 * \param[in] integrator_solution Object instance to set. Object instance can be
 *                                \em ta_object_invalid to clear the value in \em ecr_info. If
 *                                object instance is not ta_object_invalid is has to be of type
 *                                \em string.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em ecr_info.
 * \retval ta_c_rc_invalid_argument \em ecr_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em ecr_info is not of type [ecr_info](\ref ecr_info.h).
 * \retval ta_c_rc_invalid_argument \em integrator_solution is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_ecr_info_set_integrator_solution(
	ta_object_t ecr_info,
	ta_object_t integrator_solution );



/**
 * \brief Remote IP.
 * 
 * \param[in] ecr_info Object instance of type [ecr_info](\ref ecr_info.h).
 * \param[out] remote_ip Pointer to variable to write object instance to. Object
 *                       instance is of type [string](\ref string.h) and is not retained. Object
 *                       instance is \em ta_object_invalid if value is not set
 *                       in \em ecr_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em remote_ip.
 * \retval ta_c_rc_invalid_argument \em ecr_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em ecr_info is not of type [ecr_info](\ref ecr_info.h).
 * \retval ta_c_rc_invalid_argument \em remote_ip is \em null-pointer.
 */
extern ta_e_result_code_t ta_ecr_info_get_remote_ip(
	ta_object_t ecr_info,
	ta_object_t* remote_ip );

/**
 * \brief Set remote IP.
 * 
 * \param[in] ecr_info Object instance of type [ecr_info](\ref ecr_info.h).
 * \param[in] remote_ip Object instance to set. Object instance can be
 *                      \em ta_object_invalid to clear the value in \em ecr_info. If
 *                      object instance is not ta_object_invalid is has to be of type
 *                      \em string.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em ecr_info.
 * \retval ta_c_rc_invalid_argument \em ecr_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em ecr_info is not of type [ecr_info](\ref ecr_info.h).
 * \retval ta_c_rc_invalid_argument \em remote_ip is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_ecr_info_set_remote_ip(
	ta_object_t ecr_info,
	ta_object_t remote_ip );


#ifdef __cplusplus
}
#endif

#endif
