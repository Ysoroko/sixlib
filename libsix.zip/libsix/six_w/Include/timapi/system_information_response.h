/**
 * \file
 * \brief Contains the result of calling the ta_terminal_system_information() or
 *        ta_terminal_system_information_async().
 * \details Object type \em system_information_response.
 */

#ifndef TA_SYSTEM_INFORMATION_RESPONSE_H
#define TA_SYSTEM_INFORMATION_RESPONSE_H

#include "common/object.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Network information of EFT terminal.
 * 
 * \param[in] response Object instance of type [system_information_response](\ref system_information_response.h).
 * \param[out] network_information Pointer to variable to write object instance to. Object
 *                                 instance is of type [network_information](\ref network_information.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em network_information.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [system_information_response](\ref system_information_response.h).
 * \retval ta_c_rc_invalid_argument \em network_information is \em null-pointer.
 */
extern ta_e_result_code_t ta_system_information_response_get_network_information(
	ta_object_t response,
	ta_object_t *network_information );


#ifdef __cplusplus
}
#endif

#endif
