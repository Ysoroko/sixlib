/**
 * \file
 * \brief Contains transaction details for counters.
 * \details Object type \em trx_detail.
 */

#ifndef TA_TRX_DETAIL_H
#define TA_TRX_DETAIL_H

#include "common/object.h"
#include "common/boolean.h"
#include "constants/transaction_type.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Specifies is a transaction is a DCC transaction or not.
 * 
 * \param[in] trx_detail Object instance of type [trx_detail](\ref trx_detail.h).
 * \param[out] dcc_flag Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em dcc_flag.
 * \retval ta_c_rc_invalid_argument \em trx_detail is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_detail is not of type [trx_detail](\ref trx_detail.h).
 * \retval ta_c_rc_invalid_argument \em dcc_flag is \em null-pointer.
 */
extern ta_e_result_code_t ta_trx_detail_get_dcc_flag(
	ta_object_t trx_detail,
	ta_e_boolean_t* dcc_flag );

/**
 * \brief Transaction type this details affect.
 * 
 * \param[in] trx_detail Object instance of type [trx_detail](\ref trx_detail.h).
 * \param[out] transaction_type Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em transaction_type.
 * \retval ta_c_rc_invalid_argument \em trx_detail is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_detail is not of type [trx_detail](\ref trx_detail.h).
 * \retval ta_c_rc_invalid_argument \em transaction_type is \em null-pointer.
 */
extern ta_e_result_code_t ta_trx_detail_get_transaction_type(
	ta_object_t trx_detail,
	ta_e_transaction_type_t* transaction_type );

/**
 * \brief Number of transactions covered by the sum.
 * 
 * \param[in] trx_detail Object instance of type [trx_detail](\ref trx_detail.h).
 * \param[out] count Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em count.
 * \retval ta_c_rc_invalid_argument \em trx_detail is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_detail is not of type [trx_detail](\ref trx_detail.h).
 * \retval ta_c_rc_invalid_argument \em count is \em null-pointer.
 */
extern ta_e_result_code_t ta_trx_detail_get_count(
	ta_object_t trx_detail,
	int* count );

/**
 * \brief Total of amount.
 * 
 * \param[in] trx_detail Object instance of type [trx_detail](\ref trx_detail.h).
 * \param[out] amount_sum Pointer to variable to write object instance to. Object
 *                        instance is of type [amount](\ref amount.h) and is not retained. Object
 *                        instance is \em ta_object_invalid if value is not set
 *                        in \em trx_detail.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount_sum.
 * \retval ta_c_rc_invalid_argument \em trx_detail is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_detail is not of type [trx_detail](\ref trx_detail.h).
 * \retval ta_c_rc_invalid_argument \em amount_sum is \em null-pointer.
 */
extern ta_e_result_code_t ta_trx_detail_get_amount_sum(
	ta_object_t trx_detail,
	ta_object_t* amount_sum );

/**
 * \brief Total of tip amount.
 * 
 * \param[in] trx_detail Object instance of type [trx_detail](\ref trx_detail.h).
 * \param[out] amount_sum Pointer to variable to write object instance to. Object
 *                        instance is of type [amount](\ref amount.h) and is not retained. Object
 *                        instance is \em ta_object_invalid if value is not set
 *                        in \em trx_detail.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount_sum.
 * \retval ta_c_rc_invalid_argument \em trx_detail is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_detail is not of type [trx_detail](\ref trx_detail.h).
 * \retval ta_c_rc_invalid_argument \em amount_sum is \em null-pointer.
 */
extern ta_e_result_code_t ta_trx_detail_get_amount_sum_tip(
	ta_object_t trx_detail,
	ta_object_t* amount_sum );

/**
 * \brief Total of other amount.
 * 
 * \param[in] trx_detail Object instance of type [trx_detail](\ref trx_detail.h).
 * \param[out] amount_sum Pointer to variable to write object instance to. Object
 *                        instance is of type [amount](\ref amount.h) and is not retained. Object
 *                        instance is \em ta_object_invalid if value is not set
 *                        in \em trx_detail.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount_sum.
 * \retval ta_c_rc_invalid_argument \em trx_detail is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_detail is not of type [trx_detail](\ref trx_detail.h).
 * \retval ta_c_rc_invalid_argument \em amount_sum is \em null-pointer.
 */
extern ta_e_result_code_t ta_trx_detail_get_amount_sum_other(
	ta_object_t trx_detail,
	ta_object_t* amount_sum );

/**
 * \brief AID.
 * 
 * \param[in] trx_detail Object instance of type [trx_detail](\ref trx_detail.h).
 * \param[out] aid Pointer to variable to write object instance to. Object instance is of type
 *                 [string](\ref string.h) and is not retained. Object instance is
 *                 \em ta_object_invalid if value is not set in \em trx_detail.
 * 
 * \retval ta_c_rc_ok Object instance written to \em aid.
 * \retval ta_c_rc_invalid_argument \em trx_detail is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_detail is not of type [trx_detail](\ref trx_detail.h).
 * \retval ta_c_rc_invalid_argument \em aid is \em null-pointer.
 */
extern ta_e_result_code_t ta_trx_detail_get_aid(
	ta_object_t trx_detail,
	ta_object_t* aid );

/**
 * \brief Markup percentage value.
 * 
 * \param[in] trx_detail Object instance of type [trx_detail](\ref trx_detail.h).
 * \param[out] markup Pointer to variable to write object instance to. Object instance is of type
 *                    [integer](\ref integer.h) and is not retained. Object instance is
 *                    \em ta_object_invalid if value is not set in \em trx_detail.
 * 
 * \retval ta_c_rc_ok Object instance written to \em markup.
 * \retval ta_c_rc_invalid_argument \em trx_detail is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_detail is not of type [trx_detail](\ref trx_detail.h).
 * \retval ta_c_rc_invalid_argument \em markup is \em null-pointer.
 */
extern ta_e_result_code_t ta_trx_detail_get_markup(
	ta_object_t trx_detail,
	ta_object_t* markup );

/**
 * \brief Markup percentage value exponent.
 * 
 * \param[in] trx_detail Object instance of type [trx_detail](\ref trx_detail.h).
 * \param[out] markup_exponent Pointer to variable to write object instance to. Object instance
 *                             is of type [integer](\ref integer.h) and is not retained. Object
 *                             instance is \em ta_object_invalid if value is not set
 *                             in \em trx_detail.
 * 
 * \retval ta_c_rc_ok Object instance written to \em markup_exponent.
 * \retval ta_c_rc_invalid_argument \em trx_detail is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_detail is not of type [trx_detail](\ref trx_detail.h).
 * \retval ta_c_rc_invalid_argument \em markup_exponent is \em null-pointer.
 */
extern ta_e_result_code_t ta_trx_detail_get_markup_exponent(
	ta_object_t trx_detail,
	ta_object_t* markup_exponent );

/**
 * \brief Indicates if a transaction was performed as non guaranteed payment (NGV).
 * 
 * \param[in] trx_detail Object instance of type [trx_detail](\ref trx_detail.h).
 * \param[out] ngvused Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em dcc_flag.
 * \retval ta_c_rc_invalid_argument \em trx_detail is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_detail is not of type [trx_detail](\ref trx_detail.h).
 * \retval ta_c_rc_invalid_argument \em ngvused is \em null-pointer.
 */
extern ta_e_result_code_t ta_trx_detail_get_ngvused_flag(
	ta_object_t trx_detail,
	ta_e_boolean_t* ngvused );

#ifdef __cplusplus
}
#endif

#endif
