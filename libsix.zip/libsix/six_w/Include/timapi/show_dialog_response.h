/**
 * \file
 * \brief Show dialog response.
 * \details Object type \em show_dialog_response.
 */

#ifndef TA_SHOW_DIALOG_RESPONSE_H
#define TA_SHOW_DIALOG_RESPONSE_H

#include "common/object.h"
#include "common/boolean.h"
#include "constants/reason.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Reason for closing dialog.
 * 
 * \param[in] response Object instance of type [show_dialog_response](\ref show_dialog_response.h).
 * \param[out] reason Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em reason.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [show_dialog_response](\ref show_dialog_response.h).
 * \retval ta_c_rc_invalid_argument \em reason is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_dialog_response_get_reason(
	ta_object_t response,
	ta_e_reason_t* reason );

/**
 * \brief User input or ta_object_invalid if absent.
 * 
 * \param[in] response Object instance of type [show_dialog_response](\ref show_dialog_response.h).
 * \param[out] user_input Pointer to variable to write object instance to. Object
 *                        instance is of type [string](\ref string.h) and is not retained. Object
 *                        instance is \em ta_object_invalid if value is not set
 *                        in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em user_input.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [show_dialog_response](\ref show_dialog_response.h).
 * \retval ta_c_rc_invalid_argument \em user_input is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_dialog_response_get_user_input(
	ta_object_t response,
	ta_object_t* user_input );

/**
 * \brief Card data or ta_object_invalid if absent.
 * 
 * \param[in] response Object instance of type [show_dialog_response](\ref show_dialog_response.h).
 * \param[out] card_data Pointer to variable to write object instance to. Object
 *                       instance is of type [card_data](\ref card_data.h) and is not retained. Object
 *                       instance is \em ta_object_invalid if value is not set
 *                       in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_data.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [show_dialog_response](\ref show_dialog_response.h).
 * \retval ta_c_rc_invalid_argument \em card_data is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_dialog_response_get_card_data(
	ta_object_t response,
	ta_object_t* card_data );


#ifdef __cplusplus
}
#endif

#endif
