/**
 * \file constants/protocol_type.h
 *
 * Protocol to use for communication.
 *
 * Copyright: Worldline.
 */

#ifndef TA_PROTOCOL_TYPE_H
#define TA_PROTOCOL_TYPE_H


/**
 * <p>Protocol to use for communication.</p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_protocol_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_pt_undefined = 0,
    
    /**
     * <p>SIXml communication protocol.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_pt_sixml = 1
    
} ta_e_protocol_type_t;

#endif // TA_PROTOCOL_TYPE_H
