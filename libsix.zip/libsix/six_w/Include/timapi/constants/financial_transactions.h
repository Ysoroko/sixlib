/**
 * \file constants/financial_transactions.h
 *
 * Flag constants for FeatureType and OptionType sixml:FinancialTransactions value.
 *
 * Copyright: Worldline.
 */

#ifndef TA_FINANCIAL_TRANSACTIONS_H
#define TA_FINANCIAL_TRANSACTIONS_H


/**
 * <p>Flag constants for FeatureType and OptionType sixml:FinancialTransactions value.</p>
 * <p>Guides: retail, petrol, unattended, advancedRetail, banking, hospitality, valueAddedServices.</p>
 */
typedef enum ta_e_financial_transactions{
    /**
     * Undefined/invalid value.
     */
    ta_c_ft_undefined = 0,
    
    /**
     * <p>Purchase function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ft_purchase = 1 << 0,
    
    /**
     * <p>Credit function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ft_credit = 1 << 1,
    
    /**
     * <p>Reversal function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ft_reversal = 1 << 2,
    
    /**
     * <p>Commit function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ft_commit = 1 << 5,
    
    /**
     * <p>Rollback function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ft_rollback = 1 << 6,
    
    /**
     * <p>Pre-authorization function supported.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_ft_pre_authorization = 1 << 3,
    
    /**
     * <p>Online advice function supported.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_ft_finalize_purchase = 1 << 11,
    
    /**
     * <p>Adjust amount of an open transaction.</p>
     * <p>Specification: unattended.</p>
     */
    ta_c_ft_amt_adjustment = 1 << 20,
    
    /**
     * <p>DebtRecovery function supported.</p>
     * <p>Specification: unattended.</p>
     */
    ta_c_ft_debt_recovery = 1 << 28,
    
    /**
     * <p>Cash advance function supported.</p>
     * <p>Specification: advancedRetail.</p>
     */
    ta_c_ft_cash_advance = 1 << 4,
    
    /**
     * <p>Purchase function with forced acceptance supported.</p>
     * <p>Specification: advancedRetail.</p>
     */
    ta_c_ft_purchase_forced_acceptance = 1 << 13,
    
    /**
     * <p>Purchase function with cashback amount function supported.</p>
     * <p>Specification: advancedRetail.</p>
     */
    ta_c_ft_purchase_with_cashback = 1 << 14,
    
    /**
     * <p>Purchase function phone authorized function supported.</p>
     * <p>Specification: advancedRetail.</p>
     */
    ta_c_ft_purchase_phone_authorized = 1 << 15,
    
    /**
     * <p>Purchase function phone ordered supported.</p>
     * <p>Specification: advancedRetail.</p>
     */
    ta_c_ft_purchase_phone_ordered = 1 << 21,
    
    /**
     * <p>Purchase function mail ordered supported.</p>
     * <p>Specification: advancedRetail.</p>
     */
    ta_c_ft_purchase_mail_ordered = 1 << 22,
    
    /**
     * <p>Giro function supported.</p>
     * <p>Specification: banking.</p>
     */
    ta_c_ft_giro = 1 << 7,
    
    /**
     * <p>Combined function supported.</p>
     * <p>Specification: banking.</p>
     */
    ta_c_ft_combined = 1 << 8,
    
    /**
     * <p>Authorize credit function supported.</p>
     * <p>Specification: banking.</p>
     */
    ta_c_ft_authorize_credit = 1 << 9,
    
    /**
     * <p>Authorize deposit function supported.</p>
     * <p>Specification: banking.</p>
     */
    ta_c_ft_authorize_deposit = 1 << 10,
    
    /**
     * <p>Capture an open reservation.</p>
     * <p>Specification: hospitality.</p>
     */
    ta_c_ft_purchase_reservation = 1 << 18,
    
    /**
     * <p>Capture an open reservation phone authorized.</p>
     * <p>Specification: hospitality.</p>
     */
    ta_c_ft_purchase_reservation_phone_authorized = 1 << 19,
    
    /**
     * <p>Load Voucher request function supported.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_ft_load_voucher = 1 << 16,
    
    /**
     * <p>Collect points request function supported.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_ft_collect_points = 1 << 17,
    
    /**
     * <p>ActivateCard function supported.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_ft_activate_card = 1 << 23,
    
    /**
     * <p>Load function supported.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_ft_load = 1 << 24,
    
    /**
     * <p>Unload function supported.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_ft_unload = 1 << 25,
    
    /**
     * <p>Funding function supported.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_ft_funding = 1 << 26,
    
    /**
     * <p>Refunding function supported.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_ft_refunding = 1 << 27,
    
    /**
     * <p>MobileTopupPurchase function supported.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_ft_mobile_topup_purchase = 1 << 29,
    
    /**
     * <p>MobileTopupReversal function supported.</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_ft_mobile_topup_reversal = 1 << 30
    
} ta_e_financial_transactions_t;

#endif // TA_FINANCIAL_TRANSACTIONS_H
