/**
 * \file constants/payment_protocol.h
 *
 * <p>Specifies the payment protocol used.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_PAYMENT_PROTOCOL_H
#define TA_PAYMENT_PROTOCOL_H


/**
 * <p><p>Specifies the payment protocol used.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_payment_protocol{
    /**
     * Undefined/invalid value.
     */
    ta_c_pp_undefined = 0,
    
    /**
     * <p>EFTPOS 2000 protocol.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_pp_ep2 = 1,
    
    /**
     * <p>EV protocol.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_pp_ev = 2,
    
    /**
     * <p>ValueMaster protocol.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_pp_vm = 3,
    
    /**
     * <p>3CXml protocol.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_pp_3cxml = 4
    
} ta_e_payment_protocol_t;

#endif // TA_PAYMENT_PROTOCOL_H
