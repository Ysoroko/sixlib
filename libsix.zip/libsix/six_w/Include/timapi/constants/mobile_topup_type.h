/**
 * \file constants/mobile_topup_type.h
 *
 * Defines the type of mobile topup.
 *
 * Copyright: Worldline.
 */

#ifndef TA_MOBILE_TOPUP_TYPE_H
#define TA_MOBILE_TOPUP_TYPE_H


/**
 * Defines the type of mobile topup.
 */
typedef enum ta_e_mobile_topup_type{
    /**
     * Undefined.
     */
    ta_c_mtt_undefined = 0,
    
    /**
     * Purchase.
     */
    ta_c_mtt_purchase = 1,
    
    /**
     * Reversal. Requires terminal to be configured for credit transactions.
     */
    ta_c_mtt_reversal = 2
} ta_e_mobile_topup_type_t;

#endif // TA_TRANSACTION_TYPE_H
