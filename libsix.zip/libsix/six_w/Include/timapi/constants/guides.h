/**
 * \file constants/guides.h
 *
 * Flag constants for FeatureType and OptionType sixml:Guides value.
 *
 * Copyright: Worldline.
 */

#ifndef TA_GUIDES_H
#define TA_GUIDES_H


/**
 * <p>Flag constants for FeatureType and OptionType sixml:Guides value.</p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_guides{
    /**
     * Undefined/invalid value.
     */
    ta_c_guide_undefined = 0,
    
    /**
     * <p>SIXml Retail & Mobile. Fundamental retail business cases.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_guide_retail = 1 << 0,
    
    /**
     * <p>Unattended Terminals in vending machines.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_guide_unattended = 1 << 1,
    
    /**
     * <p>Advanced Retail additions: TopUp, Purchase with Cashback etc.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_guide_advanced_retail = 1 << 2,
    
    /**
     * <p>Banking business cases.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_guide_banking = 1 << 3,
    
    /**
     * <p>Pre-Authorization and fleet management for petrol business.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_guide_petrol = 1 << 4,
    
    /**
     * <p>Dialog mode addons.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_guide_dialog = 1 << 5,
    
    /**
     * <p>Remote addons.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_guide_remote = 1 << 6,
    
    /**
     * <p>Addons for restaurants.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_guide_gastro = 1 << 7,
    
    /**
     * <p>Addons for restaurants.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_guide_hospitality = 1 << 8,
    
    /**
     * <p>Addons for value added services.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_guide_value_added_services = 1 << 9,
    
    /**
     * <p>Addons for value added services.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_guide_austrian_use_cases = 1 << 10,
    
    /**
     * <p>Certification.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_guide_certification = 1 << 11
    
} ta_e_guides_t;

#endif // TA_GUIDES_H
