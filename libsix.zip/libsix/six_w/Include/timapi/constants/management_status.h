/**
 * \file constants/management_status.h
 *
 * <p>The <sixml:ManagementStatus> tag is used to transport information about the current activation
 * state of the terminal, i.e. shift open / shift closed.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_MANAGEMENT_STATUS_H
#define TA_MANAGEMENT_STATUS_H


/**
 * <p><p>The <sixml:ManagementStatus> tag is used to transport information about the current activation
 * state of the terminal, i.e. shift open / shift closed.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_management_status{
    /**
     * Undefined/invalid value.
     */
    ta_c_ms_undefined = 0,
    
    /**
     * <p>Initial state, shift closed. In this state only administration, remote and status functions
     * can be used, which means no interaction with the cardholder is required.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ms_closed = 1,
    
    /**
     * <p>Shift opened. In this state only financial, non-financial, remote and status functions as
     * well as Deactivate can be used. Usually an interaction with the cardholder is required.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ms_open = 2,
    
    /**
     * <p>Dialog mode opened. This state allows to process ECR controlled dialog functions. Only dialog
     * and remote functions can be used. (Some guides only)</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ms_dialog = 3
    
} ta_e_management_status_t;

#endif // TA_MANAGEMENT_STATUS_H
