/**
 * \file constants/customer_data_type.h
 *
 * <p>Specifies what kind of customer information the sixml:CustomerDataItem contains.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_CUSTOMER_DATA_TYPE_H
#define TA_CUSTOMER_DATA_TYPE_H


/**
 * <p><p>Specifies what kind of customer information the sixml:CustomerDataItem contains.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_customer_data_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_cdt_undefined = 0,
    
    /**
     * <p>Customer identifier e.g. of a Loyalty program.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_cdt_customer_id = 1,
    
    /**
     * <p>Identifier of the loyalty brand used.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_cdt_loyalty_brand_id = 2,
    
    /**
     * <p>Further information e.g. promotion codes or promotion descriptions. The values are defined by
     * the merchant or acquirer.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_cdt_further_info = 3
    
} ta_e_customer_data_type_t;

#endif // TA_CUSTOMER_DATA_TYPE_H
