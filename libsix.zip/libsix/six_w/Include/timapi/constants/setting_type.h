/**
 * \file constants/setting_type.h
 *
 * Constants for SettingType tag.
 *
 * Copyright: Worldline.
 */

#ifndef TA_SETTING_TYPE_H
#define TA_SETTING_TYPE_H


/**
 * <p>Constants for SettingType tag.</p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_setting_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_st_undefined = 0,
    
    /**
     * <p>Brightness of the display.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_st_display_brightness = 1,
    
    /**
     * <p>Contrast of the display.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_st_display_contrast = 2,
    
    /**
     * <p>Volume of the key press tones.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_st_keypad_tones = 3,
    
    /**
     * <p>Volume of the alert tones.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_st_alert_tones = 4,
    
    /**
     * <p>Language of the EFT. Valid values: <lng code>[-<cntry code>] as supported by the terminal.
     * e.g. "de", "de-at", "en", "nl-be"</p>
     * <p>Specification: retail.</p>
     */
    ta_c_st_language = 5,
    
    /**
     * <p>Selection of active power management profile. Valid values are fully devices dependent.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_st_power_management_mode = 6
    
} ta_e_setting_type_t;

#endif // TA_SETTING_TYPE_H
