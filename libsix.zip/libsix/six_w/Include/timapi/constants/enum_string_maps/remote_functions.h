/**
 * \file constants/enum_string_maps/remote_functions.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_REMOTE_FUNCTIONS_ENUM_STRING_MAP_H
#define TA_REMOTE_FUNCTIONS_ENUM_STRING_MAP_H

#include "../remote_functions.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Get String for Enum value.
 * 
 * \param[in] value Enum value to get string for
 * 
 * \returns String value.
 */
extern const char * ta_remote_functions_e2s(int value);
#ifdef __cplusplus
}
#endif

#endif // TA_REMOTE_FUNCTIONS_ENUM_STRING_MAP_H
