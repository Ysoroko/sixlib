/**
 * \file constants/enum_string_maps/theme.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_THEME_ENUM_STRING_MAP_H
#define TA_THEME_ENUM_STRING_MAP_H

#include "../theme.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Get String for Enum value.
 * 
 * \param[in] value Enum value to get string for
 * 
 * \returns String value.
 */
extern const char * ta_theme_e2s(ta_e_theme_t value);
#ifdef __cplusplus
}
#endif

#endif // TA_THEME_ENUM_STRING_MAP_H
