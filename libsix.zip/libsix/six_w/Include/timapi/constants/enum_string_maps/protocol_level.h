/**
 * \file constants/enum_string_maps/protocol_level.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_PROTOCOL_LEVEL_ENUM_STRING_MAP_H
#define TA_PROTOCOL_LEVEL_ENUM_STRING_MAP_H

#include "../protocol_level.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Get String for Enum value.
 * 
 * \param[in] value Enum value to get string for
 * 
 * \returns String value.
 */
extern const char * ta_protocol_level_e2s(ta_e_protocol_level_t value);
#ifdef __cplusplus
}
#endif

#endif // TA_PROTOCOL_LEVEL_ENUM_STRING_MAP_H
