/**
 * \file constants/enum_string_maps/outcome.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_OUTCOME_ENUM_STRING_MAP_H
#define TA_OUTCOME_ENUM_STRING_MAP_H

#include "../outcome.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Get String for Enum value.
 * 
 * \param[in] value Enum value to get string for
 * 
 * \returns String value.
 */
extern const char * ta_outcome_e2s(ta_e_outcome_t value);
#ifdef __cplusplus
}
#endif

#endif // TA_OUTCOME_ENUM_STRING_MAP_H
