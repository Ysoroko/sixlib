/**
 * \file constants/enum_string_maps/vas_info_list_type.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_VAS_INFO_LIST_TYPE_ENUM_STRING_MAP_H
#define TA_VAS_INFO_LIST_TYPE_ENUM_STRING_MAP_H

#include "../vas_info_list_type.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Get String for Enum value.
 * 
 * \param[in] value Enum value to get string for
 * 
 * \returns String value.
 */
extern const char * ta_vas_info_list_type_e2s(ta_e_vas_info_list_type_t value);
#ifdef __cplusplus
}
#endif

#endif // TA_VAS_INFO_LIST_TYPE_ENUM_STRING_MAP_H
