/**
 * \file constants/enum_string_maps/allowed_accounts.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_ALLOWED_ACCOUNTS_ENUM_STRING_MAP_H
#define TA_ALLOWED_ACCOUNTS_ENUM_STRING_MAP_H

#include "../allowed_accounts.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Get String for Enum value.
 * 
 * \param[in] value Enum value to get string for
 * 
 * \returns String value.
 */
extern const char * ta_allowed_accounts_e2s(int value);
#ifdef __cplusplus
}
#endif

#endif // TA_ALLOWED_ACCOUNTS_ENUM_STRING_MAP_H
