/**
 * \file constants/enum_string_maps/token_pan_type.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_TOKEN_PAN_TYPE_ENUM_STRING_MAP_H
#define TA_TOKEN_PAN_TYPE_ENUM_STRING_MAP_H

#include "../token_pan_type.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Get String for Enum value.
 * 
 * \param[in] value Enum value to get string for
 * 
 * \returns String value.
 */
extern const char * ta_token_pan_type_e2s(ta_e_token_pan_type_t value);
#ifdef __cplusplus
}
#endif

#endif // TA_TOKEN_PAN_TYPE_ENUM_STRING_MAP_H
