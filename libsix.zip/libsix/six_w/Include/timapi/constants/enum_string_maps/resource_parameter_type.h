/**
 * \file constants/enum_string_maps/resource_parameter_type.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_RESOURCE_PARAMETER_TYPE_ENUM_STRING_MAP_H
#define TA_RESOURCE_PARAMETER_TYPE_ENUM_STRING_MAP_H

#include "../resource_parameter_type.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Get String for Enum value.
 * 
 * \param[in] value Enum value to get string for
 * 
 * \returns String value.
 */
extern const char * ta_resource_parameter_type_e2s(ta_e_resource_parameter_type_t value);
#ifdef __cplusplus
}
#endif

#endif // TA_RESOURCE_PARAMETER_TYPE_ENUM_STRING_MAP_H
