/**
 * \file constants/enum_string_maps/third_party_app_id.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_THIRD_PARTY_APP_ID_ENUM_STRING_MAP_H
#define TA_THIRD_PARTY_APP_ID_ENUM_STRING_MAP_H

#include "../third_party_app_id.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Get String for Enum value.
 * 
 * \param[in] value Enum value to get string for
 * 
 * \returns String value.
 */
extern const char * ta_third_party_app_id_e2s(ta_e_third_party_app_id_t value);
#ifdef __cplusplus
}
#endif

#endif // TA_THIRD_PARTY_APP_ID_ENUM_STRING_MAP_H
