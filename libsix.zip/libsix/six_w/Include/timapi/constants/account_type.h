/**
 * \file constants/account_type.h
 *
 * Identifies the selected account. If Account Selection is enabled, the transaction responses
 * should contain this field. Default value is Credit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_ACCOUNT_TYPE_H
#define TA_ACCOUNT_TYPE_H


/**
 * <p>Identifies the selected account. If Account Selection is enabled, the transaction responses
 * should contain this field. Default value is Credit.</p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_account_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_at_undefined = 0,
    
    /**
     * <p>Cheque / Debit account selected.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_at_cheque = 1,
    
    /**
     * <p>Savings account selected.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_at_savings = 2,
    
    /**
     * <p>Credit account selected (default, e.g. for non-domestic brands).</p>
     * <p>Specification: retail.</p>
     */
    ta_c_at_credit = 3
    
} ta_e_account_type_t;

#endif // TA_ACCOUNT_TYPE_H
