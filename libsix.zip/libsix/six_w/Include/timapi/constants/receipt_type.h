/**
 * \file constants/receipt_type.h
 *
 * <p>Specifies type of the receipt.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_RECEIPT_TYPE_H
#define TA_RECEIPT_TYPE_H


/**
 * <p><p>Specifies type of the receipt.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_receipt_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_rt_undefined = 0,
    
    /**
     * <p>ActivateCard receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_activate_card = 1,
    
    /**
     * <p>AdjustReservation receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_adjust_reservation = 2,
    
    /**
     * <p>BalanceInquiry receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_balance_inquiry = 3,
    
    /**
     * <p>CashAdvance receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_cash_advance = 4,
    
    /**
     * <p>CancelReservation receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_cancel_reservation = 5,
    
    /**
     * <p>Credit receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_credit = 6,
    
    /**
     * <p>ConfirmReservation receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_confirm_reservation = 7,
    
    /**
     * <p>FinalizePurchase receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_finalize_purchase = 8,
    
    /**
     * <p>Load card/voucher receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_load = 9,
    
    /**
     * <p>PreAuthorization receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_pre_authorization = 10,
    
    /**
     * <p>Purchase receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_purchase = 11,
    
    /**
     * <p>PurchaseForcedAcceptance receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_purchase_forced_acceptance = 12,
    
    /**
     * <p>PurchaseMailOrdered receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_purchase_mail_ordered = 13,
    
    /**
     * <p>PurchasePhoneAuthorized receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_purchase_phone_authorized = 14,
    
    /**
     * <p>PurchasePhoneOrdered receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_purchase_phone_ordered = 15,
    
    /**
     * <p>PurchaseReservation receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_purchase_reservation = 16,
    
    /**
     * <p>PurchaseWithCashback receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_purchase_with_cashback = 17,
    
    /**
     * <p>Reservation receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_reservation = 18,
    
    /**
     * <p>Reversal receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_reversal = 19,
    
    /**
     * <p>Giro receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_giro = 20,
    
    /**
     * <p>Combined receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_combined = 21,
    
    /**
     * <p>AuthorizeCredit receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_authorize_credit = 22,
    
    /**
     * <p>AuthorizeDeposit receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_authorize_deposit = 23,
    
    /**
     * <p>ClientIdRequest receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_client_id_request = 24,
    
    /**
     * <p>AccountVerification receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rt_account_verification = 25
    
} ta_e_receipt_type_t;

#endif // TA_RECEIPT_TYPE_H
