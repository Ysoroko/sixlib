/**
 * \file constants/response_type.h
 *
 * <p>Defines the outcome type of the command response.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_RESPONSE_TYPE_H
#define TA_RESPONSE_TYPE_H


/**
 * <p><p>Defines the outcome type of the command response.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: dialog.</p>
 */
typedef enum ta_e_response_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_rest_undefined = 0,
    
    /**
     * <p>Positive command outcome.</p>
     * <p>Specification: dialog.</p>
     */
    ta_c_rest_positive = 1,
    
    /**
     * <p>Negative command outcome.</p>
     * <p>Specification: dialog.</p>
     */
    ta_c_rest_negative = 2,
    
    /**
     * <p>Card removed during command.</p>
     * <p>Specification: dialog.</p>
     */
    ta_c_rest_card_removal = 3,
    
    /**
     * <p>Timeout during command.</p>
     * <p>Specification: dialog.</p>
     */
    ta_c_rest_timeout = 4
    
} ta_e_response_type_t;

#endif // TA_RESPONSE_TYPE_H
