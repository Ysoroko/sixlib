/**
 * \file constants/currency_type.h
 *
 * <p>Specifies the type of currency. Used to distinguish between base and DCC currencies.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_CURRENCY_TYPE_H
#define TA_CURRENCY_TYPE_H


/**
 * <p><p>Specifies the type of currency. Used to distinguish between base and DCC currencies.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_currency_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_curt_undefined = 0,
    
    /**
     * <p>Local currency depending on location</p>
     * <p>Specification: retail.</p>
     */
    ta_c_curt_local = 1,
    
    /**
     * <p>Foreign currency</p>
     * <p>Specification: retail.</p>
     */
    ta_c_curt_foreign = 2,
    
    /**
     * <p>Currency used for DCC conversion</p>
     * <p>Specification: retail.</p>
     */
    ta_c_curt_dcc = 3
    
} ta_e_currency_type_t;

#endif // TA_CURRENCY_TYPE_H
