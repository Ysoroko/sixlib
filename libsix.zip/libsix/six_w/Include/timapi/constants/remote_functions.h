/**
 * \file constants/remote_functions.h
 *
 * Flag constants for FeatureType and OptionType sixml:RemoteFunctions value.
 *
 * Copyright: Worldline.
 */

#ifndef TA_REMOTE_FUNCTIONS_H
#define TA_REMOTE_FUNCTIONS_H


/**
 * <p>Flag constants for FeatureType and OptionType sixml:RemoteFunctions value.</p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_remote_functions{
    /**
     * Undefined/invalid value.
     */
    ta_c_rf_undefined = 0,
    
    /**
     * <p>Screenshot function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rf_screenshot = 1 << 0,
    
    /**
     * <p>Device maintenance function supported.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rf_device_maintenance = 1 << 1
    
} ta_e_remote_functions_t;

#endif // TA_REMOTE_FUNCTIONS_H
