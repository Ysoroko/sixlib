/**
 * \file constants/loyalty_function_type.h
 *
 * <p>Defines what kind of loyalty mode will be used.</p>
 * <p>The are different modes that can be used with the LoyaltyData function.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_LOYALTY_FUNCTION_TYPE_H
#define TA_LOYALTY_FUNCTION_TYPE_H


/**
 * <p><p>Defines what kind of loyalty mode will be used.</p>
 * <p>The are different modes that can be used with the LoyaltyData function.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: valueAddedServices.</p>
 */
typedef enum ta_e_loyalty_function_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_lft_undefined = 0,
    
    /**
     * <p>Loyalty initialization</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_lft_init = 1,
    
    /**
     * <p>Loyalty data update</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_lft_update = 2,
    
    /**
     * <p>Loyalty deinitialization</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_lft_deinit = 3,
    
    /**
     * <p>Loyalty query</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_lft_query = 4
    
} ta_e_loyalty_function_type_t;

#endif // TA_LOYALTY_FUNCTION_TYPE_H
