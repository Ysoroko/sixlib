/**
 * \file constants/maintenance_type.h
 *
 * Type of maintenance process to perform.
 *
 * Copyright: Worldline.
 */

#ifndef TA_MAINTENANCE_TYPE_H
#define TA_MAINTENANCE_TYPE_H


/**
 * <p>Type of maintenance process to perform.</p>
 * <p>Specification: remote.</p>
 */
typedef enum ta_e_maintenance_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_mt_undefined = 0,
    
    /**
     * <p>Start the process of cleaning card readers</p>
     * <p>Specification: remote.</p>
     */
    ta_c_mt_clean_readers = 1,
    
    /**
     * <p>Start the process of touch screen calibration.</p>
     * <p>Specification: remote.</p>
     */
    ta_c_mt_calibrate_touch_screen = 2,
    
    /**
     * <p>Transmit terminal event log data.</p>
     * <p>Specification: remote.</p>
     */
    ta_c_mt_transmit_teld = 3
    
} ta_e_maintenance_type_t;

#endif // TA_MAINTENANCE_TYPE_H
