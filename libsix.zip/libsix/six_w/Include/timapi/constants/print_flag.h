/**
 * \file constants/print_flag.h
 *
 * Constants for PrintFlag tag or&ed together.
 *
 * Copyright: Worldline.
 */

#ifndef TA_PRINT_FLAG_H
#define TA_PRINT_FLAG_H


/**
 * <p>Constants for PrintFlag tag or&ed together.</p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_print_flag{
    /**
     * Undefined/invalid value.
     */
    ta_c_pflag_undefined = 0,
    
    /**
     * <p>Do not print receipt headers.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_pflag_suppress_header = 1 << 0,
    
    /**
     * <p>Do not print signature line.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_pflag_suppress_signature = 1 << 1,
    
    /**
     * <p>Do not print ECR information.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_pflag_suppress_ecr_info = 1 << 2,
    
    /**
     * <p>Do not print EFT terminal information.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_pflag_suppress_eft_info = 1 << 3,
    
    /**
     * <p>Do not print footers e.g. Additional Ticket Text.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_pflag_suppress_footer = 1 << 4
    
} ta_e_print_flag_t;

#endif // TA_PRINT_FLAG_H
