/**
 * \file constants/merchant_option_type.h
 *
 * <p>Specifies type of merchant option.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_MERCHANT_OPTION_TYPE_H
#define TA_MERCHANT_OPTION_TYPE_H


/**
 * <p><p>Specifies type of merchant option.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_merchant_option_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_mot_undefined = 0,
    
    /**
     * <p>Additional data the merchant would like to add. String value.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_mot_additional_merchant_data = 1,
    
    /**
     * <p>Account index that shall be used for this transaction. Numeric number that defines the
     * account index.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_mot_multi_account_index = 2,
    
    /**
     * <p>Acquirer contract index that shall be used for this transaction. Numeric number that
     * specifies the contract index.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_mot_multi_contract_index = 3,
    
    /**
     * <p>Specific terminal identifier defined by the merchant.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_mot_merchant_tid = 4,
    
    /**
     * <p>Merchant defined attendant identifier. Used for petrol MOC, provided by ECR.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_mot_clerk_identifier = 5,
    
    /**
     * <p>Fuel Pump number. Used for petrol MOC, provided by ECR.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_mot_fuel_dispenser_number = 6,
    
    /**
     * <p>Number of the ECR device. Used for petrol MOC, provided by ECR.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_mot_posdnumber = 7,
    
    /**
     * <p>ECR Receipt number. Used for petrol MOC, provided by ECR.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_mot_receipt_number = 8,
    
    /**
     * <p>ECR side shift number. Used for petrol MOC, provided by ECR.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_mot_shift_number = 9
    
} ta_e_merchant_option_type_t;

#endif // TA_MERCHANT_OPTION_TYPE_H
