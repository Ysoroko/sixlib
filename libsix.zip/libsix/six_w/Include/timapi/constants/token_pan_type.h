/**
 * \file constants/token_pan_type.h
 *
 * <p>To differ the source of a token PAN, the TokenPanType field is used in a SIXml request message
 * as part of the sixml:TransactionData container and in a SIXml response message as part of the
 * sixml:CardData container.</p>
 * <p>The TokenPanType field always is transmitted if a TokenPan field is transmitted but must not
 * be transmitted alone.</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_TOKEN_PAN_TYPE_H
#define TA_TOKEN_PAN_TYPE_H


/**
 * <p><p>To differ the source of a token PAN, the TokenPanType field is used in a SIXml request message
 * as part of the sixml:TransactionData container and in a SIXml response message as part of the
 * sixml:CardData container.</p>
 * <p>The TokenPanType field always is transmitted if a TokenPan field is transmitted but must not
 * be transmitted alone.</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_token_pan_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_tpt_undefined = 0,
    
    /**
     * <p>Worldline Global Tokenization Service.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_tpt_gts = 1,
    
    /**
     * <p>SIX BNR2.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_tpt_bnr2 = 2
    
} ta_e_token_pan_type_t;

#endif // TA_TOKEN_PAN_TYPE_H
