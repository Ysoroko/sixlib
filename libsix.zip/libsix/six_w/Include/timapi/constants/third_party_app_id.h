/**
 * \file constants/third_party_app_id.h
 *
 * Identifier of a third party application.
 *
 * Copyright: Worldline.
 */

#ifndef TA_THIRD_PARTY_APP_ID_H
#define TA_THIRD_PARTY_APP_ID_H


/**
 * <p>Identifier of a third party application.</p>
 * <p>Specification: valueAddedServices.</p>
 */
typedef enum ta_e_third_party_app_id{
    /**
     * Undefined/invalid value.
     */
    ta_c_tpaid_undefined = 0,
    
    /**
     * <p>Slave app written by Linkly (Australian POS service provider)</p>
     * <p>Specification: valueAddedServices.</p>
     */
    ta_c_tpaid_linkly_slave_app = 1
    
} ta_e_third_party_app_id_t;

#endif // TA_THIRD_PARTY_APP_ID_H
