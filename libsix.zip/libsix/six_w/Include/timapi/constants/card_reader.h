/**
 * \file constants/card_reader.h
 *
 * <p>Defines that shall be used for the card commands.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_CARD_READER_H
#define TA_CARD_READER_H


/**
 * <p><p>Defines that shall be used for the card commands.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: dialog.</p>
 */
typedef enum ta_e_card_reader{
    /**
     * Undefined/invalid value.
     */
    ta_c_cr_undefined = 0,
    
    /**
     * <p>Contact card reader.</p>
     * <p>Specification: dialog.</p>
     */
    ta_c_cr_icc = 1,
    
    /**
     * <p>Contactless reader.</p>
     * <p>Specification: dialog.</p>
     */
    ta_c_cr_cl = 2,
    
    /**
     * <p>Magstripe reader.</p>
     * <p>Specification: dialog.</p>
     */
    ta_c_cr_ms = 3
    
} ta_e_card_reader_t;

#endif // TA_CARD_READER_H
