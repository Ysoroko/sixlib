/**
 * \file constants/allowed_accounts.h
 *
 * Constants for AllowedAccounts tag or&ed together. Not set flags are restricted.
 *
 * Copyright: Worldline.
 */

#ifndef TA_ALLOWED_ACCOUNTS_H
#define TA_ALLOWED_ACCOUNTS_H


/**
 * <p>Constants for AllowedAccounts tag or&ed together. Not set flags are restricted.</p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_allowed_accounts{
    /**
     * Undefined/invalid value.
     */
    ta_c_aa_undefined = 0,
    
    /**
     * <p>Allow account Cheque during Account Selection.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_aa_cheque = 1 << 0,
    
    /**
     * <p>Allow account Savings during Account Selection.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_aa_savings = 1 << 1,
    
    /**
     * <p>Allow account Credit during Account Selection.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_aa_credit = 1 << 2
    
} ta_e_allowed_accounts_t;

#endif // TA_ALLOWED_ACCOUNTS_H
