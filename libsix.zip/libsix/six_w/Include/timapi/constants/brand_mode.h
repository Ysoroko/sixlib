/**
 * \file constants/brand_mode.h
 *
 * <p>This attribute is used to specify which Brand icons are shown in the BrandBar element in a
 * dialog.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_BRAND_MODE_H
#define TA_BRAND_MODE_H


/**
 * <p><p>This attribute is used to specify which Brand icons are shown in the BrandBar element in a
 * dialog.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: dialog.</p>
 */
typedef enum ta_e_brand_mode{
    /**
     * Undefined/invalid value.
     */
    ta_c_bm_undefined = 0,
    
    /**
     * <p>All supported brand icons are shown in the BrandBar.</p>
     * <p>Specification: dialog.</p>
     */
    ta_c_bm_all = 1,
    
    /**
     * <p>Only the selected brand icon is shown in the BrandBar. The brands that shall be displayed
     * have to be defined with the BrandBar tag.</p>
     * <p>Specification: dialog.</p>
     */
    ta_c_bm_selected = 2,
    
    /**
     * <p>No brand icons are shown in the BrandBar.</p>
     * <p>Specification: dialog.</p>
     */
    ta_c_bm_off = 3
    
} ta_e_brand_mode_t;

#endif // TA_BRAND_MODE_H
