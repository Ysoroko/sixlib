/**
 * \file constants/cvm.h
 *
 * <p>Specifies which cardholder verification method has been performed during the transaction.</p>
 * <p>The supported cardholder verification methods are defined both, on the terminal and on the
 * card. The first match of both sides will be performed according to EMV Book 3 [B11].</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_CVM_H
#define TA_CVM_H


/**
 * <p><p>Specifies which cardholder verification method has been performed during the transaction.</p>
 * <p>The supported cardholder verification methods are defined both, on the terminal and on the
 * card. The first match of both sides will be performed according to EMV Book 3 [B11].</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_cvm{
    /**
     * Undefined/invalid value.
     */
    ta_c_cvm_undefined = 0,
    
    /**
     * <p>PIN verification</p>
     * <p>Specification: retail.</p>
     */
    ta_c_cvm_pin = 1,
    
    /**
     * <p>PIN verification and signature (paper).</p>
     * <p>Specification: retail.</p>
     */
    ta_c_cvm_pin_signature = 2,
    
    /**
     * <p>Signature (paper).</p>
     * <p>Specification: retail.</p>
     */
    ta_c_cvm_signature = 3,
    
    /**
     * <p>On device cvm.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_cvm_on_device = 4,
    
    /**
     * <p>No CVM required.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_cvm_no_cvm = 5
    
} ta_e_cvm_t;

#endif // TA_CVM_H
