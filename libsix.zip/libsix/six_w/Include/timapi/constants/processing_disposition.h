/**
 * \file constants/processing_disposition.h
 *
 * <p>Defines if the ECR or EFT is responsible for further trx handling.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_PROCESSING_DISPOSITION_H
#define TA_PROCESSING_DISPOSITION_H


/**
 * <p><p>Defines if the ECR or EFT is responsible for further trx handling.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: petrol.</p>
 */
typedef enum ta_e_processing_disposition{
    /**
     * Undefined/invalid value.
     */
    ta_c_pd_undefined = 0,
    
    /**
     * <p>The ECR is responsible for further trx handling.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_pd_on_ecr = 1,
    
    /**
     * <p>The EFT is responsible for further trx handling.</p>
     * <p>Specification: petrol.</p>
     */
    ta_c_pd_on_eft = 2
    
} ta_e_processing_disposition_t;

#endif // TA_PROCESSING_DISPOSITION_H
