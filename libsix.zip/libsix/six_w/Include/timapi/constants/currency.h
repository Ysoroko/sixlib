/**
 * \file constants/currency.h
 *
 * \warning This file is generated. Do not edit.
 *
 * Copyright: Worldline.
 */

#ifndef TA_CURRENCY_H
#define TA_CURRENCY_H

#include "result_code.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Currency code.
 */
typedef struct ta_s_currency{

    /**
     * Code identifying the currency. Use this to display amounts on screen.
     */
    const char * code;

    /**
     * Verbose currency name for example for selections to choose from.
     */
    const char * name;

    /**
     * Minor units exponent to properly format amounts on screen.
     */
    int exponent;
} ta_s_currency_t;


/**
 * Currency codes.
 */
typedef enum ta_e_currency{
    /**
     * Undefined/invalid currency code.
     */
    ta_c_currency_undefined,
    
    /**
     * UAE Dirham.
     */
    ta_c_currency_aed,
    
    /**
     * Afghani.
     */
    ta_c_currency_afn,
    
    /**
     * Lek.
     */
    ta_c_currency_all,
    
    /**
     * Armenian Dram.
     */
    ta_c_currency_amd,
    
    /**
     * Netherlands Antillean Guilder.
     */
    ta_c_currency_ang,
    
    /**
     * Kwanza.
     */
    ta_c_currency_aoa,
    
    /**
     * Argentine Peso.
     */
    ta_c_currency_ars,
    
    /**
     * Australian Dollar.
     */
    ta_c_currency_aud,
    
    /**
     * Aruban Florin.
     */
    ta_c_currency_awg,
    
    /**
     * Azerbaijanian Manat.
     */
    ta_c_currency_azn,
    
    /**
     * Convertible Mark.
     */
    ta_c_currency_bam,
    
    /**
     * Barbados Dollar.
     */
    ta_c_currency_bbd,
    
    /**
     * Taka.
     */
    ta_c_currency_bdt,
    
    /**
     * Bulgarian Lev.
     */
    ta_c_currency_bgn,
    
    /**
     * Bahraini Dinar.
     */
    ta_c_currency_bhd,
    
    /**
     * Burundi Franc.
     */
    ta_c_currency_bif,
    
    /**
     * Bermudian Dollar.
     */
    ta_c_currency_bmd,
    
    /**
     * Brunei Dollar.
     */
    ta_c_currency_bnd,
    
    /**
     * Boliviano.
     */
    ta_c_currency_bob,
    
    /**
     * Mvdol.
     */
    ta_c_currency_bov,
    
    /**
     * Brazilian Real.
     */
    ta_c_currency_brl,
    
    /**
     * Bahamian Dollar.
     */
    ta_c_currency_bsd,
    
    /**
     * Ngultrum.
     */
    ta_c_currency_btn,
    
    /**
     * Pula.
     */
    ta_c_currency_bwp,
    
    /**
     * Belarusian Ruble.
     */
    ta_c_currency_byn,
    
    /**
     * Belarusian Ruble.
     */
    ta_c_currency_byr,
    
    /**
     * Belize Dollar.
     */
    ta_c_currency_bzd,
    
    /**
     * Canadian Dollar.
     */
    ta_c_currency_cad,
    
    /**
     * Congolese Franc.
     */
    ta_c_currency_cdf,
    
    /**
     * WIR Euro.
     */
    ta_c_currency_che,
    
    /**
     * Swiss Franc.
     */
    ta_c_currency_chf,
    
    /**
     * WIR Franc.
     */
    ta_c_currency_chw,
    
    /**
     * Unidad de Fomento.
     */
    ta_c_currency_clf,
    
    /**
     * Chilean Peso.
     */
    ta_c_currency_clp,
    
    /**
     * Yuan Renminbi.
     */
    ta_c_currency_cny,
    
    /**
     * Colombian Peso.
     */
    ta_c_currency_cop,
    
    /**
     * Unidad de Valor Real.
     */
    ta_c_currency_cou,
    
    /**
     * Costa Rican Colon.
     */
    ta_c_currency_crc,
    
    /**
     * Peso Convertible.
     */
    ta_c_currency_cuc,
    
    /**
     * Cuban Peso.
     */
    ta_c_currency_cup,
    
    /**
     * Cabo Verde Escudo.
     */
    ta_c_currency_cve,
    
    /**
     * Czech Koruna.
     */
    ta_c_currency_czk,
    
    /**
     * Djibouti Franc.
     */
    ta_c_currency_djf,
    
    /**
     * Danish Krone.
     */
    ta_c_currency_dkk,
    
    /**
     * Dominican Peso.
     */
    ta_c_currency_dop,
    
    /**
     * Algerian Dinar.
     */
    ta_c_currency_dzd,
    
    /**
     * Egyptian Pound.
     */
    ta_c_currency_egp,
    
    /**
     * Nakfa.
     */
    ta_c_currency_ern,
    
    /**
     * Ethiopian Birr.
     */
    ta_c_currency_etb,
    
    /**
     * Euro.
     */
    ta_c_currency_eur,
    
    /**
     * Fiji Dollar.
     */
    ta_c_currency_fjd,
    
    /**
     * Falkland Islands Pound.
     */
    ta_c_currency_fkp,
    
    /**
     * Pound Sterling.
     */
    ta_c_currency_gbp,
    
    /**
     * Lari.
     */
    ta_c_currency_gel,
    
    /**
     * Ghana Cedi.
     */
    ta_c_currency_ghs,
    
    /**
     * Gibraltar Pound.
     */
    ta_c_currency_gip,
    
    /**
     * Dalasi.
     */
    ta_c_currency_gmd,
    
    /**
     * Guinea Franc.
     */
    ta_c_currency_gnf,
    
    /**
     * Quetzal.
     */
    ta_c_currency_gtq,
    
    /**
     * Guyana Dollar.
     */
    ta_c_currency_gyd,
    
    /**
     * Hong Kong Dollar.
     */
    ta_c_currency_hkd,
    
    /**
     * Lempira.
     */
    ta_c_currency_hnl,
    
    /**
     * Kuna.
     */
    ta_c_currency_hrk,
    
    /**
     * Gourde.
     */
    ta_c_currency_htg,
    
    /**
     * Forint.
     */
    ta_c_currency_huf,
    
    /**
     * Rupiah.
     */
    ta_c_currency_idr,
    
    /**
     * New Israeli Sheqel.
     */
    ta_c_currency_ils,
    
    /**
     * Indian Rupee.
     */
    ta_c_currency_inr,
    
    /**
     * Iraqi Dinar.
     */
    ta_c_currency_iqd,
    
    /**
     * Iranian Rial.
     */
    ta_c_currency_irr,
    
    /**
     * Iceland Krona.
     */
    ta_c_currency_isk,
    
    /**
     * Jamaican Dollar.
     */
    ta_c_currency_jmd,
    
    /**
     * Jordanian Dinar.
     */
    ta_c_currency_jod,
    
    /**
     * Yen.
     */
    ta_c_currency_jpy,
    
    /**
     * Kenyan Shilling.
     */
    ta_c_currency_kes,
    
    /**
     * Som.
     */
    ta_c_currency_kgs,
    
    /**
     * Riel.
     */
    ta_c_currency_khr,
    
    /**
     * Comoro Franc.
     */
    ta_c_currency_kmf,
    
    /**
     * North Korean Won.
     */
    ta_c_currency_kpw,
    
    /**
     * Won.
     */
    ta_c_currency_krw,
    
    /**
     * Kuwaiti Dinar.
     */
    ta_c_currency_kwd,
    
    /**
     * Cayman Islands Dollar.
     */
    ta_c_currency_kyd,
    
    /**
     * Tenge.
     */
    ta_c_currency_kzt,
    
    /**
     * Kip.
     */
    ta_c_currency_lak,
    
    /**
     * Lebanese Pound.
     */
    ta_c_currency_lbp,
    
    /**
     * Sri Lanka Rupee.
     */
    ta_c_currency_lkr,
    
    /**
     * Liberian Dollar.
     */
    ta_c_currency_lrd,
    
    /**
     * Loti.
     */
    ta_c_currency_lsl,
    
    /**
     * Libyan Dinar.
     */
    ta_c_currency_lyd,
    
    /**
     * Moroccan Dirham.
     */
    ta_c_currency_mad,
    
    /**
     * Moldovan Leu.
     */
    ta_c_currency_mdl,
    
    /**
     * Malagasy Ariary.
     */
    ta_c_currency_mga,
    
    /**
     * Denar.
     */
    ta_c_currency_mkd,
    
    /**
     * Kyat.
     */
    ta_c_currency_mmk,
    
    /**
     * Tugrik.
     */
    ta_c_currency_mnt,
    
    /**
     * Pataca.
     */
    ta_c_currency_mop,
    
    /**
     * Ouguiya.
     */
    ta_c_currency_mro,
    
    /**
     * Mauritius Rupee.
     */
    ta_c_currency_mur,
    
    /**
     * Rufiyaa.
     */
    ta_c_currency_mvr,
    
    /**
     * Malawi Kwacha.
     */
    ta_c_currency_mwk,
    
    /**
     * Mexican Peso.
     */
    ta_c_currency_mxn,
    
    /**
     * Mexican Unidad de Inversion (UDI).
     */
    ta_c_currency_mxv,
    
    /**
     * Malaysian Ringgit.
     */
    ta_c_currency_myr,
    
    /**
     * Mozambique Metical.
     */
    ta_c_currency_mzn,
    
    /**
     * Namibia Dollar.
     */
    ta_c_currency_nad,
    
    /**
     * Naira.
     */
    ta_c_currency_ngn,
    
    /**
     * Cordoba Oro.
     */
    ta_c_currency_nio,
    
    /**
     * Norwegian Krone.
     */
    ta_c_currency_nok,
    
    /**
     * Nepalese Rupee.
     */
    ta_c_currency_npr,
    
    /**
     * New Zealand Dollar.
     */
    ta_c_currency_nzd,
    
    /**
     * Rial Omani.
     */
    ta_c_currency_omr,
    
    /**
     * Balboa.
     */
    ta_c_currency_pab,
    
    /**
     * Sol.
     */
    ta_c_currency_pen,
    
    /**
     * Kina.
     */
    ta_c_currency_pgk,
    
    /**
     * Philippine Peso.
     */
    ta_c_currency_php,
    
    /**
     * Pakistan Rupee.
     */
    ta_c_currency_pkr,
    
    /**
     * Zloty.
     */
    ta_c_currency_pln,
    
    /**
     * VM Loyalty.
     */
    ta_c_currency_pts,
    
    /**
     * Guarani.
     */
    ta_c_currency_pyg,
    
    /**
     * Qatari Rial.
     */
    ta_c_currency_qar,
    
    /**
     * Romanian Leu.
     */
    ta_c_currency_ron,
    
    /**
     * Serbian Dinar.
     */
    ta_c_currency_rsd,
    
    /**
     * Russian Ruble.
     */
    ta_c_currency_rub,
    
    /**
     * Rwanda Franc.
     */
    ta_c_currency_rwf,
    
    /**
     * Saudi Riyal.
     */
    ta_c_currency_sar,
    
    /**
     * Solomon Islands Dollar.
     */
    ta_c_currency_sbd,
    
    /**
     * Seychelles Rupee.
     */
    ta_c_currency_scr,
    
    /**
     * Sudanese Pound.
     */
    ta_c_currency_sdg,
    
    /**
     * Swedish Krona.
     */
    ta_c_currency_sek,
    
    /**
     * Singapore Dollar.
     */
    ta_c_currency_sgd,
    
    /**
     * Saint Helena Pound.
     */
    ta_c_currency_shp,
    
    /**
     * Leone.
     */
    ta_c_currency_sll,
    
    /**
     * Somali Shilling.
     */
    ta_c_currency_sos,
    
    /**
     * Surinam Dollar.
     */
    ta_c_currency_srd,
    
    /**
     * South Sudanese Pound.
     */
    ta_c_currency_ssp,
    
    /**
     * Dobra.
     */
    ta_c_currency_std,
    
    /**
     * El Salvador Colon.
     */
    ta_c_currency_svc,
    
    /**
     * Syrian Pound.
     */
    ta_c_currency_syp,
    
    /**
     * Lilangeni.
     */
    ta_c_currency_szl,
    
    /**
     * Baht.
     */
    ta_c_currency_thb,
    
    /**
     * Somoni.
     */
    ta_c_currency_tjs,
    
    /**
     * Turkmenistan New Manat.
     */
    ta_c_currency_tmt,
    
    /**
     * Tunisian Dinar.
     */
    ta_c_currency_tnd,
    
    /**
     * Pa’anga.
     */
    ta_c_currency_top,
    
    /**
     * Turkish Lira.
     */
    ta_c_currency_try,
    
    /**
     * Trinidad and Tobago Dollar.
     */
    ta_c_currency_ttd,
    
    /**
     * New Taiwan Dollar.
     */
    ta_c_currency_twd,
    
    /**
     * Tanzanian Shilling.
     */
    ta_c_currency_tzs,
    
    /**
     * Hryvnia.
     */
    ta_c_currency_uah,
    
    /**
     * Uganda Shilling.
     */
    ta_c_currency_ugx,
    
    /**
     * US Dollar.
     */
    ta_c_currency_usd,
    
    /**
     * US Dollar (Next day).
     */
    ta_c_currency_usn,
    
    /**
     * Uruguay Peso en Unidades Indexadas (URUIURUI).
     */
    ta_c_currency_uyi,
    
    /**
     * Peso Uruguayo.
     */
    ta_c_currency_uyu,
    
    /**
     * Uzbekistan Sum.
     */
    ta_c_currency_uzs,
    
    /**
     * Bolívar.
     */
    ta_c_currency_vef,
    
    /**
     * Dong.
     */
    ta_c_currency_vnd,
    
    /**
     * Vatu.
     */
    ta_c_currency_vuv,
    
    /**
     * Tala.
     */
    ta_c_currency_wst,
    
    /**
     * CFA Franc BEAC.
     */
    ta_c_currency_xaf,
    
    /**
     * Silver.
     */
    ta_c_currency_xag,
    
    /**
     * Gold.
     */
    ta_c_currency_xau,
    
    /**
     * Bond Markets Unit European Composite Unit (EURCO).
     */
    ta_c_currency_xba,
    
    /**
     * Bond Markets Unit European Monetary Unit (E.M.U.-6).
     */
    ta_c_currency_xbb,
    
    /**
     * Bond Markets Unit European Unit of Account 9 (E.U.A.-9).
     */
    ta_c_currency_xbc,
    
    /**
     * Bond Markets Unit European Unit of Account 17 (E.U.A.-17).
     */
    ta_c_currency_xbd,
    
    /**
     * East Caribbean Dollar.
     */
    ta_c_currency_xcd,
    
    /**
     * SDR (Special Drawing Right).
     */
    ta_c_currency_xdr,
    
    /**
     * CFA Franc BCEAO.
     */
    ta_c_currency_xof,
    
    /**
     * Palladium.
     */
    ta_c_currency_xpd,
    
    /**
     * CFP Franc.
     */
    ta_c_currency_xpf,
    
    /**
     * Platinum.
     */
    ta_c_currency_xpt,
    
    /**
     * Sucre.
     */
    ta_c_currency_xsu,
    
    /**
     * Codes specifically reserved for testing purposes.
     */
    ta_c_currency_xts,
    
    /**
     * ADB Unit of Account.
     */
    ta_c_currency_xua,
    
    /**
     * The codes assigned for transactions where no currency is involved.
     */
    ta_c_currency_xxx,
    
    /**
     * Yemeni Rial.
     */
    ta_c_currency_yer,
    
    /**
     * Rand.
     */
    ta_c_currency_zar,
    
    /**
     * Zambian Kwacha.
     */
    ta_c_currency_zmw,
    
    /**
     * Zimbabwe Dollar.
     */
    ta_c_currency_zwl
    
} ta_e_currency_t;

/**
 * Get enumeration value matching code.
 * 
 * \param[in] code Code to look up
 * \param[out] currency Variable to write result to.
 * 
 * \retval ta_c_rc_ok Currency constant written to \em currency. Set to \em ta_c_currency_undefined
 *                    if currency is not found.
 * \retval ta_c_rc_invalid_argument \em code is 0 pointer.
 * \retval ta_c_rc_invalid_argument \em currency is 0 pointer.
 * \retval ta_c_rc_invalid_argument Currency with \em code not found.
 */
extern ta_e_result_code_t ta_currency_with_code(const char * code,
                                                ta_e_currency_t* currency);

/**
 * Get currency parameters.
 * 
 * \param[in] currency Currency to get parameters for
 * \param[out] parameters Variable to write parameters to.
 * 
 * \retval ta_c_rc_ok Parameters written to \em parameters.
 * \retval ta_c_rc_invalid_argument \em currency is 0 pointer.
 * \retval ta_c_rc_invalid_argument \em parameters is 0 pointer.
 * \retval ta_c_rc_invalid_argument Invalid currency value.
 */
extern ta_e_result_code_t ta_currency_get_parameters(ta_e_currency_t currency,
                                                     ta_s_currency_t* parameters);
#ifdef __cplusplus
}
#endif

#endif // TA_CURRENCY_H
