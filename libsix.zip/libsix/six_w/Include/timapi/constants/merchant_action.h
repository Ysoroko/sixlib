/**
 * \file constants/merchant_action.h
 *
 * Constants for MerchantAction tag.
 *
 * Copyright: Worldline.
 */

#ifndef TA_MERCHANT_ACTION_H
#define TA_MERCHANT_ACTION_H


/**
 * <p>Constants for MerchantAction tag.</p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_merchant_action{
    /**
     * Undefined/invalid value.
     */
    ta_c_ma_undefined = 0,
    
    /**
     * <p>The merchant has to sign the receipt.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ma_signature = 1,
    
    /**
     * <p>No merchant action is required.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_ma_none = 2
    
} ta_e_merchant_action_t;

#endif // TA_MERCHANT_ACTION_H
