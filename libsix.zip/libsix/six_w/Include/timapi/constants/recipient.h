/**
 * \file constants/recipient.h
 *
 * <p>Specifies the recipient of a receipt.</p>
 * <p>The following values are valid:</p>
 *
 * Copyright: Worldline.
 */

#ifndef TA_RECIPIENT_H
#define TA_RECIPIENT_H


/**
 * <p><p>Specifies the recipient of a receipt.</p>
 * <p>The following values are valid:</p></p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_recipient{
    /**
     * Undefined/invalid value.
     */
    ta_c_rcp_undefined = 0,
    
    /**
     * <p>The datum is intended for the merchant.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rcp_merchant = 1,
    
    /**
     * <p>The datum is intended for the cardholder.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rcp_cardholder = 2,
    
    /**
     * <p>The datum is intended for the cardholder and the merchant.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rcp_both = 3
    
} ta_e_recipient_t;

#endif // TA_RECIPIENT_H
