/**
 * \file constants/receipt_request_type.h
 *
 * Constants for ReceiptRequestType tag.
 *
 * Copyright: Worldline.
 */

#ifndef TA_RECEIPT_REQUEST_TYPE_H
#define TA_RECEIPT_REQUEST_TYPE_H


/**
 * <p>Constants for ReceiptRequestType tag.</p>
 * <p>Specification: retail.</p>
 */
typedef enum ta_e_receipt_request_type{
    /**
     * Undefined/invalid value.
     */
    ta_c_rrt_undefined = 0,
    
    /**
     * <p>Only the latest receipt is returned for reprinting.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rrt_reprint = 1,
    
    /**
     * <p>A list of collected silent receipts is returned.</p>
     * <p>Specification: retail.</p>
     */
    ta_c_rrt_list = 2
    
} ta_e_receipt_request_type_t;

#endif // TA_RECEIPT_REQUEST_TYPE_H
