/**
 * \file
 * \brief Client identification response.
 * \details Object type \em client_identification_response.
 */

#ifndef TA_CLIENT_IDENTIFICATION_RESPONSE_H
#define TA_CLIENT_IDENTIFICATION_RESPONSE_H

#include "common/object.h"
#include "common/boolean.h"
#include "constants/transaction_type.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Saldo amount if present.
 * 
 * \param[in] response Object instance of type [client_identification_response](\ref client_identification_response.h).
 * \param[out] amount_saldo Pointer to variable to write object instance to. Object
 *                          instance is of type [amount](\ref amount.h) and is not retained. Object
 *                          instance is \em ta_object_invalid if value is not set
 *                          in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount_saldo.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [client_identification_response](\ref client_identification_response.h).
 * \retval ta_c_rc_invalid_argument \em amount_saldo is \em null-pointer.
 */
extern ta_e_result_code_t ta_client_identification_response_get_amount_saldo(
	ta_object_t response,
	ta_object_t* amount_saldo );

/**
 * \brief Information about completed transaction.
 * 
 * \param[in] response Object instance of type [client_identification_response](\ref client_identification_response.h).
 * \param[out] transaction_information Pointer to variable to write object instance to. Object
 *                                     instance is of type [transaction_information](\ref transaction_information.h) and is
 *                                     not retained. Object instance is \em ta_object_invalid
 *                                     if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em transaction_information.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [client_identification_response](\ref client_identification_response.h).
 * \retval ta_c_rc_invalid_argument \em transaction_information is \em null-pointer.
 */
extern ta_e_result_code_t ta_client_identification_response_get_transaction_information(
	ta_object_t response,
	ta_object_t* transaction_information );

/**
 * \brief Information about payment card used by the cardholder if present.
 * 
 * \param[in] response Object instance of type [client_identification_response](\ref client_identification_response.h).
 * \param[out] card_data Pointer to variable to write object instance to. Object
 *                       instance is of type [card_data](\ref card_data.h) and is not retained. Object
 *                       instance is \em ta_object_invalid if value is not set
 *                       in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_data.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [client_identification_response](\ref client_identification_response.h).
 * \retval ta_c_rc_invalid_argument \em card_data is \em null-pointer.
 */
extern ta_e_result_code_t ta_client_identification_response_get_card_data(
	ta_object_t response,
	ta_object_t* card_data );


#ifdef __cplusplus
}
#endif

#endif
