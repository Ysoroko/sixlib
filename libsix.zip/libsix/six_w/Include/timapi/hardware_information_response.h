/**
 * \file
 * \brief Contains the result of calling ta_terminal_hardware_information
 *        or ta_terminal_hardware_information_async.
 * \details Object type \em hardware_information_response.
 */

#ifndef TA_HARDWARE_INFORMATION_RESPONSE_H
#define TA_HARDWARE_INFORMATION_RESPONSE_H

#include "common/object.h"
#include "common/boolean.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief List of hardware attached to the EFT Terminal..
 * 
 * \param[in] response Object instance of type [hardware_information_response](\ref hardware_information_response.h).
 * \param[out] hardwares Pointer to variable to write object instance to. Object instance
 *                       is of type [list](\ref list.h) and is not retained. The list contains elements
 *                       of type [hardware](\ref hardware.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em hardwares.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [hardware_information_response](\ref hardware_information_response.h).
 * \retval ta_c_rc_invalid_argument \em hardwares is \em null-pointer.
 */
extern ta_e_result_code_t ta_hardware_information_response_get_hardwares(
	ta_object_t response,
	ta_object_t* hardwares );

/**
 * \brief Kernel versions supported by the EFT Terminal.
 * 
 * \param[in] response Object instance of type [hardware_information_response](\ref hardware_information_response.h).
 * \param[out] kernel_versions Pointer to variable to write object instance to. Object instance
 *                             is of type [map](\ref map.h) and is not retained. The map contains keys
 *                             of type [integer](\ref integer.h) and values of type [string](\ref string.h). The keys
 *                             match values from \em ta_e_kernel_type_t. The values are the
 *                             string version of the kernel.
 * 
 * \retval ta_c_rc_ok Object instance written to \em kernel_versions.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [hardware_information_response](\ref hardware_information_response.h).
 * \retval ta_c_rc_invalid_argument \em kernel_versions is \em null-pointer.
 */
extern ta_e_result_code_t ta_hardware_information_response_get_kernel_versions(
	ta_object_t response,
	ta_object_t* kernel_versions );

/**
 * \brief Settings supported by the EFT Terminal.
 * 
 * \param[in] response Object instance of type [hardware_information_response](\ref hardware_information_response.h).
 * \param[out] settings Pointer to variable to write object instance to. Object instance
 *                      is of type [map](\ref map.h) and is not retained. The map contains keys
 *                      of type [integer](\ref integer.h) and values of type [string](\ref string.h). The keys
 *                      match values from \em ta_e_setting_type_t.
 * 
 * \retval ta_c_rc_ok Object instance written to \em settings.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [hardware_information_response](\ref hardware_information_response.h).
 * \retval ta_c_rc_invalid_argument \em settings is \em null-pointer.
 */
extern ta_e_result_code_t ta_hardware_information_response_get_settings(
	ta_object_t response,
	ta_object_t* settings );

/**
 * \brief Hardware statistics.
 * 
 * \param[in] response Object instance of type [hardware_information_response](\ref hardware_information_response.h).
 * \param[out] statistics Pointer to variable to write object instance to. Object instance
 *                        is of type [map](\ref map.h) and is not retained. The map contains keys
 *                        and values both of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em statistics.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [hardware_information_response](\ref hardware_information_response.h).
 * \retval ta_c_rc_invalid_argument \em statistics is \em null-pointer.
 */
extern ta_e_result_code_t ta_hardware_information_response_get_statistics(
	ta_object_t response,
	ta_object_t* statistics );

/**
 * \brief Charging level of the battery as a percentage value of the total charge.
 * 
 * 0% is defined as the amount of charge where the device performs an automatic shutdown.
 * 100% is a full charge.
 * 
 * \param[in] response Object instance of type [hardware_information_response](\ref hardware_information_response.h).
 * \param[out] level Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em statistics.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [hardware_information_response](\ref hardware_information_response.h).
 * \retval ta_c_rc_invalid_argument \em statistics is \em null-pointer.
 */
extern ta_e_result_code_t ta_hardware_information_response_get_battery_level(
	ta_object_t response,
	int* level );

/**
 * \brief Indicates whether the batterie is being charged i.e. the device is plugged in.
 * 
 * true: Plugged in
 * false: Not plugged in
 * 
 * \param[in] response Object instance of type [hardware_information_response](\ref hardware_information_response.h).
 * \param[out] charging Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em statistics.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [hardware_information_response](\ref hardware_information_response.h).
 * \retval ta_c_rc_invalid_argument \em statistics is \em null-pointer.
 */
extern ta_e_result_code_t ta_hardware_information_response_get_battery_charging(
	ta_object_t response,
	ta_e_boolean_t* charging );


#ifdef __cplusplus
}
#endif

#endif
