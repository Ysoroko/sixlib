/**
 * \file
 * \brief Transaction information.
 * \details Object type \em transaction_information.
 */

#ifndef TA_TRANSACTION_INFORMATION_H
#define TA_TRANSACTION_INFORMATION_H

#include "common/object.h"
#include "common/boolean.h"
#include "common/integer.h"
#include "constants/pos_entry_mode.h"
#include "constants/cvm.h"
#include "constants/merchant_action.h"
#include "constants/age_check_result.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief According to EMV definition.
 * 
 * Mandatory for:
 * - ta_c_tt_activate_card
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase
 * - ta_c_tt_refunding
 * - ta_c_tt_unload
 * .
 *
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_reservation
 * .
 *
 * Forbidden (always ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_reversal
 * .
 * 
 * \param[in] trx_info Object instance of type [transaction_information](\ref transaction_information.h).
 * \param[out] pos_entry_mode Pointer to variable to write value to. Value is
 *                            \em ta_c_pem_undefined if value is not set in \em trx_info.
 * 
 * \retval ta_c_rc_ok Value written to \em pos_entry_mode.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em pos_entry_mode is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_pos_entry_mode(
	ta_object_t trx_info,
	ta_e_pos_entry_mode_t* pos_entry_mode );

/**
 * \brief Cardholder verification method.
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_activate_card
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_purchase
 * - ta_c_tt_reservation
 * - ta_c_tt_unload
 * .
 *
 * Forbidden (always ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_credit
 * - ta_c_tt_load
 * - ta_c_tt_refunding
 * - ta_c_tt_reversal
 * .
 * 
 * \param[in] trx_info Value written of type [transaction_information](\ref transaction_information.h).
 * \param[out] cvm Pointer to variable to write value to. Value is
 *                 \em ta_c_cvm_undefined if value is not set in \em trx_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em cvm.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em cvm is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_cvm(
	ta_object_t trx_info,
	ta_e_cvm_t* cvm );

/**
 * \brief Feedback to know which merchant action has to be performed.
 * 
 * Mandatory for:
 * - ta_c_tt_activate_card
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load_voucher
 * - ta_c_tt_load
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_purchase
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * .
 *
 * Forbidden (always ta_object_invalid):
 * - ta_c_tt_account_verification
 * .
 * 
 * \param[in] trx_info Object instance of type [transaction_information](\ref transaction_information.h).
 * \param[out] merchant_action Pointer to variable to write value to. Value is
 *                             \em ta_c_ma_undefined if value is not set in \em trx_info.
 * 
 * \retval ta_c_rc_ok Value written written to \em merchant_action.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em merchant_action is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_merchant_action(
	ta_object_t trx_info,
	ta_e_merchant_action_t* merchant_action );

/**
 * \brief Authorization code received from the acquirer.
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_activate_card
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load_voucher
 * - ta_c_tt_load
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_purchase
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_unload
 * .
 *
 * Forbidden (always ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_reversal
 * .
 * 
 * \param[in] trx_info Object instance of type [transaction_information](\ref transaction_information.h).
 * \param[out] auth_code Pointer to variable to write object instance to. Object
 *                       instance is of type [string](\ref string.h) and is not retained. Object
 *                       instance is \em ta_object_invalid if value is not set
 *                       in \em trx_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em auth_code.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em auth_code is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_auth_code(
	ta_object_t trx_info,
	ta_object_t* auth_code );

/**
 * \brief Local time of the transaction.
 * 
 * Mandatory for:
 * - ta_c_tt_activate_card
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load_voucher
 * - ta_c_tt_load
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_purchase
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * .
 *
 * Forbidden (always ta_object_invalid):
 * - ta_c_tt_account_verification
 * .
 * \param[in] trx_info Object instance of type [transaction_information](\ref transaction_information.h).
 * \param[out] time_stamp Pointer to variable to write object instance to. Object
 *                        instance is of type [timedate](\ref timedate.h) and is not retained. Object
 *                        instance is \em ta_object_invalid if value is not set
 *                        in \em trx_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em time_stamp.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em time_stamp is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_time_stamp(
	ta_object_t trx_info,
	ta_object_t* time_stamp );

/**
 * \brief Transaction reference defined by the terminal.
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_activate_card
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_purchase
 * - ta_c_tt_refunding
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * .
 *
 * Forbidden (always ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_collect_points
 * - ta_c_tt_load_voucher
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_reservation
 * .
 * 
 * \param[in] trx_info Object instance of type [transaction_information](\ref transaction_information.h).
 * \param[out] trans_ref Pointer to variable to write object instance to. Object
 *                       instance is of type [integer](\ref integer.h) and is not retained. Object
 *                       instance is \em ta_object_invalid if value is not set
 *                       in \em trx_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em trans_ref.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em trans_ref is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_trans_ref(
	ta_object_t trx_info,
	ta_object_t* trans_ref );

/**
 * \brief Transaction sequence number defined by the terminal.
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_activate_card
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_purchase
 * - ta_c_tt_refunding
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * .
 *
 * Forbidden (always ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_collect_points
 * - ta_c_tt_load_voucher
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_reservation
 * .
 * 
 * \param[in] trx_info Object instance of type [transaction_information](\ref transaction_information.h).
 * \param[out] trans_seq Pointer to variable to write object instance to. Object
 *                       instance is of type [integer](\ref integer.h) and is not retained. Object
 *                       instance is \em ta_object_invalid if value is not set
 *                       in \em trx_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em trans_seq.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em trans_seq is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_trans_seq(
	ta_object_t trx_info,
	ta_object_t* trans_seq );

/**
 * \brief TransactionAcquirer identifier.
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_activate_card
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_purchase
 * - ta_c_tt_refunding
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * .
 *
 * Forbidden (always ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_collect_points
 * - ta_c_tt_load_voucher
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_reservation
 * .
 * 
 * \param[in] trx_info Value written of type [transaction_information](\ref transaction_information.h).
 * \param[out] acq Pointer to variable to write value to. Value is
 *                 0 if value is not set in \em trx_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em acq.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em acq is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_acq_id(
	ta_object_t trx_info,
	int64_t* acq );

/**
 * \deprecated Use ta_transaction_information_get_acq_id.
 */
extern ta_e_result_code_t ta_transaction_information_get_acq( ta_object_t trx_info, int64_t* acq );

/**
 * \brief Signature captured by EFT Terminal if present.
 * 
 * Mandatory for:
 * - ta_c_tt_load_voucher
 * .
 *
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_activate_card
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_purchase
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * .
 *
 * Forbidden (always ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_collect_points
 * .
 * 
 * \param[in] trx_info Object instance of type [transaction_information](\ref transaction_information.h).
 * \param[out] signature_information Pointer to variable to write object instance to. Object
 *                                   instance is of type [signature_information](\ref signature_information.h) and is not
 *                                   retained. Object instance is \em ta_object_invalid if
 *                                   value is not set in \em trx_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em signature_information.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em signature_information is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_signature_information(
	ta_object_t trx_info,
	ta_object_t* signature_information );

/**
 * \brief Transaction reference from the terminal.
 * 
 * Mandatory for:
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_collect_points
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_reservation
 * .
 *
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_activate_card
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load_voucher
 * - ta_c_tt_load
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_purchase
 * - ta_c_tt_refunding
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * .
 *
 * Forbidden (always ta_object_invalid):
 * - ta_c_tt_account_verification
 * .
 * 
 * \param[in] trx_info Object instance of type [transaction_information](\ref transaction_information.h).
 * \param[out] trm_trans_ref Pointer to variable to write object instance to. Object
 *                           instance is of type [string](\ref string.h) and is not retained. Object
 *                           instance is \em ta_object_invalid if value is not set
 *                           in \em trx_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em trm_trans_ref.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em trm_trans_ref is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_trm_trans_ref(
	ta_object_t trx_info,
	ta_object_t* trm_trans_ref );

/**
 * \brief Transaction reference from the acquirer.
 * 
 * Mandatory for:
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_reservation
 * .
 *
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_activate_card
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load_voucher
 * - ta_c_tt_load
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_purchase
 * - ta_c_tt_refunding
 * - ta_c_tt_unload
 * .
 *
 * Forbidden (always ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_reversal
 * .
 * 
 * \param[in] trx_info Object instance of type [transaction_information](\ref transaction_information.h).
 * \param[out] acq_trans_ref Pointer to variable to write object instance to. Object
 *                           instance is of type [string](\ref string.h) and is not retained. Object
 *                           instance is \em ta_object_invalid if value is not set
 *                           in \em trx_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em acq_trans_ref.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em acq_trans_ref is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_acq_trans_ref(
	ta_object_t trx_info,
	ta_object_t* acq_trans_ref );

/**
 * \brief SIX Transaction Reference.
 * 
 * \param[in] trx_info Object instance of type [transaction_information](\ref transaction_information.h).
 * \param[out] six_trx_ref_num Pointer to variable to write object instance to. Object
 *                             instance is of type [string](\ref string.h) and is not retained. Object
 *                             instance is \em ta_object_invalid if value is not set
 *                             in \em trx_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em six_trx_ref_num.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em six_trx_ref_num is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_six_trx_ref_num(
	ta_object_t trx_info,
	ta_object_t* six_trx_ref_num );

/**
 * \brief Cardholder name.
 * 
 * \deprecated Use ta_card_data_get_cardholder instead (on card_data object returned by ta_transaction_response_get_card_data). 
 * 
 * Optional: Mandatory if requested by acquirer.
 * Specifications: \em Banking, \em AustrianUseCases.
 * 
 * \param[in] trx_info Object instance of type [transaction_information](\ref transaction_information.h).
 * \param[out] cardholder_name Pointer to variable to write object instance to. Object
 *                             instance is of type [string](\ref string.h) and is not retained. Object
 *                             instance is \em ta_object_invalid if value is not set
 *                             in \em trx_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em cardholder_name.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em cardholder_name is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_cardholder_name(
	ta_object_t trx_info,
	ta_object_t* cardholder_name );

/**
 * \brief Cardholder ID- or Passport number.
 * 
 * Optional: Mandatory if requested by acquirer.
 * Specifications: \em Banking, \em AustrianUseCases.
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_giro
 * - ta_c_tt_purchase
 * - ta_c_tt_reversal
 * .
 *
 * Otherwise Forbidden (always ta_object_invalid)
 * 
 * \param[in] trx_info Object instance of type [transaction_information](\ref transaction_information.h).
 * \param[out] client_identifier Pointer to variable to write object instance to. Object
 *                               instance is of type [string](\ref string.h) and is not retained. Object
 *                               instance is \em ta_object_invalid if value is not set
 *                               in \em trx_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em client_identifier.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em client_identifier is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_client_identifier(
	ta_object_t trx_info,
	ta_object_t* client_identifier );

/**
 * \brief Account number of the card used.
 * 
 * Optional: Mandatory if requested by acquirer.
 * Specifications: \em Banking, \em AustrianUseCases.
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_giro
 * - ta_c_tt_purchase
 * - ta_c_tt_reversal
 * .
 *
 * Otherwise Forbidden (always ta_object_invalid)
 * 
 * \param[in] trx_info Object instance of type [transaction_information](\ref transaction_information.h).
 * \param[out] account_number Pointer to variable to write object instance to. Object
 *                            instance is of type [string](\ref string.h) and is not retained. Object
 *                            instance is \em ta_object_invalid if value is not set
 *                            in \em trx_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em account_number.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em account_number is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_account_number(
	ta_object_t trx_info,
	ta_object_t* account_number );

/**
 * \brief Person OID.
 * 
 * Optional: Mandatory if requested by acquirer.
 * Specifications: \em Banking, \em AustrianUseCases.
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_giro
 * - ta_c_tt_purchase
 * - ta_c_tt_reversal
 * .
 *
 * Otherwise Forbidden (always ta_object_invalid)
 * 
 * \param[in] trx_info Object instance of type [transaction_information](\ref transaction_information.h).
 * \param[out] person_oid Pointer to variable to write object instance to. Object
 *                        instance is of type [integer](\ref integer.h) and is not retained. Object
 *                        instance is \em ta_object_invalid if value is not set
 *                        in \em trx_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em person_oid.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em person_oid is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_person_oid(
	ta_object_t trx_info,
	ta_object_t* person_oid );

/**
 * \brief Card ID.
 * 
 * Optional: Mandatory if requested by acquirer.
 * Specifications: \em Banking, \em AustrianUseCases.
 * 
 * \param[in] trx_info Object instance of type [transaction_information](\ref transaction_information.h).
 * \param[out] card_id Pointer to variable to write object instance to. Object
 *                     instance is of type [integer](\ref integer.h) and is not retained. Object
 *                     instance is \em ta_object_invalid if value is not set
 *                     in \em trx_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_id.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em card_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_card_id(
	ta_object_t trx_info,
	ta_object_t* card_id );

/**
 * \brief Indicates if a transaction was performed as non guaranteed payment (NGV). 
 * 
 * Available if \em AustrianUseCases is enabled.
 * 
 * \param[in] trx_info Object instance of type [transaction_information](\ref transaction_information.h).
 * \param[out] ngv_used_flag Pointer to variable to write value to. Value is
 *                           \em ta_c_b_undefined if value is not set in \em trx_info.
 * 
 * \retval ta_c_rc_ok Value written to \em ngv_used_flag.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em ngv_used_flag is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_ngv_used_flag(
	ta_object_t trx_info,
	ta_e_boolean_t* ngv_used_flag );

/**
 * \brief Omnichannel payment / transaction identifier.
 * 
 * Optional: Mandatory if available to terminal.
 * Specifications: retail, banking, austrianUseCases.
 * 
 * \param[in] trx_info Object instance of type [transaction_information](\ref transaction_information.h).
 * \param[out] omnichannel_payment_id Pointer to variable to write object instance to. Object
 *                                    instance is of type [string](\ref string.h) and is not retained. Object
 *                                    instance is \em ta_object_invalid if value is not set in \em trx_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_id.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em omnichannel_payment_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_omnichannel_payment_id(
	ta_object_t trx_info,
	ta_object_t* omnichannel_payment_id );

/**
 * \brief Used for "Stored Credential" and the "Merchant-Initiated-Transaction (MIT) frameworks.
 * 
 * Card scheme data element that links original authorisation requests to subsequent messages.
 * 
 * Used also for Initial recurring and omnichannel use cases.
 * 
 * Optional: Mandatory if available to terminal.
 * Specifications: retail, banking, austrianUseCases.
 * 
 * \param[in] trx_info Object instance of type [transaction_information](\ref transaction_information.h).
 * \param[out] scheme_trx_id Pointer to variable to write object instance to. Object
 *                           instance is of type [integer](\ref integer.h) and is not retained. Object
 *                           instance is \em ta_object_invalid if value is not set in \em trx_info.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_id.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em scheme_trx_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_scheme_trx_id(
	ta_object_t trx_info,
	ta_object_t* scheme_trx_id );

/**
 * \brief Get Age Check Result.
 * 
 * Optional: Mandatory if available to terminal.
 * Specifications: valueAddedServices.
 * 
 * \param[in] trx_info Object instance of type [transaction_information](\ref transaction_information.h).
 * \param[out] age_check_result Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_id.
 * \retval ta_c_rc_invalid_argument \em trx_info is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_info is not of type [transaction_information](\ref transaction_information.h).
 * \retval ta_c_rc_invalid_argument \em age_check_result is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_information_get_age_check_result(
	ta_object_t trx_info,
	ta_e_age_check_result_t* age_check_result );

#ifdef __cplusplus
}
#endif

#endif
