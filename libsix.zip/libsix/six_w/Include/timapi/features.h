/**
 * \file
 * \brief Terminal Features.
 */

#ifndef TA_FEATURES_H
#define TA_FEATURES_H

#include "common/boolean.h"
#include "constants/feature_support.h"
#include "constants/protocol_level.h"


#ifdef __cplusplus
extern "C" {
#endif

/** \brief Hardware features supported by terminal. */
typedef struct ta_s_features_hardware {
	/** \brief The device has a cardholder display. */
	ta_e_boolean_t cardholder_display;
	
	/** \brief The device has a merchant display. */
	ta_e_boolean_t merchant_display;
	
	/** \brief The device has a printer. */
	ta_e_boolean_t printer;
	
	/** \brief The display brightness can be set. */
	ta_e_boolean_t display_brightness;
	
	/** \brief The display contrast can be set. */
	ta_e_boolean_t display_contrast;
	
	/** \brief The alert tones can be set. */
	ta_e_boolean_t alert_tones;
	
	/** \brief The keypad tones can be set. */
	ta_e_boolean_t keypad_tones;
	
	/** \brief Power management supported by hardware. */
	ta_e_boolean_t power_management;
} ta_s_features_hardware_t;


/** \brief Age check support. */
typedef enum ta_e_age_check_support{
	/** \brief Age check is not supported. */
	ta_c_acs_not_supported = 0,
	
	/** \brief Age check is only supported using Terminal.ageCheck() method. */
	ta_c_acs_only_age_check = 1,
	
	/**
	 * \brief Age check is supported using Terminal.ageCheck() and in transactions
	 *        using ta_transaction_data_set_age_to_check.
	 */
	ta_c_acs_transaction_age_check = 2
} ta_e_age_check_support_t;

/** \brief Payment features supported by terminal. */
typedef struct ta_s_features_payment {
	/** \brief DCC support. */
	ta_e_boolean_t dcc;
	
	/** \brief Support for "Declined Receipts". */
	ta_e_boolean_t declined_receipts;
	
	/** \brief Support for "Partial Approval". */
	ta_e_boolean_t partial_approval;
	
	/** \brief Support for "Partial Commit". */
	ta_e_boolean_t partial_commit;
	
	/** \brief EP2 payment protocol is available on the terminal. */
	ta_e_boolean_t ep2_available;
	
	/** \brief DCC support on EP2 brands. */
	ta_e_boolean_t ep2_dcc;
	
	/** \brief Support for "Declined Receipts" on EP2 brands. */
	ta_e_boolean_t ep2_declined_receipts;
	
	/** \brief Support for multiple account selection. */
	ta_e_boolean_t ep2_multi_account_selection;
	
	/** \brief Support for multiple contract selection. */
	ta_e_boolean_t ep2_multi_contract_selection;
	
	/** \brief Support for installment. */
	ta_e_boolean_t ep2_installment;
	
	/** \brief Support for giftcard functions. */
	ta_e_boolean_t ep2_giftcard;
	
	/** \brief Account selection. */
	ta_e_boolean_t account_selection;
	
	/** \brief Support merchant choice routing. */
	ta_e_boolean_t mcr;
	
	/** \brief Support surcharge. */
	ta_e_boolean_t surcharge;
	
	/** \brief Age check support. */
	ta_e_age_check_support_t ep2_age_check;
} ta_s_features_payment_t;


/** \brief SIXml features supported by terminal. */
typedef struct ta_s_features_sixml {
	/**
	 * \brief Supported SIXml administrative functions.
	 * 
	 * \see ta_e_admin_functions_t.
	 */
	int admin_functions;
	
	/** \brief AutoCommit support. */
	ta_e_feature_support_t auto_commit;
	
	/** \brief AutoShiftManagement support. */
	ta_e_feature_support_t auto_shift_management;
	
	/** \brief AutoShutterManagement support. */
	ta_e_feature_support_t auto_shutter_management;
	
	/** \brief Request repetition support. */
	ta_e_boolean_t request_repetitition;
	
	/**
	 * \brief Supported SIXml financial transaction functions.
	 * 
	 * \see ta_e_financial_transactions_t.
	 */
	int financial_functions;
	
	/**
	 * \brief Supported SIXml guides.
	 * 
	 * \see ta_e_guides_t.
	 */
	int guides;
	
	/**
	 * \brief Supported SIXml non-financial transaction functions.
	 * 
	 * \see ta_e_non_financial_transactions_t.
	 */
	int non_financial_functions;
	
	/** \brief Highest supported protocol levels. */
	ta_e_protocol_level_t protocol_level;
	
	/** \brief SleepTimer support. */
	ta_e_boolean_t sleep_timer;
	
	/**
	 * \brief Supported SIXml status functions.
	 * 
	 * \see ta_e_status_functions_t.
	 */
	int status_functions;
	
	/**
	 * \brief Supported SIXml dialog functions.
	 * 
	 * \see ta_e_dialog_functions_t.
	 */
	int dialog_functions;
	
	/** \brief Supports allow closed card insertion. */
	ta_e_boolean_t allow_closed_card_insertion;
	
	/** \brief Support for fast notification mode. */
	ta_e_boolean_t fast_ntf_mode;
	
	/**
	 * \brief Support if the SIXml session should start in the default Closed management state
	 *        or the last known management state (e.g. before a reboot) should be used.
	 * 
	 * For the latter option the terminal shall indicate the state in the login response.
	 */
	ta_e_boolean_t persistent_state;
	
	/**
	 * \brief EP2 referenced transaction supported.
	 */
	ta_e_boolean_t ep2_referenced_transaction;
	
	/**
	 * \brief Payment Protocol EP2 Deferred Authorisation Feature.
	 */
	ta_e_boolean_t ep2_deferred_authorisation;
	
	/**
	 * \brief Payment Deferred Authorisation Feature.
	 */
	ta_e_boolean_t deferred_authorisation;
	
	/**
	 * \brief EP2 Payment Credential on File Feature.
	 */
	ta_e_boolean_t ep2_credential_on_file;

	/**
	 * \brief Payment Credential on File Feature.
	 */
	ta_e_boolean_t credential_on_file;
	
	/**
	 * \brief Supported SIXml remote functions.
	 * 
	 * \see ta_e_remote_functions_t.
	 */
	int remote_functions;
	
	/** \brief Custom init transaction screen supported. */
	ta_e_boolean_t custom_init_trx_screen;
	
	/** \brief Wake up support. */
	ta_e_boolean_t wake_up;
	
	/** \brief The device supports long (90 char) EcrInfo values. */
	ta_e_boolean_t long_ecr_info_supported;
	
	/** \brief The device supports software update information. */
	ta_e_boolean_t sw_update_information;
	
	/**
	 * \brief Supported Third Party Apps.
	 * 
	 * \see ta_e_third_party_apps_t.
	 */
	int third_party_apps;
} ta_s_features_sixml_t;


/** \brief Features supported by terminal. */
typedef struct ta_s_features {
	/** \brief Hardware features. */
	ta_s_features_hardware_t hardware;
	
	/** \brief Payment features. */
	ta_s_features_payment_t payment;
	
	/** \brief SIXml features. */
	ta_s_features_sixml_t sixml;
} ta_s_features_t;

#ifdef __cplusplus
}
#endif

#endif

