/**
 * \file
 * \brief Contains VAS information list.
 * \details Object type \em vas_information_list.
 */

#ifndef TA_VAS_INFORMATION_LIST_H
#define TA_VAS_INFORMATION_LIST_H

#include "common/object.h"
#include "common/boolean.h"
#include "constants/vas_info_list_type.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create vas information list.
 * 
 * \param[out] vas_information_list Pointer to variable to write created object instance to.
 *                        Created object instance is retained.
 * \param[in] vas_info_list_type Vas information list type.
 * \param[in] vas_information Object instance is of type [map](\ref map.h) and is retained.
 *                            The map contains keys of type [integer](\ref integer.h) and values
 *                            of type [string](\ref string.h) (binary data).
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em vas_information_list.
 * \retval ta_c_rc_invalid_argument \em vas_information_list is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em vas_information is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em vas_information is not of type
 *                                  [map](\ref map.h).
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_vas_information_list_create(
	ta_object_t *vas_information_list,
	ta_e_vas_info_list_type_t vas_info_list_type,
	ta_object_t vas_information );


/**
 * \brief VAS information list type.
 * 
 * \param[in] vas_information_list Object instance of type [vas_information_list](\ref vas_information_list.h).
 * \param[out] type Pointer to variable to write type to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em vas_informations.
 * \retval ta_c_rc_invalid_argument \em vas_information_list is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em vas_information_list is not of type
 *                                  [vas_information_list](\ref vas_information_list.h).
 * \retval ta_c_rc_invalid_argument \em type is \em null-pointer.
 */
extern ta_e_result_code_t ta_vas_information_list_get_vas_info_list_type(
	ta_object_t vas_information_list,
	ta_e_vas_info_list_type_t* type );

/**
 * \brief Map of VAS information.
 * 
 * \param[in] vas_information_list Object instance of type [vas_information_list](\ref vas_information_list.h).
 * \param[out] vas_information Pointer to variable to write object instance to. Object instance
 *                             is of type [map](\ref map.h) and is not retained. The map contains
 *                             keys of type [integer](\ref integer.h) and values of type
 *                             [string](\ref string.h) (binary data). If list is not
 *                             present \em ta_object_invalid is written.
 * 
 * \retval ta_c_rc_ok Object instance written to \em vas_informations.
 * \retval ta_c_rc_invalid_argument \em vas_information_list is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em vas_information_list is not of type
 *                                  [vas_information_list](\ref vas_information_list.h).
 * \retval ta_c_rc_invalid_argument \em vas_information is \em null-pointer.
 */
extern ta_e_result_code_t ta_vas_information_list_get_vas_information(
	ta_object_t vas_information_list,
	ta_object_t* vas_information );

#ifdef __cplusplus
}
#endif

#endif
