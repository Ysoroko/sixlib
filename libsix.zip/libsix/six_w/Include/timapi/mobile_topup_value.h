/**
 * \file
 * \brief Contains the name of a mobile topup issuer and an associated voucher value.
 * \details Object type \em mobile_topup_value.
 */

#ifndef TA_MOBILE_TOPUP_VALUE_H
#define TA_MOBILE_TOPUP_VALUE_H

#include "common/object.h"
#include "common/boolean.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create object of type [mobile_topup_value](\ref mobile_topup_value.h).
 * 
 * \param[out] value Pointer to variable to write created object instance to.
 *                  Created object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em value.
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_mobile_topup_value_create(
	ta_object_t* value );

/**
 * \brief Create deep copy of object instance of type [mobile_topup_value](\ref mobile_topup_value.h).
 * 
 * \param[out] value Pointer to variable to write created object instance to.
 *                  Created object instance is retained.
 * \param[in] source_value Object of type [mobile_topup_value](\ref mobile_topup_value.h) to create copy of.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em value.
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em source_item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em source_item is not of type [mobile_topup_value](\ref mobile_topup_value.h).
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_mobile_topup_value_copy(
	ta_object_t* value,
	const ta_object_t* source_value );



/**
 * \brief Contains the name of an issuer off (mobile topup) vouchers.
 * 
 * Optional: For brand name based Mobile Topup transactions.
 * 
 * \param[in] value Object instance of type [mobile_topup_value](\ref mobile_topup_value.h).
 * \param[out] issuer_name Pointer to variable to write object instance to. Object instance is
 *                         of type [string](\ref string.h) and is not retained. Object instance is
 *                         \em ta_object_invalid if value is not set in \em mobile_topup_value.
 * 
 * \retval ta_c_rc_ok Object instance written to \em issuer_name.
 * \retval ta_c_rc_invalid_argument \em value is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em value is not of type [mobile_topup_value](\ref mobile_topup_value.h).
 * \retval ta_c_rc_invalid_argument \em issuer_name is not \em null-pointer.
 */
extern ta_e_result_code_t ta_mobile_topup_value_get_issuer_name(
	ta_object_t value,
	ta_object_t *issuer_name );

/**
 * \brief Contains the name of an issuer off (mobile topup) vouchers.
 * 
 * Optional: For brand name based Mobile Topup transactions.
 * 
 * \param[in] value Object instance of type [mobile_topup_value](\ref mobile_topup_value.h).
 * \param[in] issuer_name Object instance to set. Object instance can be \em ta_object_invalid
 *                        to clear the value in \em value. If object instance is not
 *                        ta_object_invalid is has to be of type [integer](\ref integer.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em value.
 * \retval ta_c_rc_invalid_argument \em value is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em value is not of type [mobile_topup_value](\ref mobile_topup_value.h).
 * \retval ta_c_rc_invalid_argument \em issuer_name is not \em ta_object_invalid and
 *                                  is not of type [integer](\ref integer.h).
 */
extern ta_e_result_code_t ta_mobile_topup_value_set_issuer_name(
	ta_object_t value,
	ta_object_t issuer_name );



/**
 * \brief Reference number provided and created for the card.
 * 
 * Optional: For PAN based Mobile Topup transactions. Send type 06 Non-PCI-PAN.
 * 
 * \param[in] value Object instance of type [mobile_topup_value](\ref mobile_topup_value.h).
 * \param[out] card_ref Pointer to variable to write object instance to. Object instance is
 *                      of type [string](\ref string.h) and is not retained. Object instance is
 *                      \em ta_object_invalid if value is not set in \em value.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_ref.
 * \retval ta_c_rc_invalid_argument \em value is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em value is not of type [mobile_topup_value](\ref mobile_topup_value.h).
 * \retval ta_c_rc_invalid_argument \em card_ref is not \em null-pointer.
 */
extern ta_e_result_code_t ta_mobile_topup_value_get_card_ref(
	ta_object_t value,
	ta_object_t *card_ref );

/**
 * \brief Reference number provided and created for the card.
 * 
 * Optional: For PAN based Mobile Topup transactions. Send type 06 Non-PCI-PAN.
 * 
 * \param[in] value Object instance of type [mobile_topup_value](\ref mobile_topup_value.h).
 * \param[in] card_ref Object instance to set. Object instance can be \em ta_object_invalid
 *                     to clear the value in \em value. If object instance is not
 *                     ta_object_invalid is has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em value.
 * \retval ta_c_rc_invalid_argument \em value is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em value is not of type [mobile_topup_value](\ref mobile_topup_value.h).
 * \retval ta_c_rc_invalid_argument \em card_ref is not \em ta_object_invalid and is not of
 *                                  type \em string.
 */
extern ta_e_result_code_t ta_mobile_topup_value_set_card_ref(
	ta_object_t value,
	ta_object_t card_ref );



/**
 * \brief Application expiration date.
 * 
 * Each application on a card has a corresponding expiration date and can be read from
 * the card. Optional: For PAN based Mobile Topup transactions. Needs to be present if
 * CardRef is present.
 * 
 * \param[in] value Object instance of type [mobile_topup_value](\ref mobile_topup_value.h).
 * \param[out] app_expiration_date Pointer to variable to write object instance to. Object instance is
 *                                 of type [timedate](\ref timedate.h) and is not retained. Object instance is
 *                                 \em ta_object_invalid if value is not set in \em value.
 * 
 * \retval ta_c_rc_ok Object instance written to \em app_expiration_date.
 * \retval ta_c_rc_invalid_argument \em value is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em value is not of type [mobile_topup_value](\ref mobile_topup_value.h).
 * \retval ta_c_rc_invalid_argument \em app_expiration_date is not \em null-pointer.
 */
extern ta_e_result_code_t ta_mobile_topup_value_get_app_expiration_date(
	ta_object_t value,
	ta_object_t *app_expiration_date );

/**
 * \brief Application expiration date.
 * 
 * Each application on a card has a corresponding expiration date and can be read from
 * the card. Optional: For PAN based Mobile Topup transactions. Needs to be present if
 * CardRef is present.
 * 
 * \param[in] value Object instance of type [mobile_topup_value](\ref mobile_topup_value.h).
 * \param[in] app_expiration_date Object instance to set. Object instance can be \em ta_object_invalid
 *                                to clear the value in \em value. If object instance is not
 *                                ta_object_invalid is has to be of type [timedate](\ref timedate.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em value.
 * \retval ta_c_rc_invalid_argument \em value is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em value is not of type [mobile_topup_value](\ref mobile_topup_value.h).
 * \retval ta_c_rc_invalid_argument \em app_expiration_date is not \em ta_object_invalid and is not of
 *                                  type \em timedate.
 */
extern ta_e_result_code_t ta_mobile_topup_value_set_app_expiration_date(
	ta_object_t value,
	ta_object_t app_expiration_date );



/**
 * \brief In a request defines the original amount for the transaction (given by ECR).
 * 
 * In response the final authorized amount (given by host) in minor units.
 * 
 * \param[in] value Object instance of type [mobile_topup_value](\ref mobile_topup_value.h).
 * \param[out] amount Pointer to variable to write object instance to. Object instance is
 *                    of type [list](\ref list.h) with entries of type [amount](\ref amount.h)
 *                    and is not retained. Object instance is \em ta_object_invalid if value
 *                    is not set in \em value.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount.
 * \retval ta_c_rc_invalid_argument \em value is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em value is not of type [mobile_topup_value](\ref mobile_topup_value.h).
 * \retval ta_c_rc_invalid_argument \em amount is not \em null-pointer.
 */
extern ta_e_result_code_t ta_mobile_topup_value_get_amount(
	ta_object_t value,
	ta_object_t *amount );

/**
 * \brief In a request defines the original amount for the transaction (given by ECR).
 * 
 * In response the final authorized amount (given by host) in minor units.
 * 
 * \param[in] value Object instance of type [mobile_topup_value](\ref mobile_topup_value.h).
 * \param[in] amount Object instance to set. Object instance can be \em ta_object_invalid
 *                   to clear the value in \em value. If object instance is not
 *                   ta_object_invalid is has to be of type [list](\ref list.h) with entries
 *                   of type [amount](\ref amount.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em value.
 * \retval ta_c_rc_invalid_argument \em value is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em value is not of type [mobile_topup_value](\ref mobile_topup_value.h).
 * \retval ta_c_rc_invalid_argument \em amount is not \em ta_object_invalid and is not of
 *                                  type \em amount.
 */
extern ta_e_result_code_t ta_mobile_topup_value_set_amount(
	ta_object_t value,
	ta_object_t amount );

#ifdef __cplusplus
}
#endif

#endif
