/**
 * \file
 * \brief Transaction data.
 * \details Object type \em transaction_data.
 */

#ifndef TA_TRANSACTION_DATA_H
#define TA_TRANSACTION_DATA_H

#include "common/object.h"
#include "common/boolean.h"
#include "common/integer.h"
#include "constants/ngv_mode.h"
#include "constants/transaction_reason.h"
#include "constants/token_pan_type.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create transaction data.
 * 
 * \param[out] trx_data Pointer to variable to write created object instance to.
 *                      Created object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_transaction_data_create(
	ta_object_t *trx_data );

/**
 * \brief Create copy of transaction data.
 * 
 * \param[out] trx_data Pointer to variable to write created object instance to.
 *                    Created object instance is retained.
 * \param[in] source_trx_data Object of type [transaction_data](\ref transaction_data.h) to create copy of.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em source_trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em source_trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_transaction_data_copy(
	ta_object_t *trx_data,
	const ta_object_t* source_trx_data );



/**
 * \brief Allows the EFT Terminal to enable DCC function.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] dcc_allowed Pointer to variable to write value to. Value is \em ta_c_b_undefined
 *                         if value is not set in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value written to \em dcc_allowed.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em dcc_allowed is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_dcc_allowed(
	ta_object_t trx_data,
	ta_e_boolean_t *dcc_allowed );

/**
 * \brief Set allows the EFT Terminal to enable DCC function.
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_reservation
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_activate_card
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_init_transaction
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_purchase
 * - ta_c_tt_refunding
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] dcc_allowed Value to set. Value can be \em ta_c_b_undefined to clear the value
 *                        in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em dcc_allowed is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_set_dcc_allowed(
	ta_object_t trx_data,
	ta_e_boolean_t dcc_allowed );



/**
 * \brief Timestamp of the original transaction.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] trx_original_date Pointer to variable to write object instance to. Object
 *                               instance is of type [timedate](\ref timedate.h) and is not retained. Object
 *                               instance is \em ta_object_invalid if value is not set
 *                               in \em trx_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em trx_original_date.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em trx_original_date is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_trx_original_date(
	ta_object_t trx_data,
	ta_object_t* trx_original_date );

/**
 * \brief Set timestamp of the original transaction.
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_credit
 * - ta_c_tt_load
 * - ta_c_tt_refunding
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_activate_card
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_init_transaction
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_reservation
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] trx_original_date Object instance to set. Object instance can be
 *                                \em ta_object_invalid to clear the value in \em trx_data. If
 *                                object instance is not ta_object_invalid is has to be of
 *                                type \em timedate.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em trx_original_date is not \em ta_object_invalid and
 *                                  is not of type [timedate](\ref timedate.h).
 */
extern ta_e_result_code_t ta_transaction_data_set_trx_original_date(
	ta_object_t trx_data,
	ta_object_t trx_original_date );



/**
 * \brief ECR sequence counter.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] ecr_seq_counter Pointer to variable to write object instance to. Object
 *                             instance is of type [integer](\ref integer.h) and is not retained. Object
 *                             instance is \em ta_object_invalid if value is not set
 *                             in \em trx_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em ecr_seq_counter.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em ecr_seq_counter is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_ecr_seq_counter(
	ta_object_t trx_data,
	ta_object_t* ecr_seq_counter );

/**
 * \brief Set ECR sequence counter.
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_init_transaction
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] ecr_seq_counter Object instance to set. Object instance can be
 *                                \em ta_object_invalid to clear the value in \em trx_data. If
 *                                object instance is not ta_object_invalid is has to be of
 *                                type \em integer.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em ecr_seq_counter is not \em ta_object_invalid and
 *                                  is not of type [integer](\ref integer.h).
 */
extern ta_e_result_code_t ta_transaction_data_set_ecr_seq_counter(
	ta_object_t trx_data,
	ta_object_t ecr_seq_counter );



/**
 * \brief Partial approval is allowed.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] partial_approval_allowed Pointer to variable to write value to. Value is
 *                                      \em ta_c_b_undefined if value is not set in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value written to \em partial_approval_allowed.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em partial_approval_allowed is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_partial_approval_allowed(
	ta_object_t trx_data,
	ta_e_boolean_t *partial_approval_allowed );

/**
 * \brief Set partial approval is allowed.
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_combined
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_giro
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_reservation
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_activate_card
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_collect_points
 * - ta_c_tt_credit
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_init_transaction
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_refunding
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] partial_approval_allowed Value to set. Value can be \em ta_c_b_undefined to
 *                                     clear the value in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em partial_approval_allowed is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_set_partial_approval_allowed(
	ta_object_t trx_data,
	ta_e_boolean_t partial_approval_allowed );



/**
 * \brief Transaction reference defined by the terminal.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] trans_ref Pointer to variable to write object instance to. Object
 *                       instance is of type [integer](\ref integer.h) and is not retained. Object
 *                       instance is \em ta_object_invalid if value is not set
 *                       in \em trx_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em trans_ref.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em trans_ref is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_trans_ref(
	ta_object_t trx_data, ta_object_t* trans_ref );

/**
 * \brief Set transaction reference defined by the terminal.
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_credit
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_load
 * - ta_c_tt_refunding
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_activate_card
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_init_transaction
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_reservation
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] trans_ref Object instance to set. Object instance can be
 *                      \em ta_object_invalid to clear the value in \em trx_data. If
 *                      object instance is not ta_object_invalid is has to be of
 *                      type \em integer.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em trans_ref is not \em ta_object_invalid and
 *                                  is not of type [integer](\ref integer.h).
 */
extern ta_e_result_code_t ta_transaction_data_set_trans_ref(
	ta_object_t trx_data,
	ta_object_t trans_ref );



/**
 * \brief Transaction sequence number defined by the terminal.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] trans_seq Pointer to variable to write object instance to. Object
 *                       instance is of type [integer](\ref integer.h) and is not retained. Object
 *                       instance is \em ta_object_invalid if value is not set
 *                       in \em trx_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em trans_seq.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em trans_seq is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_trans_seq(
	ta_object_t trx_data,
	ta_object_t* trans_seq );

/**
 * \brief Set transaction sequence number defined by the terminal.
 * 
 * Mandatory for (can not be ta_object_invalid):
 * - ta_c_tt_reversal
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_finalize_purchase
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_activate_card
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_init_transaction
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_unload
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] trans_seq Object instance to set. Object instance can be
 *                      \em ta_object_invalid to clear the value in \em trx_data. If
 *                      object instance is not ta_object_invalid is has to be of
 *                      type \em integer.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em trans_seq is not \em ta_object_invalid and
 *                                  is not of type [integer](\ref integer.h).
 */
extern ta_e_result_code_t ta_transaction_data_set_trans_seq(
	ta_object_t trx_data,
	ta_object_t trans_seq );



/**
 * \brief Petrol: Reference from the card.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] card_ref Pointer to variable to write object instance to. Object
 *                      instance is of type [string](\ref string.h) and is not retained. Object
 *                      instance is \em ta_object_invalid if value is not set
 *                      in \em trx_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_ref.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em card_ref is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_card_ref(
	ta_object_t trx_data,
	ta_object_t* card_ref );

/**
 * \brief Set petrol: Reference from the card.
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_pre_authorization
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] card_ref Object instance to set. Object instance can be
 *                     \em ta_object_invalid to clear the value in \em trx_data. If
 *                     object instance is not ta_object_invalid is has to be of
 *                     type \em string.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em card_ref is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_transaction_data_set_card_ref(
	ta_object_t trx_data,
	ta_object_t card_ref );



/**
 * \brief Acquirer identifier. Uniquely identifies the acquirer.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] acq_id Pointer to variable to write object instance to. Object
 *                    instance is of type [integer](\ref integer.h) and is not retained. Object
 *                    instance is \em ta_object_invalid if value is not set
 *                    in \em trx_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em acq_id.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em acq_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_acq_id(
	ta_object_t trx_data,
	ta_object_t* acq_id );

/**
 * \brief Set acquirer identifier. Uniquely identifies the acquirer.
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_reversal
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_activate_card
 * - ta_c_tt_collect_points
 * - ta_c_tt_funding
 * - ta_c_tt_init_transaction
 * - ta_c_tt_load_voucher
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_unload
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] acq_id Object instance to set. Object instance can be
 *                     \em ta_object_invalid to clear the value in \em trx_data. If
 *                     object instance is not ta_object_invalid is has to be of
 *                     type \em integer.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em acq_id is not \em ta_object_invalid and
 *                                  is not of type [integer](\ref integer.h).
 */
extern ta_e_result_code_t ta_transaction_data_set_acq_id(
	ta_object_t trx_data,
	ta_object_t acq_id );



/**
 * \brief Transaction reference from the acquirer.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] acq_trans_ref Pointer to variable to write object instance to. Object
 *                           instance is of type [string](\ref string.h) and is not retained. Object
 *                           instance is \em ta_object_invalid if value is not set
 *                           in \em trx_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em acq_trans_ref.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em acq_trans_ref is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_acq_trans_ref(
	ta_object_t trx_data,
	ta_object_t* acq_trans_ref );

/**
 * \brief Set transaction reference from the acquirer.
 * 
 * Mandatory for (can not be ta_object_invalid):
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_refunding
 * - ta_c_tt_unload
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_reservation
 * - ta_c_tt_reversal
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_init_transaction
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] acq_trans_ref Object instance to set. Object instance can be
 *                          \em ta_object_invalid to clear the value in \em trx_data. If
 *                          object instance is not ta_object_invalid is has to be of
 *                          type \em string.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em acq_trans_ref is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_transaction_data_set_acq_trans_ref(
	ta_object_t trx_data,
	ta_object_t acq_trans_ref );



/**
 * \brief Transaction reference from the terminal.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] trm_trans_ref Pointer to variable to write object instance to. Object
 *                           instance is of type [string](\ref string.h) and is not retained. Object
 *                           instance is \em ta_object_invalid if value is not set
 *                           in \em trx_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em trm_trans_ref.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em trm_trans_ref is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_trm_trans_ref(
	ta_object_t trx_data,
	ta_object_t* trm_trans_ref );

/**
 * \brief Set transaction reference from the terminal.
 * 
 * Mandatory for (can not be ta_object_invalid):
 * - ta_c_tt_finalize_purchase
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_init_transaction
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] trm_trans_ref Object instance to set. Object instance can be
 *                          \em ta_object_invalid to clear the value in \em trx_data. If
 *                          object instance is not ta_object_invalid is has to be of
 *                          type \em string.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em trm_trans_ref is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_transaction_data_set_trm_trans_ref(
	ta_object_t trx_data,
	ta_object_t trm_trans_ref );



/**
 * \brief Tip is allowed for purchase transactions.
 * 
 * This parameter is only used if \em ta_c_g_gastro is enabled.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] tip_allowed Pointer to variable to write value to. Value is \em ta_c_b_undefined
 *                         if value is not set in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value written to \em tip_allowed.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em tip_allowed is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_tip_allowed(
	ta_object_t trx_data,
	ta_e_boolean_t *tip_allowed );

/**
 * \brief Set tip is allowed for purchase transactions.
 * 
 * This parameter is only used if ta_c_g_gastro is enabled.
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_refunding
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_reservation
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] tip_allowed Value to set. Value can be \em ta_c_b_undefined to clear the value
 *                        in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em tip_allowed is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_set_tip_allowed(
	ta_object_t trx_data,
	ta_e_boolean_t tip_allowed );



/**
 * \brief Phone authorization code.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] phone_auth_code Pointer to variable to write object instance to. Object
 *                             instance is of type [string](\ref string.h) and is not retained. Object
 *                             instance is \em ta_object_invalid if value is not set
 *                             in \em trx_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em phone_auth_code.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em phone_auth_code is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_phone_auth_code(
	ta_object_t trx_data,
	ta_object_t* phone_auth_code );

/**
 * \brief Set phone authorization code.
 * 
 * Mandatory for (can not be ta_object_invalid):
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_reservation_phone_authorized
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_collect_points
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_refunding
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_giro
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_reservation
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] phone_auth_code Object instance to set. Object instance can be
 *                            \em ta_object_invalid to clear the value in \em trx_data. If
 *                            object instance is not ta_object_invalid is has to be of
 *                            type \em string.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em phone_auth_code is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_transaction_data_set_phone_auth_code(
	ta_object_t trx_data,
	ta_object_t phone_auth_code );



/**
 * \brief Petrol, Unattended: Language.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] language Pointer to variable to write object instance to. Object
 *                      instance is of type [string](\ref string.h) and is not retained. Object
 *                      instance is \em ta_object_invalid if value is not set
 *                      in \em trx_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em language.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em language is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_language(
	ta_object_t trx_data,
	ta_object_t* language );

/**
 * \brief Set petrol, Unattended: Language.
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_activate_card
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_balance_inquiry
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_client_identification
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_init_transaction
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_send_card_command
 * - ta_c_tt_start_checkout
 * - ta_c_tt_unload
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_reversal
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] language Object instance to set. Object instance can be
 *                     \em ta_object_invalid to clear the value in \em trx_data. If
 *                     object instance is not ta_object_invalid is has to be of
 *                     type \em string.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em language is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_transaction_data_set_language(
	ta_object_t trx_data,
	ta_object_t language );



/**
 * \brief Indicates if the transaction uses multiple currencies.
 * 
 * Optional: Indicates that the transaction uses multiple currencies.
 * Specifications: \em Banking, \em Gastro, \em Hospitality,\em AustrianUseCases.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] multi_currency_flag Pointer to variable to write value to. Value is
 *                                 \em ta_c_b_undefined if value is not set in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value written to \em multi_currency_flag.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em multi_currency_flag is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_multi_currency_flag(
	ta_object_t trx_data,
	ta_e_boolean_t* multi_currency_flag );

/**
 * \brief Set Indicates if the transaction uses multiple currencies.
 * 
 * Optional: Indicates that the transaction uses multiple currencies.
 * Specifications: \em Banking, \em Gastro, \em Hospitality,\em AustrianUseCases.
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * 
 * Forbidden (has to be always ta_object_invalid):
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] multi_currency_flag Value to set. Value can be \em ta_c_b_undefined to clear
 *                                the value in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em multi_currency_flag is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_set_multi_currency_flag(
	ta_object_t trx_data,
	ta_e_boolean_t multi_currency_flag );



/**
 * \brief Defines if NGV usage is mandatory or optional if card supports it.
 * 
 * Available if \em AustrianUseCases guide is enabled.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] ngv_mode Pointer to variable to write value to. Value is
 *                      \em ta_c_ngvm_undefined if value is not set in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value written to \em ngv_mode.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em ngv_mode is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_ngv_mode(
	ta_object_t trx_data,
	ta_e_ngv_mode_t* ngv_mode );

/**
 * \brief Set defines if NGV usage is mandatory or optional if card supports it.
 * 
 * Available if \em AustrianUseCases guide is enabled.
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * 
 * Forbidden (has to be always ta_object_invalid):
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] ngv_mode Value to set. Value can be \em ta_c_ngvm_undefined to clear
 *                     the value in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em ngv_mode is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_set_ngv_mode(
	ta_object_t trx_data,
	ta_e_ngv_mode_t ngv_mode );



/**
 * \brief Defines the clearing delay of the PurchaseNGV transaction.
 * 
 * Available if \em AustrianUseCases guide is enabled.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] ngv_clearing_delay Pointer to variable to write value to. Value is
 *                                0 if value is not set in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value written to \em ngv_clearing_delay.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em ngv_clearing_delay is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_ngv_clearing_delay(
	ta_object_t trx_data,
	int* ngv_clearing_delay );

/**
 * \brief Set defines the clearing delay of the PurchaseNGV transaction.
 * 
 * Available if \em AustrianUseCases guide is enabled.
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * 
 * Forbidden (has to be always ta_object_invalid):
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] ngv_clearing_delay Value to set. Value can be 0 to clear the value in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em ngv_clearing_delay is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em ngv_clearing_delay is less than 0.
 */
extern ta_e_result_code_t ta_transaction_data_set_ngv_clearing_delay(
	ta_object_t trx_data,
	int ngv_clearing_delay );



/**
 * \brief Card verification code 2.
 * 
 * The card verification code 2 is used for transactions with MPKE as an additional security
 * element that has to be provided. It has an n3 value: Numeric 3 digits: 012
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] cvc2 Pointer to variable to write object instance to. Object instance is of
 *                  type [integer](\ref integer.h) and is not retained. Object instance is
 *                  \em ta_object_invalid if value is not set in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value written to \em ngv_clearing_delay.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em cvc2 is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_cvc2(
	ta_object_t trx_data,
	ta_object_t* cvc2 );

/**
 * \brief Set card verification code 2.
 * 
 * The card verification code 2 is used for transactions with MPKE as an additional security
 * element that has to be provided. It has an n3 value: Numeric 3 digits: 012
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_init_transaction
 * - ta_c_tt_purchase_reservation
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] cvc2 Object instance to set. Object instance can be \em ta_object_invalid to
 *                 clear the value in \em trx_data. If object instance is not ta_object_invalid
 *                 is has to be of type \em integer.
 * 
 * \retval ta_c_rc_ok Value assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em cvc2 is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em cvc2 is less than 0.
 */
extern ta_e_result_code_t ta_transaction_data_set_cvc2(
	ta_object_t trx_data,
	ta_object_t cvc2 );



/**
 * \brief Application expiration date.
 * 
 * Each application on a card has a corresponding expiration date and can be read from the card.
 * Example: The format of an 'Expiration Date' is defined as MMyy, 2 digits for the month and
 *          2 digits for the year. So January 2018 will have the following format as
 *          'Expiration Date': 0118
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] app_expiration_date Pointer to variable to write object instance to. Object
 *                                 instance is of type [timedate](\ref timedate.h) and is not retained. Object
 *                                 instance is \em ta_object_invalid if value is not set
 *                                 in \em trx_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em app_expiration_date.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em app_expiration_date is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_app_expiration_date(
	ta_object_t trx_data,
	ta_object_t* app_expiration_date );

/**
 * \brief Set application expiration date.
 * 
 * Each application on a card has a corresponding expiration date and can be read from the card.
 * Example: The format of an 'Expiration Date' is defined as MMyy, 2 digits for the month and
 *          2 digits for the year. So January 2018 will have the following format as
 *          'Expiration Date': 0118
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_purchase_reservation
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] app_expiration_date Object instance to set. Object instance can be
 *                                \em ta_object_invalid to clear the value in \em trx_data. If
 *                                object instance is not ta_object_invalid is has to be of
 *                                type \em timedate.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em app_expiration_date is not \em ta_object_invalid and
 *                                  is not of type [timedate](\ref timedate.h).
 */
extern ta_e_result_code_t ta_transaction_data_set_app_expiration_date(
	ta_object_t trx_data,
	ta_object_t app_expiration_date );



/**
 * \brief SIX Transaction Reference Number.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] six_trx_ref_num Pointer to variable to write object instance to. Object
 *                             instance is of type [string](\ref string.h) and is not retained. Object
 *                             instance is \em ta_object_invalid if value is not set
 *                             in \em trx_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em six_trx_ref_num.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em six_trx_ref_num is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_six_trx_ref_num(
	ta_object_t trx_data,
	ta_object_t* six_trx_ref_num );

/**
 * \brief Set SIX Transaction Reference Number.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] six_trx_ref_num Object instance to set. Object instance can be
 *                            \em ta_object_invalid to clear the value in \em trx_data. If
 *                            object instance is not ta_object_invalid is has to be of
 *                            type \em string.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em six_trx_ref_num is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_transaction_data_set_six_trx_ref_num(
	ta_object_t trx_data,
	ta_object_t six_trx_ref_num );

/**
 * \brief SIX Transaction Reference Number for integrators using MPD Client.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] acq_id AcqID as provided by MPD.
 * \param[in] trx_ref_num Transaction reference as provided by MPD. Object instance has
 *                        to be of type \em string.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em trx_ref_num is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_transaction_data_set_six_trx_ref_num_mpd(
	ta_object_t trx_data,
	int64_t acq_id,
	ta_object_t trx_ref_num );



/**
 * \brief Saferpay alias.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] saferpay_alias Pointer to variable to write object instance to. Object
 *                            instance is of type [string](\ref string.h) and is not retained. Object
 *                            instance is \em ta_object_invalid if value is not set
 *                            in \em trx_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em saferpay_alias.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em saferpay_alias is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_saferpay_alias(
	ta_object_t trx_data,
	ta_object_t* saferpay_alias );

/**
 * \brief Set saferpay alias.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] saferpay_alias Object instance to set. Object instance can be
 *                           \em ta_object_invalid to clear the value in \em trx_data. If
 *                           object instance is not ta_object_invalid is has to be of
 *                           type \em string.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em saferpay_alias is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_transaction_data_set_saferpay_alias(
	ta_object_t trx_data,
	ta_object_t saferpay_alias );



/**
 * \brief Saferpay recurring enabled.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] saferpay_recurring Pointer to variable to write value to. Value is
 *                                \em ta_c_b_undefined if value is not set in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value written to \em saferpay_recurring.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em saferpay_recurring is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_saferpay_recurring(
	ta_object_t trx_data,
	ta_e_boolean_t *saferpay_recurring );

/**
 * \brief Set saferpay recurring enabled.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] saferpay_recurring Value to set. Value can be \em ta_c_b_undefined to clear
 *                               the value in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em saferpay_recurring is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_set_saferpay_recurring(
	ta_object_t trx_data,
	ta_e_boolean_t saferpay_recurring );



/**
 * \brief Indicates if installment shall be allowed for a transaction.
 * 
 * This tag can be set for each transaction separately to specifically allow or disallow
 * installment feature during the corresponding transaction.
 * As this is a boolean value is can be understood as follows:
 * true: Installment is allowed for the transaction
 * false: Installment is NOT allowed for the transaction 
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] installment_allowed Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em installment_allowed.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em installment_allowed is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_installment_allowed(
	ta_object_t trx_data,
	ta_e_boolean_t* installment_allowed );

/**
 * \brief Set application expiration date.
 * 
 * Each application on a card has a corresponding expiration date and can be read from the card.
 * Example: The format of an 'Expiration Date' is defined as MMyy, 2 digits for the month and
 *          2 digits for the year. So January 2018 will have the following format as
 *          'Expiration Date': 0118
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_init_transaction
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] installment_allowed Value to set.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em app_expiration_date is not \em ta_object_invalid and
 *                                  is not of type [timedate](\ref timedate.h).
 */
extern ta_e_result_code_t ta_transaction_data_set_installment_allowed(
	ta_object_t trx_data,
	ta_e_boolean_t installment_allowed );



/**
 * \brief Indicates that the transaction shall be performed using deffered authorisation.
 * 
 * The following values are valid:
 * true: Deferred authorisation applies
 * false: Standard authorisation scheme (default)
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] deferred_auth_ind Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em deferred_auth_ind.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em deferred_auth_ind is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_deferred_auth_ind(
	ta_object_t trx_data,
	ta_e_boolean_t* deferred_auth_ind );

/**
 * \brief Set indicates that the transaction shall be performed using deffered authorisation.
 * 
 * The following values are valid:
 * true: Deferred authorisation applies
 * false: Standard authorisation scheme (default)
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * 
 * Forbidden (has to be always ta_object_invalid):
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] installment_allowed Value to set.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em app_expiration_date is not \em ta_object_invalid and
 *                                  is not of type [timedate](\ref timedate.h).
 */
extern ta_e_result_code_t ta_transaction_data_set_deferred_auth_ind(
	ta_object_t trx_data,
	ta_e_boolean_t installment_allowed );



/**
 * \brief Set the transaction reason to setup credential on file.
 * 
 * Available if \em AdvancedRetail guide is enabled.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] transaction_reason Pointer to variable to write value to. Value is
 *                                \em ta_c_ngvm_undefined if value is not set in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value written to \em transaction_reason.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em transaction_reason is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_transaction_reason(
	ta_object_t trx_data,
	ta_e_transaction_reason_t* transaction_reason );

/**
 * \brief Set the transaction reason to setup credential on file.
 * 
 * Available if \em AdvancedRetail guide is enabled.
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_init_transaction
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] transaction_reason Value to set. Value can be \em ta_c_ngvm_undefined to clear
 *                     the value in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em transaction_reason is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_set_transaction_reason(
	ta_object_t trx_data,
	ta_e_transaction_reason_t transaction_reason );



/**
 * \brief Sub transactions.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] sub_transactions Pointer to variable to write object instance to. Object instance
 *                              is of type [list](\ref list.h) with elements of type
 *                              [sub_transaction](\ref sub_transaction.h). Object instance is not
 *                              retained. Object instance is \em ta_object_invalid if value is
 *                              not set in \em trx_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em sub_transactions.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em sub_transactions is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_sub_transactions(
	ta_object_t trx_data,
	ta_object_t* sub_transactions );

/**
 * \brief Set sub transactions.
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_combined
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] sub_transactions Object instance to set. Object instance can be \em ta_object_invalid
 *                             to clear the value in \em trx_data. If object instance is not
 *                             ta_object_invalid is has to be of type [list](\ref list.h) with
 *                             elements of type [sub_transaction](\ref sub_transaction.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em sub_transactions is not \em ta_object_invalid and
 *                                  is not of type [timedate](\ref timedate.h).
 */
extern ta_e_result_code_t ta_transaction_data_set_sub_transactions(
	ta_object_t trx_data,
	ta_object_t sub_transactions );



/**
 * \brief Allowed accounts (flags).
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] allowed_accounts Pointer to variable to write object instance to. Object instance
 *                              is of type [integer](\ref integer.h) with value OR-combined
 *                              from constant [allowed_accounts](\ref allowed_accounts.h).
 *                              Object instance is not retained. Object instance is
 *                              \em ta_object_invalid if value is not set in \em trx_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em allowed_accounts.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em allowed_accounts is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_allowed_accounts(
	ta_object_t trx_data,
	ta_object_t* allowed_accounts );

/**
 * \brief Set allowed accounts (flags).
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_credit
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_with_cashback
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_balance_inquiry
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_reversal
 * - ta_c_tt_unload
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] allowed_accounts Object instance to set. Object instance can be \em ta_object_invalid
 *                             to clear the value in \em trx_data. If object instance is not
 *                             ta_object_invalid is has to be of type [integer](\ref integer.h)
 *                             with value OR-combined from constant [allowed_accounts](\ref allowed_accounts.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em allowed_accounts is not \em ta_object_invalid and
 *                                  is not of type [list](\ref list.h).
 */
extern ta_e_result_code_t ta_transaction_data_set_allowed_accounts(
	ta_object_t trx_data,
	ta_object_t allowed_accounts );



/**
 * \brief Token PAN.
 * 
 * The token PAN is a tokenized version for an underlaying card PAN. If the underlaying payment
 * protocol supports it, a payment transaction can be initiated with the token PAN instead of
 * using a card. A token PAN is normally generated by a tokenization service either form the
 * acquirer host or the issuer host.
 * 
 * The TokenPan field is used in a SIXml request message as part of the sixml:TransactionData
 * container to trigger a token-based transaction and in a SIXml response message as part of
 * the sixml:CardData container for returning token PANs to the ECR.
 * 
 * The TokenPan field always must be accompanied by a corresponding TokenPanType field.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] token_pan Pointer to variable to write object instance to. Object instance is of type
 *                       [string](\ref string.h) and is not retained. Object instance is
 *                       \em ta_object_invalid if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em token_pan.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em token_pan is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_token_pan(
	ta_object_t trx_data,
	ta_object_t* token_pan );

/**
 * \brief Set token PAN.
 * 
 * The token PAN is a tokenized version for an underlaying card PAN. If the underlaying payment
 * protocol supports it, a payment transaction can be initiated with the token PAN instead of
 * using a card. A token PAN is normally generated by a tokenization service either form the
 * acquirer host or the issuer host.
 * 
 * The TokenPan field is used in a SIXml request message as part of the sixml:TransactionData
 * container to trigger a token-based transaction and in a SIXml response message as part of
 * the sixml:CardData container for returning token PANs to the ECR.
 * 
 * The TokenPan field always must be accompanied by a corresponding TokenPanType field.
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_unload
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_reversal
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] token_pan Object instance to set. Object instance can be
 *                      \em ta_object_invalid to clear the value in \em trx_data. If
 *                      object instance is not ta_object_invalid is has to be of type \em string.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em token_pan is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_transaction_data_set_token_pan(
	ta_object_t trx_data,
	ta_object_t token_pan );



/**
 * \brief Token PAN type.
 * 
 * To differ the source of a token PAN, the TokenPanType field is used in a SIXml request
 * message as part of the sixml:TransactionData container and in a SIXml response message
 * as part of the sixml:CardData container.
 * 
 * The TokenPanType field always is transmitted if a TokenPan field is transmitted but must
 * not be transmitted alone.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] token_pan_type Pointer to variable to write value to. Value is
 *                                \em ta_c_tpt_undefined if value is not set in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value written to \em token_pan_type.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em token_pan_type is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_token_pan_type(
	ta_object_t trx_data,
	ta_e_token_pan_type_t* token_pan_type );

/**
 * \brief Set token PAN type.
 * 
 * To differ the source of a token PAN, the TokenPanType field is used in a SIXml request
 * message as part of the sixml:TransactionData container and in a SIXml response message
 * as part of the sixml:CardData container.
 * 
 * The TokenPanType field always is transmitted if a TokenPan field is transmitted but must
 * not be transmitted alone.
 * 
 * Mandatory for (can not be ta_object_invalid):
 * 
 * Conditional for (can be ta_object_invalid):
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_unload
 * 
 * Forbidden (has to be always ta_object_invalid):
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_reversal
 * 
 * Transactions will fail if one of the above mentioned restrictions are violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] token_pan_type Value to set. Value can be \em ta_c_tpt_undefined to clear
 *                     the value in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em token_pan_type is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_set_token_pan_type(
	ta_object_t trx_data,
	ta_e_token_pan_type_t token_pan_type );



/**
 * To identify an Omnichannel transaction (not used for Saferpay) the
 * OmnichannelPaymentId has to be set in TransactionData. This attribute is also
 * used to identify the Omnichannel host, a OmnichannelPaymentId starting by
 * '90' meens for example that Ogone has to be used.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] payment_id Pointer to variable to write object instance to. Object instance is of type
 *                        [string](\ref string.h) and is not retained. Object instance is
 *                        \em ta_object_invalid if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em payment_id.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em payment_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_omnichannel_payment_id(
	ta_object_t trx_data,
	ta_object_t* payment_id );

/**
 * To identify an Omnichannel transaction (not used for Saferpay) the
 * OmnichannelPaymentId has to be set in TransactionData. This attribute is also
 * used to identify the Omnichannel host, a OmnichannelPaymentId starting by
 * '90' meens for example that Ogone has to be used.
 *
 * Mandatory for (can not be null):
 *
 * Conditional for (can be null):
 * - ta_c_tt_credit
 *
 * Forbidden (has to be always null):
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_reversal
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_credit
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_unload
 *
 * Transactions will fail if one of the above mentioned restrictions are
 * violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] payment_id Value to set. Value can be \em ta_c_ngvm_undefined to clear
 *                       the value in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em payment_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_set_omnichannel_payment_id(
	ta_object_t trx_data,
	ta_object_t payment_id );



/**
 * The OmnichannelMerchantId is used to identify the merchant on a Omnichannel
 * host. This field is not used for Saferpay, but is for example for Ogone.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] merchant_id Pointer to variable to write object instance to. Object instance is of type
 *                        [string](\ref string.h) and is not retained. Object instance is
 *                        \em ta_object_invalid if value is not set in \em card_data.
 * 
 * \retval ta_c_rc_ok Object instance written to \em merchant_id.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em merchant_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_omnichannel_merchant_id(
	ta_object_t trx_data,
	ta_object_t* merchant_id );

/**
 * The OmnichannelMerchantId is used to identify the merchant on a Omnichannel
 * host. This field is not used for Saferpay, but is for example for Ogone.
 * 
 * Mandatory for (can not be null):
 *
 * Conditional for (can be null):
 * - ta_c_tt_credit
 *
 * Forbidden (has to be always null):
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_reversal
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_refunding
 * - ta_c_tt_reservation
 * - ta_c_tt_unload
 *
 * Transactions will fail if one of the above mentioned restrictions are
 * violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] merchant_id Value to set. Value can be \em ta_c_ngvm_undefined to clear
 *                        the value in \em trx_data.
 * 
 * \retval ta_c_rc_ok Value assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em merchant_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_set_omnichannel_merchant_id(
	ta_object_t trx_data,
	ta_object_t merchant_id );



/**
 * Age to check.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[out] age_to_check Pointer to variable to write object instance to. Object instance
 *                          is of type [integer](\ref integer.h) and is not retained.
 *                          Object instance is \em ta_object_invalid if value is not set.
 * 
 * \retval ta_c_rc_ok Object instance written to \em merchant_id.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em age_to_check is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_get_age_to_check(
	ta_object_t trx_data,
	ta_object_t* age_to_check );

/**
 * Set age to check.
 * 
 * Mandatory for (can not be null):
 *
 * Conditional for (can be null):
 * - ta_c_tt_purchase
 * - ta_c_tt_purchase_with_cashback
 * - ta_c_tt_pre_authorization
 * - ta_c_tt_reservation
 *
 * Forbidden (has to be always null):
 * - ta_c_tt_adjust_reservation
 * - ta_c_tt_cancel_reservation
 * - ta_c_tt_credit
 * - ta_c_tt_debt_recovery
 * - ta_c_tt_finalize_purchase
 * - ta_c_tt_purchase_phone_authorized
 * - ta_c_tt_purchase_reservation
 * - ta_c_tt_purchase_reservation_phone_authorized
 * - ta_c_tt_reversal
 * - ta_c_tt_account_verification
 * - ta_c_tt_activate_card
 * - ta_c_tt_authorize_credit
 * - ta_c_tt_authorize_deposit
 * - ta_c_tt_cash_advance
 * - ta_c_tt_collect_points
 * - ta_c_tt_combined
 * - ta_c_tt_funding
 * - ta_c_tt_giro
 * - ta_c_tt_load
 * - ta_c_tt_load_voucher
 * - ta_c_tt_purchase_forced_acceptance
 * - ta_c_tt_purchase_mail_ordered
 * - ta_c_tt_purchase_phone_ordered
 * - ta_c_tt_refunding
 * - ta_c_tt_unload
 *
 * Transactions will fail if one of the above mentioned restrictions are
 * violated.
 * 
 * \param[in] trx_data Object instance of type [transaction_data](\ref transaction_data.h).
 * \param[in] age_to_check Object instance to set. Object instance can be \em ta_object_invalid
 *                         to clear the value in \em trx_data. If object instance is not
 *                         ta_object_invalid is has to be of type [integer](\ref integer.h).
 * 
 * \retval ta_c_rc_ok Value assigned to \em trx_data.
 * \retval ta_c_rc_invalid_argument \em trx_data is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em trx_data is not of type [transaction_data](\ref transaction_data.h).
 * \retval ta_c_rc_invalid_argument \em age_to_check is \em null-pointer.
 */
extern ta_e_result_code_t ta_transaction_data_set_age_to_check(
	ta_object_t trx_data,
	ta_object_t age_to_check );

#ifdef __cplusplus
}
#endif

#endif
