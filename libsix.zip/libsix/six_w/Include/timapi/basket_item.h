/**
 * \file
 * \brief Basket item.
 * \details Object type \em basket_item.
 */

#ifndef TA_BASKET_ITEM_H
#define TA_BASKET_ITEM_H

#include "common/object.h"
#include "common/boolean.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create object of type [basket_item](\ref basket_item.h).
 * 
 * \param[out] item Pointer to variable to write created object instance to.
 *                  Created object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_basket_item_create(
	ta_object_t *item );

/**
 * \brief Create deep copy of object instance of type [basket_item](\ref basket_item.h).
 * 
 * \param[out] item Pointer to variable to write created object instance to.
 *                  Created object instance is retained.
 * \param[in] source_item Object of type [basket_item](\ref basket_item.h) to create copy of.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em source_item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em source_item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_basket_item_copy(
	ta_object_t* item,
	const ta_object_t* source_item );



/**
 * \brief Acquirers result code, which indicates the result of a restriction request.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[out] auth_result Pointer to variable to write object instance to. Object instance is
 *                         of type [integer](\ref integer.h) and is not retained. Object instance is
 *                         \em ta_object_invalid if value is not set in \em basket_item.
 * 
 * \retval ta_c_rc_ok Object instance written to \em auth_result.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em auth_result is \em null-pointer.
 */
extern ta_e_result_code_t ta_basket_item_get_auth_result(
	ta_object_t item,
	ta_object_t *auth_result );

/**
 * \brief Set acquirers result code, which indicates the result of a restriction request.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[in] auth_result Object instance to set. Object instance can be \em ta_object_invalid
 *                        to clear the value in \em item. If object instance is not
 *                        ta_object_invalid is has to be of type [integer](\ref integer.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em auth_result is not \em ta_object_invalid and
 *                                  is not of type [integer](\ref integer.h).
 */
extern ta_e_result_code_t ta_basket_item_set_auth_result(
	ta_object_t item,
	ta_object_t auth_result );



/**
 * \brief Identifies the item.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[out] id Pointer to variable to write object instance to. Object instance is
 *                of type [string](\ref string.h) and is not retained. Object instance is
 *                \em ta_object_invalid if value is not set in \em item.
 * 
 * \retval ta_c_rc_ok Object instance written to \em id.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em id is \em null-pointer.
 */
extern ta_e_result_code_t ta_basket_item_get_item_id(
	ta_object_t item,
	ta_object_t *id );

/**
 * \brief Set identifies the item.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[in] id Object instance to set. Object instance can be \em ta_object_invalid
 *               to clear the value in \em item. If object instance is not
 *               ta_object_invalid is has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em id is not \em ta_object_invalid and is not of
 *                                  type \em string.
 */
extern ta_e_result_code_t ta_basket_item_set_item_id(
	ta_object_t item,
	ta_object_t id );



/**
 * \brief Identifies the loyalty type.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[out] loyalty_id Pointer to variable to write object instance to. Object instance is
 *                        of type [string](\ref string.h) and is not retained. Object instance is
 *                        \em ta_object_invalid if value is not set in \em item.
 * 
 * \retval ta_c_rc_ok Object instance written to \em loyalty_id.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em loyalty_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_basket_item_get_loyalty_id(
	ta_object_t item,
	ta_object_t *loyalty_id );

/**
 * \brief Set identifies the loyalty type.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[in] loyalty_id Object instance to set. Object instance can be \em ta_object_invalid
 *                       to clear the value in \em item. If object instance is not
 *                       ta_object_invalid is has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em loyalty_id is not \em ta_object_invalid and is not of
 *                                  type \em string.
 */
extern ta_e_result_code_t ta_basket_item_set_loyalty_id(
	ta_object_t item,
	ta_object_t loyalty_id );



/**
 * \brief Amount.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[out] amount Pointer to variable to write object instance to. Object instance is
 *                    of type [amount](\ref amount.h) and is not retained. Object instance is
 *                    \em ta_object_invalid if value is not set in \em item.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em amount is \em null-pointer.
 */
extern ta_e_result_code_t ta_basket_item_get_amount(
	ta_object_t item,
	ta_object_t *amount );

/**
 * \brief Set amount.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[in] amount Object instance to set. Object instance can be \em ta_object_invalid
 *                   to clear the value in \em item. If object instance is not
 *                   ta_object_invalid is has to be of type [amount](\ref amount.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em amount is not \em ta_object_invalid and is not of
 *                                  type \em amount.
 */
extern ta_e_result_code_t ta_basket_item_set_amount(
	ta_object_t item,
	ta_object_t amount );



/**
 * \brief Total amount.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[out] amount_total Pointer to variable to write object instance to. Object instance is
 *                          of type [amount](\ref amount.h) and is not retained. Object instance is
 *                          \em ta_object_invalid if value is not set in \em item.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount_total.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em amount_total is \em null-pointer.
 */
extern ta_e_result_code_t ta_basket_item_get_amount_total(
	ta_object_t item,
	ta_object_t *amount_total );

/**
 * \brief Set total amount.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[in] amount_total Object instance to set. Object instance can be \em ta_object_invalid
 *                         to clear the value in \em item. If object instance is not
 *                         ta_object_invalid is has to be of type [amount](\ref amount.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em amount_total is not \em ta_object_invalid and is not of
 *                                  type \em amount.
 */
extern ta_e_result_code_t ta_basket_item_set_amount_total(
	ta_object_t item,
	ta_object_t amount_total );



/**
 * \brief Discount amount or 0 if discount amount is not used.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[out] amount_discount Pointer to variable to write object instance to. Object instance is
 *                             of type [amount_discount](\ref amount_discount.h) and is not retained. Object instance is
 *                             \em ta_object_invalid if value is not set in \em item.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount_discount.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em amount_discount is \em null-pointer.
 */
extern ta_e_result_code_t ta_basket_item_get_amount_discount(
	ta_object_t item,
	ta_object_t *amount_discount );

/**
 * \brief Set discount amount or 0 if discount amount is not used.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[in] amount_discount Object instance to set. Object instance can be \em ta_object_invalid
 *                            to clear the value in \em item. If object instance is not
 *                            ta_object_invalid is has to be of type [amount_discount](\ref amount_discount.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em amount_discount is not \em ta_object_invalid and is
 *                                  not of type [amount_discount](\ref amount_discount.h).
 */
extern ta_e_result_code_t ta_basket_item_set_amount_discount(
	ta_object_t item,
	ta_object_t amount_discount );



/**
 * \brief Tax amount.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[out] amount_tax Pointer to variable to write object instance to. Object instance is
 *                        of type [amount](\ref amount.h) and is not retained. Object instance is
 *                        \em ta_object_invalid if value is not set in \em item.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount_tax.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em amount_tax is \em null-pointer.
 */
extern ta_e_result_code_t ta_basket_item_get_amount_tax(
	ta_object_t item,
	ta_object_t *amount_tax );

/**
 * \brief Set tax amount.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[in] amount_tax Object instance to set. Object instance can be \em ta_object_invalid
 *                       to clear the value in \em item. If object instance is not
 *                       ta_object_invalid is has to be of type [amount](\ref amount.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em amount_tax is not \em ta_object_invalid and is not of
 *                                  type \em amount.
 */
extern ta_e_result_code_t ta_basket_item_set_amount_tax(
	ta_object_t item,
	ta_object_t amount_tax );



/**
 * \brief Gross amount.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[out] amount_gross Pointer to variable to write object instance to. Object instance is
 *                        of type [amount](\ref amount.h) and is not retained. Object instance is
 *                        \em ta_object_invalid if value is not set in \em item.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount_gross.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em amount_gross is \em null-pointer.
 */
extern ta_e_result_code_t ta_basket_item_get_amount_gross(
	ta_object_t item,
	ta_object_t *amount_gross );

/**
 * \brief Set gross amount.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[in] amount_gross Object instance to set. Object instance can be \em ta_object_invalid
 *                       to clear the value in \em item. If object instance is not
 *                       ta_object_invalid is has to be of type [amount](\ref amount.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em amount_gross is not \em ta_object_invalid and is not of
 *                                  type \em amount.
 */
extern ta_e_result_code_t ta_basket_item_set_amount_gross(
	ta_object_t item,
	ta_object_t amount_gross );



/**
 * \brief Tax amount.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[out] unit_amount_discount Pointer to variable to write object instance to. Object instance is
 *                        of type [amount](\ref amount.h) and is not retained. Object instance is
 *                        \em ta_object_invalid if value is not set in \em item.
 * 
 * \retval ta_c_rc_ok Object instance written to \em unit_amount_discount.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em unit_amount_discount is \em null-pointer.
 */
extern ta_e_result_code_t ta_basket_item_get_unit_amount_discount(
	ta_object_t item,
	ta_object_t *unit_amount_discount );

/**
 * \brief Set unit_amount_discount amount.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[in] unit_amount_discount Object instance to set. Object instance can be \em ta_object_invalid
 *                       to clear the value in \em item. If object instance is not
 *                       ta_object_invalid is has to be of type [amount](\ref amount.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em unit_amount_discount is not \em ta_object_invalid and is not of
 *                                  type \em amount.
 */
extern ta_e_result_code_t ta_basket_item_set_unit_amount_discount(
	ta_object_t item,
	ta_object_t unit_amount_discount );



/**
 * \brief Tax amount.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[out] unit_amount_gross Pointer to variable to write object instance to. Object instance is
 *                        of type [amount](\ref amount.h) and is not retained. Object instance is
 *                        \em ta_object_invalid if value is not set in \em item.
 * 
 * \retval ta_c_rc_ok Object instance written to \em unit_amount_gross.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em unit_amount_gross is \em null-pointer.
 */
extern ta_e_result_code_t ta_basket_item_get_unit_amount_gross(
	ta_object_t item,
	ta_object_t *unit_amount_gross );

/**
 * \brief Set unit_amount_gross amount.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[in] unit_amount_gross Object instance to set. Object instance can be \em ta_object_invalid
 *                       to clear the value in \em item. If object instance is not
 *                       ta_object_invalid is has to be of type [amount](\ref amount.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em unit_amount_gross is not \em ta_object_invalid and is not of
 *                                  type \em amount.
 */
extern ta_e_result_code_t ta_basket_item_set_unit_amount_gross(
	ta_object_t item,
	ta_object_t unit_amount_gross );



/**
 * \brief Quantity of the product.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[out] item_quantity Pointer to variable to write object instance to. Object instance is
 *                           of type [item_quantity](\ref item_quantity.h) and is not retained. Object instance is
 *                           \em ta_object_invalid if value is not set in \em item.
 * 
 * \retval ta_c_rc_ok Object instance written to \em item_quantity.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em item_quantity is \em null-pointer.
 */
extern ta_e_result_code_t ta_basket_item_get_item_quantity(
	ta_object_t item,
	ta_object_t *item_quantity );

/**
 * \brief Set quantity of the product.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[in] item_quantity Object instance to set. Object instance can be \em ta_object_invalid
 *                          to clear the value in \em item. If object instance is not
 *                          ta_object_invalid is has to be of type [item_quantity](\ref item_quantity.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em item_quantity is not \em ta_object_invalid and is not of
 *                                  type \em item_quantity.
 */
extern ta_e_result_code_t ta_basket_item_set_item_quantity(
	ta_object_t item,
	ta_object_t item_quantity );



/**
 * \brief Product description.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[out] prod_description Pointer to variable to write object instance to. Object instance
 *                              is of type [string](\ref string.h) and is not retained. Object instance is
 *                              \em ta_object_invalid if value is not set in \em item.
 * 
 * \retval ta_c_rc_ok Object instance written to \em prod_description.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em prod_description is \em null-pointer.
 */
extern ta_e_result_code_t ta_basket_item_get_prod_description(
	ta_object_t item,
	ta_object_t *prod_description );

/**
 * \brief Set product description.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[in] prod_description Object instance to set. Object instance can be
 *                             \em ta_object_invalid to clear the value in \em item. If object
 *                             instance is not ta_object_invalid is has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em prod_description is not \em ta_object_invalid and is
 *                                  not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_basket_item_set_prod_description(
	ta_object_t item,
	ta_object_t prod_description );



/**
 * \brief Discount ID if AmountDiscount.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[out] discount_id Pointer to variable to write object instance to. Object instance
 *                         is of type [string](\ref string.h) and is not retained.
 *                         Object instance is \em ta_object_invalid if amount discount is
 *                         not set or discount item in amount discount is not set.
 * 
 * \retval ta_c_rc_ok Object instance written to \em prod_description.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em discount_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_basket_item_get_discount_id(
	ta_object_t item,
	ta_object_t *discount_id );



/**
 * \brief Specifies the used petrol pump number used in a sixml:Item as part of a sixml:Basket.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[out] petrol_pump_number Pointer to variable to write object instance to. Object instance is
 *                        of type [integer](\ref integer.h) and is not retained. Object instance is
 *                        \em ta_object_invalid if value is not set in \em item.
 * 
 * \retval ta_c_rc_ok Object instance written to \em petrol_pump_number.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em petrol_pump_number is \em null-pointer.
 */
extern ta_e_result_code_t ta_basket_item_get_petrol_pump_number(
	ta_object_t item,
	ta_object_t *petrol_pump_number );

/**
 * \brief Specifies the used petrol pump number used in a sixml:Item as part of a sixml:Basket.
 * 
 * \param[in] item Object instance of type [basket_item](\ref basket_item.h).
 * \param[in] petrol_pump_number Object instance to set. Object instance can be \em ta_object_invalid
 *                       to clear the value in \em item. If object instance is not
 *                       ta_object_invalid is has to be of type [integer](\ref integer.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em item.
 * \retval ta_c_rc_invalid_argument \em item is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em item is not of type [basket_item](\ref basket_item.h).
 * \retval ta_c_rc_invalid_argument \em petrol_pump_number is not \em ta_object_invalid and is not of
 *                                  type \em integer.
 */
extern ta_e_result_code_t ta_basket_item_set_petrol_pump_number(
	ta_object_t item,
	ta_object_t petrol_pump_number );


#ifdef __cplusplus
}
#endif

#endif
