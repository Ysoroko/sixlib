/**
 * \file
 * \brief Native error.
 * \details Object type \em native_error.
 */

#ifndef TA_NATIVE_ERROR_H
#define TA_NATIVE_ERROR_H

#include "common/object.h"
#include "common/boolean.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Error code.
 * 
 * \param[in] response Object instance of type [native_error](\ref native_error.h).
 * \param[out] code Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em code.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [native_error](\ref native_error.h).
 * \retval ta_c_rc_invalid_argument \em code is \em null-pointer.
 */
extern ta_e_result_code_t ta_native_error_get_code(
	ta_object_t response,
	int *code );

/**
 * \brief Print information for merchant receipt.
 * 
 * \param[in] response Object instance of type [native_error](\ref native_error.h).
 * \param[out] message Pointer to variable to write object instance to. Object instance
 *                     is of type [string](\ref string.h) and is not retained. Object instance
 *                     is \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em message.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [native_error](\ref native_error.h).
 * \retval ta_c_rc_invalid_argument \em message is \em null-pointer.
 */
extern ta_e_result_code_t ta_native_error_get_message(
	ta_object_t response,
	ta_object_t *message );

/**
 * \brief Print information for merchant receipt.
 * 
 * \param[in] response Object instance of type [native_error](\ref native_error.h).
 * \param[out] source Pointer to variable to write object instance to. Object instance
 *                    is of type [string](\ref string.h) and is not retained. Object instance
 *                    is \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em source.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [native_error](\ref native_error.h).
 * \retval ta_c_rc_invalid_argument \em source is \em null-pointer.
 */
extern ta_e_result_code_t ta_native_error_get_source(
	ta_object_t response,
	ta_object_t *source );


#ifdef __cplusplus
}
#endif

#endif
