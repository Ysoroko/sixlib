/**
 * \file
 * \brief Terminal status.
 * \details Object type \em terminal_status.
 */

#ifndef TA_TERMINAL_STATUS_H
#define TA_TERMINAL_STATUS_H

#include "common/object.h"
#include "common/boolean.h"
#include "constants/connection_status.h"
#include "constants/management_status.h"
#include "constants/card_reader_status.h"
#include "constants/transaction_status.h"
#include "constants/sleep_mode_status.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Content of display on EFT Terminal.
 * 
 * \param[in] terminal_status Object instance of type [terminal_status](\ref terminal_status.h).
 * \param[out] display_content Pointer to variable to write object instance to. Object instance
 *                             is of type [list](\ref list.h) and is not retained. The list contains
 *                             elements of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em display_content.
 * \retval ta_c_rc_invalid_argument \em terminal_status is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal_status is not of type [terminal_status](\ref terminal_status.h).
 * \retval ta_c_rc_invalid_argument \em display_content is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_status_get_display_content(
	ta_object_t terminal_status,
	ta_object_t *display_content );

/**
 * \brief Connection status of the EFT Terminal.
 * 
 * \param[in] terminal_status Object instance of type [terminal_status](\ref terminal_status.h).
 * \param[out] connection_status Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em connection_status.
 * \retval ta_c_rc_invalid_argument \em terminal_status is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal_status is not of type [terminal_status](\ref terminal_status.h).
 * \retval ta_c_rc_invalid_argument \em connection_status is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_status_get_connection_status(
	ta_object_t terminal_status,
	ta_e_connection_status_t *connection_status );

/**
 * \brief Management status of the EFT Terminal.
 * 
 * \param[in] terminal_status Object instance of type [terminal_status](\ref terminal_status.h).
 * \param[out] management_status Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em management_status.
 * \retval ta_c_rc_invalid_argument \em terminal_status is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal_status is not of type [terminal_status](\ref terminal_status.h).
 * \retval ta_c_rc_invalid_argument \em management_status is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_status_get_management_status(
	ta_object_t terminal_status,
	ta_e_management_status_t *management_status );

/**
 * \brief Status of card reader attached to EFT Terminal.
 * 
 * \param[in] terminal_status Object instance of type [terminal_status](\ref terminal_status.h).
 * \param[out] card_reader_status Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em card_reader_status.
 * \retval ta_c_rc_invalid_argument \em terminal_status is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal_status is not of type [terminal_status](\ref terminal_status.h).
 * \retval ta_c_rc_invalid_argument \em card_reader_status is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_status_get_card_reader_status(
	ta_object_t terminal_status,
	ta_e_card_reader_status_t *card_reader_status );

/**
 * \brief Transaction status of EFT Terminal.
 * 
 * \param[in] terminal_status Object instance of type [terminal_status](\ref terminal_status.h).
 * \param[out] transaction_status Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em transaction_status.
 * \retval ta_c_rc_invalid_argument \em terminal_status is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal_status is not of type [terminal_status](\ref terminal_status.h).
 * \retval ta_c_rc_invalid_argument \em transaction_status is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_status_get_transaction_status(
	ta_object_t terminal_status,
	ta_e_transaction_status_t *transaction_status );

/**
 * \brief Sleep mode status of EFT Terminal.
 * 
 * \param[in] terminal_status Object instance of type [terminal_status](\ref terminal_status.h).
 * \param[out] sleep_mode_status Pointer to variable to write value to. Value is
 *                               \em ta_c_sms_undefined if value is not set in \em terminal_status.
 * 
 * \retval ta_c_rc_ok Value written to \em sleep_mode_status.
 * \retval ta_c_rc_invalid_argument \em terminal_status is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal_status is not of type [terminal_status](\ref terminal_status.h).
 * \retval ta_c_rc_invalid_argument \em sleep_mode_status is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_status_get_sleep_mode_status(
	ta_object_t terminal_status,
	ta_e_sleep_mode_status_t *sleep_mode_status );

/**
 * \brief Receipts can be retrieved.
 * 
 * Use ta_terminal_receipt_request or ta_terminal_receipt_request_async.
 * 
 * \param[in] terminal_status Object instance of type [terminal_status](\ref terminal_status.h).
 * \param[out] receipt_information Pointer to variable to write value to. Value is
 *                                 \em ta_c_b_undefined if value is not set in
 *                                 \em terminal_status.
 * 
 * \retval ta_c_rc_ok Value written to \em receipt_information.
 * \retval ta_c_rc_invalid_argument \em terminal_status is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal_status is not of type [terminal_status](\ref terminal_status.h).
 * \retval ta_c_rc_invalid_argument \em receipt_information is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_status_get_receipt_information(
	ta_object_t terminal_status,
	ta_e_boolean_t *receipt_information );

/**
 * \brief Information about payment card used by the customer if present.
 * 
 * \param[in] terminal_status Object instance of type [terminal_status](\ref terminal_status.h).
 * \param[out] card_data Pointer to variable to write object instance to. Object
 *                       instance is of type [card_data](\ref card_data.h) and is not retained. Object
 *                       instance is \em ta_object_invalid if value is not set
 *                       in \em terminal_status.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_data.
 * \retval ta_c_rc_invalid_argument \em terminal_status is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal_status is not of type [terminal_status](\ref terminal_status.h).
 * \retval ta_c_rc_invalid_argument \em card_data is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_status_get_card_data(
	ta_object_t terminal_status,
	ta_object_t *card_data );

/**
 * \brief Software update is available.
 * 
 * \param[in] terminal_status Object instance of type [terminal_status](\ref terminal_status.h).
 * \param[out] sw_update_available Pointer to variable to write value to. Value is
 *                                 \em ta_c_b_undefined if value is not set in
 *                                 \em terminal_status.
 * 
 * \retval ta_c_rc_ok Value written to \em sw_update_available.
 * \retval ta_c_rc_invalid_argument \em terminal_status is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal_status is not of type [terminal_status](\ref terminal_status.h).
 * \retval ta_c_rc_invalid_argument \em sw_update_available is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_status_get_sw_update_available(
	ta_object_t terminal_status,
	ta_e_boolean_t *sw_update_available );

/**
 * \brief If the amount of the original transaction has been adjusted
 * 
 * \param[in] terminal_status Object instance of type [terminal_status](\ref terminal_status.h).
 * \param[out] amount Pointer to variable to write object instance to. Object instance is of type
 *                    [amount_final](\ref amount_final.h) and is not retained. Object instance is
 *                    \em ta_object_invalid if value is not set in \em terminal_status.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_data.
 * \retval ta_c_rc_invalid_argument \em terminal_status is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal_status is not of type [terminal_status](\ref terminal_status.h).
 * \retval ta_c_rc_invalid_argument \em amount is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_status_get_final_amount(
	ta_object_t terminal_status,
	ta_object_t *amount );


#ifdef __cplusplus
}
#endif

#endif
