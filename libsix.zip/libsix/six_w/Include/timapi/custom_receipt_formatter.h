/**
 * \file
 * \brief Custom receipt formatter.
 * \details Object type \em custom_receipt_formatter.
 */

#ifndef TA_CUSTOM_RECEIPT_FORMATTER_H
#define TA_CUSTOM_RECEIPT_FORMATTER_H

#include <stdlib.h>

#include "common/object.h"
#include "constants/result_code.h"
#include "constants/receipt_type.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Custom receipt formatter text types.
 */
typedef enum ta_e_custom_receipt_formatter_text_type{
	/** \brief Static text. */
	ta_c_crftt_text,
	
	/** \brief User identifier. */
	ta_c_crftt_user_id,
	
	/** \brief POS identifier. */
	ta_c_crftt_pos_id,
	
	/** \brief Transaction type. */
	ta_c_crftt_transaction_type,
	
	/** \brief Underline running across the entire line. */
	ta_c_crftt_dashed_line,
	
	/** \brief Header if available (requires calling Terminal.SystemInformationAsync() first. */
	ta_c_crftt_receipt_header,
	
	/** \brief ReceiptItemType.ACT_ID. */
	ta_c_crftt_field_act_id,
	
	/** \brief ReceiptItemType.ACC_PER. */ 
	ta_c_crftt_field_acc_per,
	
	/** \brief ReceiptItemType.ACQ_ID. */ 
	ta_c_crftt_field_acq_id,
	
	/** \brief ReceiptItemType.AID. */
	ta_c_crftt_field_aid,
	
	/** \brief ReceiptItemType.AMOUNT. */
	ta_c_crftt_field_amount,
	
	/** \brief ReceiptItemType.AMOUNT_DCC. */
	ta_c_crftt_field_amount_dcc,
	
	/** \brief ReceiptItemType.AMOUNT_OTHER. */
	ta_c_crftt_field_amount_other,
	
	/** \brief ReceiptItemType.AUTH_CODE. */
	ta_c_crftt_field_auth_code,
	
	/** \brief ReceiptItemType.BRAND_NAME. */
	ta_c_crftt_field_brand_name,
	
	/** \brief ReceiptItemType.CURRENCY. */
	ta_c_crftt_field_currency,
	
	/** \brief ReceiptItemType.CURRENCY_DCC. */
	ta_c_crftt_field_currency_dcc,
	
	/** \brief ReceiptItemType.DCC_DISCLAIMER. */
	ta_c_crftt_field_dcc_disclaimer,
	
	/** \brief ReceiptItemType.DISCLAIMER. */
	ta_c_crftt_field_disclaimer,
	
	/** \brief ReceiptItemType.EXPONENT. */
	ta_c_crftt_field_exponent,
	
	/** \brief ReceiptItemType.EXPONENT_DCC. */
	ta_c_crftt_field_exponent_dcc,
	
	/** \brief ReceiptItemType.MARKUP_DCC. */
	ta_c_crftt_field_markup_dcc,
	
	/** \brief ReceiptItemType.MARKUP_EXPONENT_DCC. */
	ta_c_crftt_field_markup_exponent_dcc,
	
	/** \brief ReceiptItemType.CARD_NUMBER_PRINTABLE_MERCHANT. */
	ta_c_crftt_field_card_number_printable_merchant,
	
	/** \brief ReceiptItemType.CARD_NUMBER_PRINTABLE_CARDHOLDER. */
	ta_c_crftt_field_card_number_printable_cardholder,
	
	/** \brief ReceiptItemType.RATE_DCC. */
	ta_c_crftt_field_rate_dcc,
	
	/** \brief ReceiptItemType.RATE_EXPONENT_DCC. */
	ta_c_crftt_field_rate_exponent_dcc,
	
	/** \brief ReceiptItemType.TIME_STAMP_DATE. */
	ta_c_crftt_field_time_stamp_date,
	
	/** \brief ReceiptItemType.TIME_STAMP_TIME. */
	ta_c_crftt_field_time_stamp_time,
	
	/** \brief ReceiptItemType.TRM_ID. */
	ta_c_crftt_field_trm_id,
	
	/** \brief ReceiptItemType.TRX_REF_NUM. */
	ta_c_crftt_field_trx_ref_num,
	
	/** \brief ReceiptItemType.TRX_SEQ_CNT. */
	ta_c_crftt_field_trx_seq_cnt,
	
	/** \brief ReceiptItemType.POS_ENTRY_MODE entry mode. */
	ta_c_crftt_field_pos_entry_mode,
	
	/** \brief ReceiptItemType.EXP_DATE entry mode. */
	ta_c_crftt_field_card_expiry_date,
	
	/** \brief ReceiptItemType.CARD_NUMBER_ENCRYPTED entry mode. */
	ta_c_crftt_field_card_number_enc,
	
	/** \brief ReceiptItemType.SALDO. */
	ta_c_crftt_field_amount_saldo,
	
	/** \brief ReceiptItemType.ECR_SEQ_CNT. */
	ta_c_crftt_field_ecr_seq_cnt,
	
	/** \brief ReceiptItemType.NUMBER_OF_INSTALLMENTS. */
	ta_c_crftt_field_number_of_installments,
	
	/** \brief ReceiptItemType.INSTALLMENT_DISCLAIMER. */
	ta_c_crftt_field_installment_disclaimer,
	
	/** \brief ReceiptItemType.TENDER_NAME. */
	ta_c_crftt_field_tender_name,
	
	/** \brief ReceiptItemType.TENDER_NAME or ReceiptItemType.BRAND_NAME. */
	ta_c_crftt_field_tender_or_brand_name,
	
	/** \brief ReceiptItemType.MARKUP_DCC. */
	ta_c_crftt_field_markup_dcc_regulated,
	
	/** \brief ReceiptItemType.MARKUP_EXPONENT_DCC. */
	ta_c_crftt_field_markup_exponent_dcc_regulated,
	
	/** \brief ReceiptItemType.RATE_DCC. */
	ta_c_crftt_field_rate_dcc_regulated,
	
	/** \brief ReceiptItemType.RATE_EXPONENT_DCC. */
	ta_c_crftt_field_rate_exponent_dcc_regulated,
	
	/** \brief ReceiptItemType.ORIGINAL_TRANS_REF. */
	ta_c_crftt_field_original_trans_ref,
	
	/** \brief ReceiptItemType.KEY_PAN_RECEIPT_INDEX. */
	ta_c_crftt_field_key_pan_receipt_index,
	
	/** \brief ReceiptItemType.FIELD_PAN_RECEIPT_DOL_INDEX. */
	ta_c_crftt_field_pan_receipt_dol_index,
	
	ta_c_crftt_field_amount_installment_fee,
	ta_c_crftt_field_amount_installment_first,
	ta_c_crftt_field_amount_installment_one,
	ta_c_crftt_field_amount_installment_total,
	ta_c_crftt_field_amount_reservation,
	ta_c_crftt_field_amount_tip,
	ta_c_crftt_field_auth_reslt,
	ta_c_crftt_field_auth_resp_c,
	ta_c_crftt_field_auth_resp_text_c,
	ta_c_crftt_field_clerk_identifier,
	ta_c_crftt_field_fuel_dispenser_number,
	ta_c_crftt_field_interest_installment,
	ta_c_crftt_field_merchant_tid,
	ta_c_crftt_field_multi_account_index,
	ta_c_crftt_field_multi_contract_index,
	ta_c_crftt_field_original_aid,
	ta_c_crftt_field_original_brand_name,
	ta_c_crftt_field_original_card_country_code,
	ta_c_crftt_field_original_card_number_printable,
	ta_c_crftt_field_original_tender_name,
	ta_c_crftt_field_posdnumber,
	ta_c_crftt_field_pan_receipt_dol,
	ta_c_crftt_field_pre_authorization_exp_date,
	ta_c_crftt_field_receipt_number,
	ta_c_crftt_field_shift_number,
	ta_c_crftt_field_card_product_type,
	ta_c_crftt_field_account_type,
	ta_c_crftt_field_surcharge_amount
} ta_e_custom_receipt_formatter_text_type_t;

/**
 * \brief Custom receipt formatter text alignment.
 */
typedef enum ta_e_custom_receipt_formatter_text_alignment{
	ta_c_crfta_left,
	ta_c_crfta_right,
	ta_c_crfta_center
} ta_e_custom_receipt_formatter_text_alignment_t;

/**
 * \brief Custom receipt formatter condition.
 */
typedef enum ta_e_custom_receipt_formatter_condition{
	ta_crfc_none,
	ta_crfc_ecr_info,
	ta_crfc_eft_info,
	ta_crfc_signature,
	ta_crfc_has_values,
	ta_crfc_has_installment,
	ta_crfc_dcc,
	ta_crfc_has_values_no_invalid_fields,
	ta_crfc_header,
	ta_crfc_footer
} ta_e_custom_receipt_formatter_condition_t;

/**
 * \brief Custom receipt formatter translated text.
 */
typedef enum ta_e_custom_receipt_formatter_translated_text{
	ta_crftt_undefined,
	ta_crftt_trx_type_credit,
	ta_crftt_trx_type_purchase,
	ta_crftt_trx_type_reversal,
	ta_crftt_attendant_id,
	ta_crftt_ecr_id,
	ta_crftt_ecr_seq,
	ta_crftt_trm_id,
	ta_crftt_act_id,
	ta_crftt_aid,
	ta_crftt_trx_seq_cnt,
	ta_crftt_trx_curr,
	ta_crftt_local_curr,
	ta_crftt_rate,
	ta_crftt_installment_payment,
	ta_crftt_no_installments,
	ta_crftt_trx_ref_no,
	ta_crftt_original_trans_ref,
	ta_crftt_auth_code,
	ta_crftt_total_eft,
	ta_crftt_cardholder,
	ta_crftt_merchant,
	ta_crftt_saldo,
	ta_crftt_att_ecr_id_seq,
	ta_crftt_eft_ref_no,
	ta_crftt_expiration_date,
	ta_crftt_exp,
	ta_crftt_trm_act_id,
	ta_crftt_seq_ref_auth,
	ta_crftt_epf,
	ta_crftt_seq_aut,
	ta_crftt_account_type,
	ta_crftt_surcharge_amount,
	ta_crftt_acq_id
} ta_e_custom_receipt_formatter_translated_text_t;

/**
 * \brief Custom receipt formatter text element definition.
 * 
 * Can be static text or dynamic content. Used during construction of object.
 */
typedef struct ta_s_custom_receipt_formatter_text_element{
	/** \brief Element type. */
	ta_e_custom_receipt_formatter_text_type_t type;
	
	/** \brief Element alignment. */
	ta_e_custom_receipt_formatter_text_alignment_t alignment;
	
	/**
	 * \brief Static text if type is \em ta_c_crftt_text.
	 * 
	 * If used points to a 0-terminate string. If not used set to 0-pointer. If used
	 * the string is copied during construction of object.
	 */
	const char* text;
	
	/**
	 * \brief Translated text if type is \em ta_c_crftt_text.
	 * 
	 * If not \em ta_crftt_undefined the \em text is used as format string (allowed is
	 * only one single "%s" token) with the translated text applied to it.
	 */
	ta_e_custom_receipt_formatter_translated_text_t translated_text;
	
	/**
	 * \brief Show element only if receipt if of a given type.
	 * 
	 * Use \em ta_c_rt_undefined to always show.
	 */
	ta_e_receipt_type_t receipt_type;
} ta_s_custom_receipt_formatter_text_element_t;

/**
 * \brief Custom receipt formatter line definition.
 * 
 * Contains array of text elements.
 */
typedef struct ta_s_custom_receipt_formatter_line_format{
	/**
	 * \brief Array of elements in the line.
	 * 
	 * Array has to point to valid memory location during construction of the object.
	 * After the object has been constructed the memory location can become invalid.
	 * 
	 * If array count is 0 the array pointer can be 0-pointer.
	 */
	const ta_s_custom_receipt_formatter_text_element_t* elements;
	
	/** \brief Number of elements in array. */
	size_t element_count;
	
	/** \brief Condition. */
	ta_e_custom_receipt_formatter_condition_t condition;
	
	/**
	 * \brief Padding character.
	 * 
	 * Character has to be a valid printable character.
	 */
	char padding;
} ta_s_custom_receipt_formatter_line_format_t;

/**
 * \brief Custom receipt formatter configuration.
 * 
 * Used by ta_custom_receipt_formatter_create to initialize formatter. After the
 * object has been created the struct data is not required anymore.
 */
typedef struct ta_s_custom_receipt_formatter_configuration{
	/**
	 * \brief Array pointing to line formats to use for cardholder receipts.
	 * 
	 * Array has to point to valid memory location during construction of the object.
	 * After the object has been constructed the memory location can become invalid.
	 * 
	 * If array count is 0 the array pointer can be 0-pointer.
	 */
	const ta_s_custom_receipt_formatter_line_format_t* cardholder;
	
	/** \brief Number of elements in \em cardholder array. */
	size_t cardholder_count;
	
	/**
	 * \brief Array pointing to line formats to use for merchant receipts.
	 * 
	 * Array has to point to valid memory location during construction of the object.
	 * After the object has been constructed the memory location can become invalid.
	 * 
	 * If array count is 0 the array pointer can be 0-pointer.
	 */
	const ta_s_custom_receipt_formatter_line_format_t* merchant;
	
	/** \brief Number of elements in \em merchant array. */
	size_t merchant_count;
	
	/**
	 * \brief Array pointing to line formats to use for saldo part of receipts.
	 * 
	 * Array has to point to valid memory location during construction of the object.
	 * After the object has been constructed the memory location can become invalid.
	 * 
	 * If array count is 0 the array pointer can be 0-pointer.
	 */
	const ta_s_custom_receipt_formatter_line_format_t* saldo;
	
	/** \brief Number of elements in \em saldo array. */
	size_t saldo_count;
	
	/**
	 * \brief String to use for not defined or empty values.
	 * 
	 * Points to a 0-terminated string. Recommended default value is "NA".
	 */
	const char* empty_value;
} ta_s_custom_receipt_formatter_configuration_t;



/**
 * \brief Create custom receipt formatter.
 * 
 * Formats transaction receipts using string formating definition. The definition
 * is  required to be valid memory location only during construction time. The
 * receipt formatted stores the information internally during construction time.
 * After the object has been constructed the memory locations can become invalid.
 * 
 * Caller retains a reference to the created instance. While assigning to a terminal
 * instance the terminal instance retains the reference. The user can release the
 * reference directly afterwards. In this case the formatter is destroyed once no
 * terminal instance requires the formatter anymore.
 * 
 * \param[out] formatter Pointer to variable to write created object instance to.
 *                       Created object instance is retained.
 * \param[in] configuration Pointer to struct containinig formatter configuration.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em formatter.
 * \retval ta_c_rc_invalid_argument \em formatter is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em configuration is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_custom_receipt_formatter_create(
	ta_object_t* formatter,
	const ta_s_custom_receipt_formatter_configuration_t* configuration );



/**
 * \brief Create normal receipt format.
 * 
 * Formats transaction receipts using normal receipt format.
 * 
 * Caller retains a reference to the created instance. While assigning to a terminal
 * instance the terminal instance retains the reference. The user can release the
 * reference directly afterwards. In this case the formatter is destroyed once no
 * terminal instance requires the formatter anymore.
 * 
 * \param[out] formatter Pointer to variable to write created object instance to.
 *                       Created object instance is retained. Object is of type
 *                       [custom_receipt_formatter](\ref custom_receipt_formatter.h)
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em formatter.
 * \retval ta_c_rc_invalid_argument \em formatter is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_normal_receipt_formatter_create(
	ta_object_t* formatter );



/**
 * \brief Create compact receipt format.
 * 
 * Formats transaction receipts using compact receipt format.
 * 
 * Caller retains a reference to the created instance. While assigning to a terminal
 * instance the terminal instance retains the reference. The user can release the
 * reference directly afterwards. In this case the formatter is destroyed once no
 * terminal instance requires the formatter anymore.
 * 
 * \param[out] formatter Pointer to variable to write created object instance to.
 *                       Created object instance is retained. Object is of type
 *                       [custom_receipt_formatter](\ref custom_receipt_formatter.h)
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em formatter.
 * \retval ta_c_rc_invalid_argument \em formatter is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_compact_receipt_formatter_create(
	ta_object_t* formatter );



/**
 * \brief Create super compact receipt format.
 * 
 * Formats transaction receipts using super compact receipt format.
 * 
 * Caller retains a reference to the created instance. While assigning to a terminal
 * instance the terminal instance retains the reference. The user can release the
 * reference directly afterwards. In this case the formatter is destroyed once no
 * terminal instance requires the formatter anymore.
 * 
 * \param[out] formatter Pointer to variable to write created object instance to.
 *                       Created object instance is retained. Object is of type
 *                       [custom_receipt_formatter](\ref custom_receipt_formatter.h)
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em formatter.
 * \retval ta_c_rc_invalid_argument \em formatter is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_super_compact_receipt_formatter_create(
	ta_object_t* formatter );



/**
 * \brief Create ultra compact receipt format.
 * 
 * Formats transaction receipts using ultra compact receipt format.
 * 
 * Caller retains a reference to the created instance. While assigning to a terminal
 * instance the terminal instance retains the reference. The user can release the
 * reference directly afterwards. In this case the formatter is destroyed once no
 * terminal instance requires the formatter anymore.
 * 
 * \param[out] formatter Pointer to variable to write created object instance to.
 *                       Created object instance is retained. Object is of type
 *                       [custom_receipt_formatter](\ref custom_receipt_formatter.h)
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em formatter.
 * \retval ta_c_rc_invalid_argument \em formatter is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_ultra_compact_receipt_formatter_create(
	ta_object_t* formatter );


#ifdef __cplusplus
}
#endif

#endif
