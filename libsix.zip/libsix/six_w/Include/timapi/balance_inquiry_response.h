/**
 * \file
 * \brief Balance inquiry Response.
 * \details Object type \em balance_inquiry_response.
 */

#ifndef TA_BALANCE_INQUIRY_RESPONSE_H
#define TA_BALANCE_INQUIRY_RESPONSE_H

#include "common/object.h"
#include "common/boolean.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Amount authorized by the transaction or ta_object_invalid if not provided by EFT.
 * 
 * \param[in] response Object instance of type [balance_inquiry_response](\ref balance_inquiry_response.h).
 * \param[out] amount Pointer to variable to write object instance to. If provided by EFT
 *                    object instance is of type [amount](\ref amount.h) and is not retained.
 *                    If not provided by EFT ta_object_invalid is written to pointer.
 * 
 * \retval ta_c_rc_ok Object instance written to \em amount.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [balance_inquiry_response](\ref balance_inquiry_response.h).
 * \retval ta_c_rc_invalid_argument \em amount is \em null-pointer.
 */
extern ta_e_result_code_t ta_balance_inquiry_response_get_amount(
	ta_object_t response,
	ta_object_t *amount );

/**
 * \brief Print information for merchant and cardholder receipts.
 * 
 * \param[in] response Object instance of type [balance_inquiry_response](\ref balance_inquiry_response.h).
 * \param[out] print_data Pointer to variable to write object instance to. Object instance is
 *                        of type [print_data](\ref print_data.h) and is not retained. Object instance is
 *                        \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em print_data.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [balance_inquiry_response](\ref balance_inquiry_response.h).
 * \retval ta_c_rc_invalid_argument \em print_data is \em null-pointer.
 */
extern ta_e_result_code_t ta_balance_inquiry_response_get_print_data(
	ta_object_t response,
	ta_object_t *print_data );

/**
 * \brief Card data.
 * 
 * \param[in] response Object instance of type [balance_inquiry_response](\ref balance_inquiry_response.h).
 * \param[out] card_data Pointer to variable to write object instance to. Object instance is
 *                       of type [card_data](\ref card_data.h) and is not retained. Object instance is
 *                       \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_data.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [balance_inquiry_response](\ref balance_inquiry_response.h).
 * \retval ta_c_rc_invalid_argument \em card_data is \em null-pointer.
 */
extern ta_e_result_code_t ta_balance_inquiry_response_get_card_data(
	ta_object_t response,
	ta_object_t *card_data );

/**
 * \brief Disclaimer.
 * 
 * \param[in] response Object instance of type [balance_inquiry_response](\ref balance_inquiry_response.h).
 * \param[out] disclaimer Pointer to variable to write object instance to. Object instance is
 *                        of type [string](\ref string.h) and is not retained. Object instance is
 *                        \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em disclaimer.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [balance_inquiry_response](\ref balance_inquiry_response.h).
 * \retval ta_c_rc_invalid_argument \em disclaimer is \em null-pointer.
 */
extern ta_e_result_code_t ta_balance_inquiry_response_get_disclaimer(
	ta_object_t response,
	ta_object_t *disclaimer );

/**
 * \brief Transaction information.
 * 
 * \param[in] response Object instance of type [balance_inquiry_response](\ref balance_inquiry_response.h).
 * \param[out] transaction_information Pointer to variable to write object instance to. Object
 *                                     instance is of type [transaction_information](\ref transaction_information.h) and is
 *                                     not retained. Object instance is \em ta_object_invalid
 *                                     if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em transaction_information.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [balance_inquiry_response](\ref balance_inquiry_response.h).
 * \retval ta_c_rc_invalid_argument \em transaction_information is \em null-pointer.
 */
extern ta_e_result_code_t ta_balance_inquiry_response_get_transaction_information(
	ta_object_t response,
	ta_object_t *transaction_information );


#ifdef __cplusplus
}
#endif

#endif
