/**
 * \file
 * \brief Show signature capture request.
 * \details Object type \em show_signature_capture_request.
 */

#ifndef TA_SHOW_SIGNATURE_CAPTURE_REQUEST_H
#define TA_SHOW_SIGNATURE_CAPTURE_REQUEST_H

#include "color.h"
#include "common/object.h"
#include "common/boolean.h"
#include "constants/brand_mode.h"
#include "constants/resource_id.h"
#include "constants/image_file_format.h"
#include "constants/theme.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create show signature capture request.
 * 
 * \param[out] request Pointer to variable to write created object instance to.
 *                     Created object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_create(
	ta_object_t *request );

/**
 * \brief Create copy of show signature capture request.
 * 
 * \param[out] request Pointer to variable to write created object instance to.
 *                     Created object instance is retained.
 * \param[in] source_request Object of type [show_signature_capture_request](\ref show_signature_capture_request.h) to create copy of.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em source_request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em source_request is not of type
 *                                  \em show_signature_capture_request.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_copy(
	ta_object_t* request,
	const ta_object_t* source_request );



/**
 * \brief Brand bar.
 * 
 * Used if brand mode is \em ta_c_bm_selected.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[out] brand_bar Pointer to variable to write object instance to. Object instance is
 *                       of type [list](\ref list.h) and is not retained. The list contains elements of
 *                       type \em integer. The value of the elements comes from
 *                       \em ta_e_brand_bar_brand_t.
 * 
 * \retval ta_c_rc_ok Object instance written to \em brand_bar.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em brand_bar is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_get_brand_bar(
	ta_object_t request,
	ta_object_t* brand_bar );

/**
 * \brief Set brand bar.
 * 
 * Used if brand mode is \em ta_c_bm_selected.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[in] brand_bar Object instance to set. Object instance has to be of type [list](\ref list.h).
 *                      The list has to contain elements of type [integer](\ref integer.h). The value of
 *                      the elements have to match \em ta_e_brand_bar_brand_t.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em brand_bar is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em brand_bar is not of type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument Element in \em brand_bar is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Element in \em brand_bar is not of type [integer](\ref integer.h).
 */
extern ta_e_result_code_t ta_show_signature_capture_request_set_brand_bar(
	ta_object_t request,
	ta_object_t brand_bar );



/**
 * \brief Brand mode.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[out] brand_mode Pointer to variable to write value to. Value is \em ta_c_bm_undefined
 *                        if value is not set in \em request.
 * 
 * \retval ta_c_rc_ok Value written to \em brand_mode.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em brand_mode is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_get_brand_mode(
	ta_object_t request,
	ta_e_brand_mode_t* brand_mode );

/**
 * \brief Set brand mode.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[in] brand_mode Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em brand_mode is \em ta_c_bm_undefined.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_set_brand_mode(
	ta_object_t request,
	ta_e_brand_mode_t brand_mode );



/**
 * \brief Background color.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[out] background_color Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em background_color.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em background_color is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_get_background_color(
	ta_object_t request,
	ta_s_color_t* background_color );

/**
 * \brief Set background color.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[in] background_color Pointer to value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em background_color is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_set_background_color(
	ta_object_t request,
	const ta_s_color_t* background_color );



/**
 * \brief Image file format to use.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[out] image_file_format Pointer to variable to write value to. Value is
 *                               \em ta_c_iff_undefined if value is not set in \em request.
 * 
 * \retval ta_c_rc_ok Value written to \em image_file_format.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em image_file_format is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_get_image_file_format(
	ta_object_t request,
	ta_e_image_file_format_t* image_file_format );

/**
 * \brief Set image file format to use.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[in] image_file_format Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em image_file_format is \em ta_c_iff_undefined.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_set_image_file_format(
	ta_object_t request,
	ta_e_image_file_format_t image_file_format );



/**
 * \brief Image file width in pixels.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[out] image_file_width Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em image_file_width.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em image_file_width is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_get_image_file_width(
	ta_object_t request,
	int* image_file_width );

/**
 * \brief Set image file width in pixels.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[in] image_file_width Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em image_file_width is less than 1.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_set_image_file_width(
	ta_object_t request,
	int image_file_width );



/**
 * \brief Image file height in pixels.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[out] image_file_height Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em image_file_height.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em image_file_height is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_get_image_file_height(
	ta_object_t request,
	int* image_file_height );

/**
 * \brief Set image file height in pixels.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[in] image_file_height Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em image_file_height is less than 1.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_set_image_file_height(
	ta_object_t request,
	int image_file_height );



/**
 * \brief Resource identifier.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[out] resource_id Pointer to variable to write value to. Value is
 *                         \em ta_c_rid_undefined if value is not set in \em request.
 * 
 * \retval ta_c_rc_ok Value written to \em resource_id.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em resource_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_get_resource_id(
	ta_object_t request,
	ta_e_resource_id_t* resource_id );

/**
 * \brief Set resource identifier.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[in] resource_id Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em resource_id is \em ta_c_rid_undefined.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_set_resource_id(
	ta_object_t request,
	ta_e_resource_id_t resource_id );



/**
 * \brief Signature color.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[out] signature_color Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em signature_color.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em signature_color is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_get_signature_color(
	ta_object_t request,
	ta_s_color_t* signature_color );

/**
 * \brief Set signature color.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[in] signature_color Pointer to value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em signature_color is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_set_signature_color(
	ta_object_t request,
	const ta_s_color_t* signature_color );



/**
 * \brief Theme.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[out] theme Pointer to variable to write value to. Value is
 *                   \em ta_c_theme_undefined if value is not set in \em request.
 * 
 * \retval ta_c_rc_ok Value written to \em theme.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em theme is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_get_theme(
	ta_object_t request,
	ta_e_theme_t* theme );

/**
 * \brief Set theme.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[in] theme Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em theme is \em ta_c_theme_undefined.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_set_theme(
	ta_object_t request,
	ta_e_theme_t theme );



/**
 * \brief Timeout in seconds.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[out] timeout Pointer to variable to write value to. Value is 0 if value is not
 *                     set in \em request.
 * 
 * \retval ta_c_rc_ok Value written to \em timeout.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em timeout is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_get_timeout(
	ta_object_t request,
	int* timeout );

/**
 * \brief Set timeout in seconds.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[in] timeout Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em timeout is \em ta_c_theme_undefined.
 * \retval ta_c_rc_invalid_argument \em timeout is less than 0.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_set_timeout(
	ta_object_t request,
	int timeout );



/**
 * \brief Language.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[out] language Pointer to variable to write object instance to. Object instance is
 *                      of type [string](\ref string.h) and is not retained. Object instance is
 *                      \em ta_object_invalid if value is not set in \em request.
 * 
 * \retval ta_c_rc_ok Object instance written to \em language.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em language is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_get_language(
	ta_object_t request,
	ta_object_t* language );

/**
 * \brief Set language.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[in] language Object instance to set. Object instance can be \em ta_object_invalid
 *                     to clear the value in \em request. If object instance is not
 *                     ta_object_invalid is has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em language is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_show_signature_capture_request_set_language(
	ta_object_t request,
	ta_object_t language );



/**
 * \brief Watermark color.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[out] watermark_color Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em watermark_color.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em watermark_color is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_get_watermark_color(
	ta_object_t request,
	ta_s_color_t* watermark_color );

/**
 * \brief Set watermark color.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[in] watermark_color Pointer to value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em language is not \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_set_watermark_color(
	ta_object_t request,
	const ta_s_color_t* watermark_color );



/**
 * \brief List of watermark items.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[out] watermark_items Pointer to variable to write object instance to. Object instance
 *                             is of type [list](\ref list.h) and is not retained. The list contains elements
 *                             of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em watermark_items.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em watermark_items is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_signature_capture_request_get_watermark_items(
	ta_object_t request,
	ta_object_t* watermark_items );

/**
 * \brief Set list of watermark items.
 * 
 * \param[in] request Object instance of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \param[in] watermark_items Object instance to set. Object instance has to be of type [list](\ref list.h).
 *                            The list has to contain elements of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_signature_capture_request](\ref show_signature_capture_request.h).
 * \retval ta_c_rc_invalid_argument \em watermark_items is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em watermark_items is not of type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument Element in \em watermark_items is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Element in \em watermark_items is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_show_signature_capture_request_set_watermark_items(
	ta_object_t request,
	ta_object_t watermark_items );


#ifdef __cplusplus
}
#endif

#endif
