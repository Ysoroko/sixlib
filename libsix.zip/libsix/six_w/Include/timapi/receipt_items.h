/**
 * \file
 * \brief Receipt items.
 * \details Object type \em receipt_items.
 */

#ifndef TA_RECEIPT_ITEMS_H
#define TA_RECEIPT_ITEMS_H

#include "common/object.h"
#include "constants/receipt_type.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Type of the receipt.
 * 
 * \param[in] receipt_items Object instance of type [receipt_items](\ref receipt_items.h).
 * \param[out] receipt_type Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em receipt_type.
 * \retval ta_c_rc_invalid_argument \em receipt_items is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em receipt_items is not of type [receipt_items](\ref receipt_items.h).
 * \retval ta_c_rc_invalid_argument \em receipt_type is \em null-pointer.
 */
extern ta_e_result_code_t ta_receipt_items_get_receipt_type (
	ta_object_t receipt_items,
	ta_e_receipt_type_t* receipt_type );

/**
 * \brief List of receipt items to be used for this receipt type.
 * 
 * \param[in] receipt_items Object instance of type [receipt_items](\ref receipt_items.h).
 * \param[out] list_items Pointer to variable to write object instance to. Object instance
 *                        is of type [list](\ref list.h) and is not retained. The list contains elements
 *                        of type [receipt_item](\ref receipt_item.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em list_items.
 * \retval ta_c_rc_invalid_argument \em receipt_items is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em receipt_items is not of type [receipt_items](\ref receipt_items.h).
 * \retval ta_c_rc_invalid_argument \em list_items is \em null-pointer.
 */
extern ta_e_result_code_t ta_receipt_items_get_receipt_item (
	ta_object_t receipt_items,
	ta_object_t* list_items );


#ifdef __cplusplus
}
#endif

#endif
