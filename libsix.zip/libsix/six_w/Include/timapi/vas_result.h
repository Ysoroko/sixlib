/**
 * \file
 * \brief Contains VAS result.
 * \details Object type \em vas_result.
 */

#ifndef TA_VAS_RESULT_H
#define TA_VAS_RESULT_H

#include "common/object.h"
#include "common/boolean.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create vas result.
 * 
 * \param[out] vas_result Pointer to variable to write created object instance to.
 *                        Created object instance is retained.
 * \param[in] vas_information_list Object instance is of type [list](\ref list.h) and is retained.
 *                           The list contains values of type [vas_information_list](\ref vas_information_list.h).
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em vas_result.
 * \retval ta_c_rc_invalid_argument \em vas_result is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em vas_information_list is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em vas_information_list is not of type [list](\ref list.h).
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_vas_result_create(
	ta_object_t *vas_result,
	ta_object_t vas_information_list );


/**
 * \brief List of VAS information lists.
 * 
 * \param[in] vas_result Object instance of type [vas_result](\ref vas_result.h).
 * \param[out] vas_information_list Pointer to variable to write object instance to. Object instance
 *                            is of type [list](\ref list.h) and is not retained. The list
 *                            contains entries of type [vas_information_list](\ref vas_information_list.h).
 *                            If list is not present \em ta_object_invalid is written.
 * 
 * \retval ta_c_rc_ok Object instance written to \em vas_information_lists.
 * \retval ta_c_rc_invalid_argument \em vas_result is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em vas_result is not of type [vas_result](\ref vas_result.h).
 * \retval ta_c_rc_invalid_argument \em vas_information_list is \em null-pointer.
 */
extern ta_e_result_code_t ta_vas_result_get_vas_information_list(
	ta_object_t vas_result,
	ta_object_t* vas_information_list );

#ifdef __cplusplus
}
#endif

#endif
