/**
 * \file
 * \brief Reconciliation Response.
 * \details Object type \em reconciliation_response.
 */

#ifndef TA_RECONCILIATION_RESPONSE_H
#define TA_RECONCILIATION_RESPONSE_H

#include "common/object.h"
#include "common/boolean.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Balance counters.
 * 
 * \param[in] response Object instance of type [reconciliation_response](\ref reconciliation_response.h).
 * \param[out] counters Pointer to variable to write object instance to. Object
 *                      instance is of type [counters](\ref counters.h) and is not retained. Object
 *                      instance is \em ta_object_invalid if value is not set
 *                      in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em counters.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [reconciliation_response](\ref reconciliation_response.h).
 * \retval ta_c_rc_invalid_argument \em counters is \em null-pointer.
 */
extern ta_e_result_code_t ta_reconciliation_response_get_counters(
	ta_object_t response,
	ta_object_t *counters );

/**
 * \brief Print information.
 * 
 * \param[in] response Object instance of type [reconciliation_response](\ref reconciliation_response.h).
 * \param[out] print_data Pointer to variable to write object instance to. Object
 *                        instance is of type [print_data](\ref print_data.h) and is not retained. Object
 *                        instance is \em ta_object_invalid if value is not set
 *                        in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em print_data.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [reconciliation_response](\ref reconciliation_response.h).
 * \retval ta_c_rc_invalid_argument \em print_data is \em null-pointer.
 */
extern ta_e_result_code_t ta_reconciliation_response_get_print_data(
	ta_object_t response,
	ta_object_t *print_data );


#ifdef __cplusplus
}
#endif

#endif
