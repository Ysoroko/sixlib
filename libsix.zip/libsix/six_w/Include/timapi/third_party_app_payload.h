/**
 * \file
 * \brief Third party app payload.
 * \details Object type \em third_party_app_payload.
 */

#ifndef TA_THIRD_PARTY_APP_PAYLOAD_H
#define TA_THIRD_PARTY_APP_PAYLOAD_H

#include "common/object.h"
#include "common/boolean.h"
#include "constants/third_party_app_id.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create object of type [third_party_app_payload](\ref third_party_app_payload.h).
 * 
 * \param[out] third_party_app_payload Pointer to variable to write created object instance to.
 *                                     Created object instance is retained.
 * \param[in] third_party_app_id Third party app id.
 * \param[in] data Data. Object of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em third_party_app_payload.
 * \retval ta_c_rc_invalid_argument \em third_party_app_payload is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em third_party_app_id is not a valid value from \em ta_e_third_party_app_id_t.
 * \retval ta_c_rc_invalid_argument \em data is \em ta_object_invalid or not of type [string](\ref string.h).
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_third_party_app_payload_create(
	ta_object_t *third_party_app_payload,
	ta_e_third_party_app_id_t third_party_app_id,
	ta_object_t data );

/**
 * \brief Third party app id.
 * 
 * \param[in] response Object instance of type [third_party_app_payload](\ref third_party_app_payload.h).
 * \param[out] third_party_app_id Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em third_party_app_id.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [third_party_app_payload](\ref third_party_app_payload.h).
 * \retval ta_c_rc_invalid_argument \em third_party_app_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_third_party_app_payload_get_third_party_app_id(
	ta_object_t response,
	ta_e_third_party_app_id_t *third_party_app_id );

/**
 * \brief Third party app payload data.
 * 
 * \param[in] response Object instance of type [third_party_app_payload](\ref third_party_app_payload.h).
 * \param[out] data Pointer to variable to write object instance to. Object instance
 *                  is of type [string](\ref string.h) and is not retained. Object instance
 *                  is \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em data.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [third_party_app_payload](\ref third_party_app_payload.h).
 * \retval ta_c_rc_invalid_argument \em data is \em null-pointer.
 */
extern ta_e_result_code_t ta_third_party_app_payload_get_data(
	ta_object_t response,
	ta_object_t *data );


#ifdef __cplusplus
}
#endif

#endif
