/**
 * \file
 * \brief Show dialog request.
 * \details Object type \em show_dialog_request.
 */

#ifndef TA_SHOW_DIALOG_REQUEST_H
#define TA_SHOW_DIALOG_REQUEST_H

#include "common/object.h"
#include "common/boolean.h"
#include "constants/brand_mode.h"
#include "constants/resource_id.h"
#include "constants/theme.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create show dialog request.
 * 
 * \param[out] request Pointer to variable to write created object instance to.
 *                                 Created object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_show_dialog_request_create(
	ta_object_t *request );

/**
 * \brief Create deep copy of object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * 
 * \param[out] request Pointer to variable to write created object instance to.
 *                    Created object instance is retained.
 * \param[in] source_request Object of type [show_dialog_request](\ref show_dialog_request.h) to create copy of.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em request.
 * \retval ta_c_rc_invalid_argument \em request is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em source_request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em source_request is not of type [show_dialog_request](\ref show_dialog_request.h).
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_show_dialog_request_copy(
	ta_object_t* request,
	const ta_object_t* source_request );



/**
 * \brief Brand bar.
 * 
 * Used if brand mode is \em ta_c_bm_selected.
 * 
 * \param[in] request Object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * \param[out] brand_bar Pointer to variable to write object instance to. Object instance is
 *                       of type [list](\ref list.h) and is not retained. The list contains elements of
 *                       type \em integer. The value of the elements comes from
 *                       \em ta_e_brand_bar_brand_t.
 * 
 * \retval ta_c_rc_ok Object instance written to \em brand_bar.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_dialog_request](\ref show_dialog_request.h).
 * \retval ta_c_rc_invalid_argument \em brand_bar is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_dialog_request_get_brand_bar(
	ta_object_t request,
	ta_object_t* brand_bar );

/**
 * \brief Set brand bar.
 * 
 * Used if brand mode is \em ta_c_bm_selected.
 * 
 * \param[in] request Object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * \param[in] brand_bar Object instance to set. Object instance has to be of type [list](\ref list.h).
 *                      The list has to contain elements of type [integer](\ref integer.h). The value of
 *                      the elements have to match \em ta_e_brand_bar_brand_t.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em brand_bar.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_dialog_request](\ref show_dialog_request.h).
 * \retval ta_c_rc_invalid_argument \em brand_bar is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em brand_bar is not of type [list](\ref list.h).
 * \retval ta_c_rc_invalid_argument Element in \em brand_bar is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Element in \em brand_bar is not of type [integer](\ref integer.h).
 */
extern ta_e_result_code_t ta_show_dialog_request_set_brand_bar(
	ta_object_t request,
	ta_object_t brand_bar );



/**
 * \brief Brand mode.
 * 
 * \param[in] request Object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * \param[out] brand_mode Pointer to variable to write value to. Value is \em ta_c_bm_undefined
 *                        if value is not set in \em request.
 * 
 * \retval ta_c_rc_ok Value written to \em brand_mode.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_dialog_request](\ref show_dialog_request.h).
 * \retval ta_c_rc_invalid_argument \em brand_mode is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_dialog_request_get_brand_mode(
	ta_object_t request,
	ta_e_brand_mode_t* brand_mode );

/**
 * \brief Set brand mode.
 * 
 * \param[in] request Object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * \param[in] brand_mode Value to set. Value can be \em ta_c_bm_undefined to clear the value
 *                       in \em request.
 * 
 * \retval ta_c_rc_ok Value assigned to \em brand_mode.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_dialog_request](\ref show_dialog_request.h).
 */
extern ta_e_result_code_t ta_show_dialog_request_set_brand_mode(
	ta_object_t request,
	ta_e_brand_mode_t brand_mode );



/**
 * \brief Resource identifier.
 * 
 * \param[in] request Object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * \param[out] resource_id Pointer to variable to write value to. Value is \em ta_c_rid_undefined
 *                         if value is not set in \em request.
 * 
 * \retval ta_c_rc_ok Value written to \em resource_id.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_dialog_request](\ref show_dialog_request.h).
 * \retval ta_c_rc_invalid_argument \em resource_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_dialog_request_get_resource_id(
	ta_object_t request,
	ta_e_resource_id_t* resource_id );

/**
 * \brief Set resource identifier.
 * 
 * \param[in] request Object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * \param[in] resource_id Value to set. Value can be \em ta_c_bm_undefined to clear the value
 *                        in \em request.
 * 
 * \retval ta_c_rc_ok Value assigned to \em resource_id.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_dialog_request](\ref show_dialog_request.h).
 */
extern ta_e_result_code_t ta_show_dialog_request_set_resource_id(
	ta_object_t request,
	ta_e_resource_id_t resource_id );



/**
 * \brief Theme.
 * 
 * \param[in] request Object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * \param[out] theme Pointer to variable to write value to. Value is \em ta_c_theme_undefined
 *                   if value is not set in \em request.
 * 
 * \retval ta_c_rc_ok Value written to \em theme.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_dialog_request](\ref show_dialog_request.h).
 * \retval ta_c_rc_invalid_argument \em theme is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_dialog_request_get_theme(
	ta_object_t request,
	ta_e_theme_t* theme );

/**
 * \brief Set theme.
 * 
 * \param[in] request Object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * \param[in] resource_id Value to set. Value can be \em ta_c_theme_undefined to clear
 *                        the value in \em request.
 * 
 * \retval ta_c_rc_ok Value assigned to \em resource_id.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_dialog_request](\ref show_dialog_request.h).
 */
extern ta_e_result_code_t ta_show_dialog_request_set_theme(
	ta_object_t request,
	ta_e_theme_t resource_id );



/**
 * \brief Timeout in seconds.
 * 
 * \param[in] request Object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * \param[out] timeout Pointer to variable to write value to. Value is 0 if value is
 *                     not set in \em request.
 * 
 * \retval ta_c_rc_ok Value written to \em timeout.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_dialog_request](\ref show_dialog_request.h).
 * \retval ta_c_rc_invalid_argument \em timeout is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_dialog_request_get_timeout(
	ta_object_t request,
	int* timeout );

/**
 * \brief Set timeout in seconds.
 * 
 * \param[in] request Object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * \param[in] timeout Value to set. Value can be 0 to clear the value in \em request.
 * 
 * \retval ta_c_rc_ok Value assigned to \em timeout.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_dialog_request](\ref show_dialog_request.h).
 */
extern ta_e_result_code_t ta_show_dialog_request_set_timeout(
	ta_object_t request,
	int timeout );



/**
 * \brief Language.
 * 
 * \param[in] request Object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * \param[out] language Pointer to variable to write object instance to. Object instance is
 *                      of type [string](\ref string.h) and is not retained. Object instance is
 *                      \em ta_object_invalid if value is not set in \em request.
 * 
 * \retval ta_c_rc_ok Object instance written to \em language.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_dialog_request](\ref show_dialog_request.h).
 * \retval ta_c_rc_invalid_argument \em language is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_dialog_request_get_language(
	ta_object_t request,
	ta_object_t* language );

/**
 * \brief Set language.
 * 
 * \param[in] request Object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * \param[in] language Object instance to set. Object instance can be \em ta_object_invalid
 *                     to clear the value in \em request. If object instance is not
 *                     ta_object_invalid is has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em language.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_dialog_request](\ref show_dialog_request.h).
 * \retval ta_c_rc_invalid_argument \em language is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_show_dialog_request_set_language(
	ta_object_t request,
	ta_object_t language );



/**
 * \brief Map of placeholder items.
 * 
 * \param[in] request Object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * \param[out] placeholder_items Pointer to variable to write object instance to. Object instance
 *                               is of type [map](\ref map.h) and is not retained. The map contains keys
 *                               of type [integer](\ref integer.h) and values of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em placeholder_items.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_dialog_request](\ref show_dialog_request.h).
 * \retval ta_c_rc_invalid_argument \em placeholder_items is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_dialog_request_get_placeholder_items(
	ta_object_t request,
	ta_object_t* placeholder_items );

/**
 * \brief Set map of placeholder items.
 * 
 * \param[in] request Object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * \param[in] placeholder_items Object instance to set. Object instance has to be of type
 *                              \em map. The map contains keys of type [integer](\ref integer.h) and values
 *                              of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em placeholder_items.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_dialog_request](\ref show_dialog_request.h).
 * \retval ta_c_rc_invalid_argument \em placeholder_items is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em placeholder_items is not of type [map](\ref map.h).
 * \retval ta_c_rc_invalid_argument Key in \em placeholder_items is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Key in \em placeholder_items is not of type [integer](\ref integer.h).
 * \retval ta_c_rc_invalid_argument Value in \em placeholder_items is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Value in \em placeholder_items is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_show_dialog_request_set_placeholder_items(
	ta_object_t request,
	ta_object_t placeholder_items );



/**
 * \brief Map of resource parameters.
 * 
 * \param[in] request Object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * \param[out] parameters Pointer to variable to write object instance to. Object instance
 *                        is of type [map](\ref map.h) and is not retained. The map contains keys
 *                        of type [integer](\ref integer.h) and values of type [string](\ref string.h). Keys use
 *                        values matching \em ta_e_resource_parameter_type_t.
 * 
 * \retval ta_c_rc_ok Object instance written to \em parameters.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_dialog_request](\ref show_dialog_request.h).
 * \retval ta_c_rc_invalid_argument \em parameters is \em null-pointer.
 */
extern ta_e_result_code_t ta_show_dialog_request_resource_get_parameters(
	ta_object_t request,
	ta_object_t* parameters );

/**
 * \brief Set map of resource parameters.
 * 
 * \param[in] request Object instance of type [show_dialog_request](\ref show_dialog_request.h).
 * \param[in] parameters Object instance to set. Object instance has to be of type [map](\ref map.h).
 *                       The map contains keys of type [integer](\ref integer.h) and values of type [string](\ref string.h).
 *                       Keys use values matching \em ta_e_resource_parameter_type_t.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em parameters.
 * \retval ta_c_rc_invalid_argument \em request is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em request is not of type [show_dialog_request](\ref show_dialog_request.h).
 * \retval ta_c_rc_invalid_argument \em parameters is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em parameters is not of type [map](\ref map.h).
 * \retval ta_c_rc_invalid_argument Key in \em parameters is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Key in \em parameters is not of type [integer](\ref integer.h).
 * \retval ta_c_rc_invalid_argument Value in \em parameters is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument Value in \em parameters is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_show_dialog_request_set_resource_parameters(
	ta_object_t request,
	ta_object_t parameters );


#ifdef __cplusplus
}
#endif

#endif

