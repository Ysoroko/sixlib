/**
 * \file
 * \brief Contains all counters for a specific counter type.
 * 
 * Object type \em counters.
 * 
 * Instances of this class are returned by various calls:
 * <ul>
 * <li>ta_terminal_balance</li>
 * <li>ta_terminal_balance_async</li>
 * <li>ta_terminal_counter_request</li>
 * <li>ta_terminal_counter_request_async</li>
 * <li>ta_terminal_deactivate</li>
 * <li>ta_terminal_deactivate_async</li>
 * <li>ta_terminal_reconciliation</li>
 * <li>ta_terminal_reconciliation_async</li>
 * </ul>
 */

#ifndef TA_COUNTERS_H
#define TA_COUNTERS_H

#include "common/object.h"
#include "constants/counter_type.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Specifies what kind of counter are demanded.
 * 
 * \param[in] counters Object instance of type [counters](\ref counters.h).
 * \param[out] counter_type Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em counter_type.
 * \retval ta_c_rc_invalid_argument \em counters is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em counters is not of type [counters](\ref counters.h).
 * \retval ta_c_rc_invalid_argument \em counter_type is \em null-pointer.
 */
extern ta_e_result_code_t ta_counters_get_counter_type(
	ta_object_t counters,
	ta_e_counter_type_t* counter_type );

/**
 * \brief Activation or period sequence counter depending on type.
 * 
 * \param[in] counters Object instance of type [counters](\ref counters.h).
 * \param[out] seq_counter Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em seq_counter.
 * \retval ta_c_rc_invalid_argument \em counters is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em counters is not of type [counters](\ref counters.h).
 * \retval ta_c_rc_invalid_argument \em seq_counter is \em null-pointer.
 */
extern ta_e_result_code_t ta_counters_get_seq_counter(
	ta_object_t counters,
	int* seq_counter );

/**
 * \brief Counters per brand.
 * 
 * \param[in] counters Object instance of type [counters](\ref counters.h).
 * \param[out] list_counters Pointer to variable to write object instance to. Object instance
 *                           is of type [list](\ref list.h) and is not retained. The list contains elements
 *                           of type [counter](\ref counter.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em list_counters.
 * \retval ta_c_rc_invalid_argument \em counters is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em counters is not of type [counters](\ref counters.h).
 * \retval ta_c_rc_invalid_argument \em list_counters is \em null-pointer.
 */
extern ta_e_result_code_t ta_counters_get_counters(
	ta_object_t counters,
	ta_object_t* list_counters );

/**
 * \brief Optional print data. Present only in ta_c_rt_counter_request.
 * 
 * \param[in] counters Object instance of type [counters](\ref counters.h).
 * \param[out] print_data Pointer to variable to write object instance to. Object instance
 *                        is of type [print_data](\ref print_data.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em list_counters.
 * \retval ta_c_rc_invalid_argument \em counters is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em counters is not of type [counters](\ref counters.h).
 * \retval ta_c_rc_invalid_argument \em print_data is \em null-pointer.
 */
extern ta_e_result_code_t ta_counters_get_print_data(
	ta_object_t counters,
	ta_object_t* print_data );


#ifdef __cplusplus
}
#endif

#endif
