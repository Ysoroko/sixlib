/**
 * \file
 * \brief PpInfo.
 * \details Object type \em ppinfo.
 */

#ifndef TA_PPINFO_H
#define TA_PPINFO_H

#include "common/object.h"
#include "common/boolean.h"
#include "constants/payment_protocol.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Specifies the payment protocol used.
 * 
 * Specification: <em>retail</em>.
 * 
 * \param[in] response Object instance of type [ppinfo](\ref ppinfo.h).
 * \param[out] payment_protocol Pointer to variable to write value to.
 
 * 
 * \retval ta_c_rc_ok Value written to \em payment_protocol.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [ppinfo](\ref ppinfo.h).
 * \retval ta_c_rc_invalid_argument \em payment_protocol is \em null-pointer.
 */
extern ta_e_result_code_t ta_ppinfo_get_payment_protocol(
	ta_object_t response,
	ta_e_payment_protocol_t* payment_protocol );

/**
 * \brief Payment protocol specific transaction sequence counter,
 *        which refers to a previous transaction
 * <p>Optional: Mandatory if payment protocol provides info.</p>
 * <p>Specification: <em>retail</em>.</p>
 * 
 * \param[in] response Object instance of type [ppinfo](\ref ppinfo.h).
 * \param[out] pp_ep2_trans_seq_cnt_orig Pointer to variable to write value to. Object 
 *                      instance of type [integer](\ref integer.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Value written to \em pp_ep2_trans_seq_cnt_orig.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [ppinfo](\ref ppinfo.h).
 * \retval ta_c_rc_invalid_argument \em pp_ep2_trans_seq_cnt_orig is \em null-pointer.
 */
extern ta_e_result_code_t ta_ppinfo_get_pp_ep2_trans_seq_cnt(
	ta_object_t response,
	ta_object_t* pp_ep2_trans_seq_cnt_orig );

/**
 * \brief Payment protocol specific original transaction sequence counter,
 *        which refers to a previous transaction
 * <p>Optional: Mandatory if payment protocol provides info.</p>
 * <p>Specification: <em>retail</em>.</p>
 * 
 * \param[in] response Object instance of type [ppinfo](\ref ppinfo.h).
 * \param[out] pp_ep2_trans_seq_cnt_orig Pointer to variable to write value to. Object 
 *                      instance of type [integer](\ref integer.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Value written to \em pp_ep2_trans_seq_cnt_orig.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [ppinfo](\ref ppinfo.h).
 * \retval ta_c_rc_invalid_argument \em pp_ep2_trans_seq_cnt_orig is \em null-pointer.
 */
extern ta_e_result_code_t ta_ppinfo_get_pp_ep2_trans_seq_cnt_orig(
	ta_object_t response,
	ta_object_t* pp_ep2_trans_seq_cnt_orig );

/**
 * \brief Payment protocol specific authorisation result.
 * 
 * <p>Optional: Mandatory if payment protocol provides info.</p>
 * <p>Specification: <em>retail</em>.</p>
 * 
 * \param[in] response Object instance of type [ppinfo](\ref ppinfo.h).
 * \param[out] pp_ep2_auth_reslt Pointer to variable to write value to. Object 
 *                      instance of type [integer](\ref integer.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Value written to \em pp_ep2_auth_reslt.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [ppinfo](\ref ppinfo.h).
 * \retval ta_c_rc_invalid_argument \em pp_ep2_auth_reslt is \em null-pointer.
 */
extern ta_e_result_code_t ta_ppinfo_get_pp_ep2_auth_reslt(
	ta_object_t response,
	ta_object_t* pp_ep2_auth_reslt );

/**
 * \brief Payment protocol specific authorisation response code.
 * 
 * <p>Optional: Mandatory if payment protocol provides info.</p>
 * <p>Specification: <em>retail</em>.</p>
 * 
 * \param[in] response Object instance of type [ppinfo](\ref ppinfo.h).
 * \param[out] pp_ep2_auth_resp_c Pointer to variable to write object instance to. Object instance
 *                                is of type [string](\ref string.h) and is not retained.
 *                                Object instance is \em ta_object_invalid if value is not
 *                                set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em pp_ep2_auth_resp_c.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [ppinfo](\ref ppinfo.h).
 * \retval ta_c_rc_invalid_argument \em pp_ep2_auth_resp_c is \em null-pointer.
 */
extern ta_e_result_code_t ta_ppinfo_get_pp_ep2_auth_resp_c(
	ta_object_t response,
	ta_object_t *pp_ep2_auth_resp_c );


#ifdef __cplusplus
}
#endif

#endif
