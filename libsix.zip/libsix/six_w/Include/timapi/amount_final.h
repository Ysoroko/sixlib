/**
 * \file
 * \brief Final amount.
 * \details Object type \em amount_final.
 */

#ifndef TA_AMOUNT_FINAL_H
#define TA_AMOUNT_FINAL_H

#include <stdint.h>

#include "common/object.h"
#include "constants/adjustment_result.h"
#include "constants/currency.h"


#ifdef __cplusplus
extern "C" {
#endif


	/**
 * \brief Amount in minor units.
 * 
 * \param[in] amount_final Object instance of type [amount_final](\ref amount_final.h).
 * \param[out] value Pointer to variable to write value to. Use \em ta_amount_final_get_exponent
 *                   to get the used exponent. This can be a different exponent than the
 *                   one defined by the used currency.
 * 
 * \retval ta_c_rc_ok Value written to \em value.
 * \retval ta_c_rc_invalid_argument \em amount_final is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount_final is not of type [amount_final](\ref amount_final.h).
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_final_get_value(
	ta_object_t amount_final,
	int64_t *value );

/**
 * \brief Amount in major units as double precision floating point value.
 * 
 * \note Double precision floating point values can not provide the same level of numerical
 *       accuracy as int64_t. It is recommended to use the integer based methods.
 * 
 * \param[in] amount_final Object instance of type [amount_final](\ref amount_final.h).
 * \param[out] value Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em value.
 * \retval ta_c_rc_invalid_argument \em amount_final is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount_final is not of type [amount_final](\ref amount_final.h).
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_final_get_decimal_value(
	ta_object_t amount_final,
	double *value );

/**
 * \brief Currency.
 * 
 * \param[in] amount_final Object instance of type [amount_final](\ref amount_final.h).
 * \param[out] currency Pointer to variable to write currency to.
 * 
 * \retval ta_c_rc_ok Value written to \em currency.
 * \retval ta_c_rc_invalid_argument \em amount_final is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount_final is not of type [amount_final](\ref amount_final.h).
 * \retval ta_c_rc_invalid_argument \em currency is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_final_get_currency(
	ta_object_t amount_final,
	ta_e_currency_t *currency );

/**
 * \brief Exponent.
 * 
 * \param[in] amount_final Object instance of type [amount_final](\ref amount_final.h).
 * \param[out] exponent Pointer to variable to write exponent to.
 * 
 * \retval ta_c_rc_ok Value written to \em exponent.
 * \retval ta_c_rc_invalid_argument \em amount_final is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount_final is not of type [amount_final](\ref amount_final.h).
 * \retval ta_c_rc_invalid_argument \em exponent is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_final_get_exponent(
	ta_object_t amount_final,
	int *exponent );

/**
 * \brief Adjustment result.
 * 
 * \param[in] amount_final Object instance of type [amount_final](\ref amount_final.h).
 * \param[out] adjustment_result Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em currency.
 * \retval ta_c_rc_invalid_argument \em amount_final is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount_final is not of type [amount_final](\ref amount_final.h).
 * \retval ta_c_rc_invalid_argument \em adjustment_result is \em null-pointer.
 */
extern ta_e_result_code_t ta_amount_final_get_adjustment_result(
	ta_object_t amount_final,
	ta_e_adjustment_result_t *adjustment_result );


#ifdef __cplusplus
}
#endif

#endif
