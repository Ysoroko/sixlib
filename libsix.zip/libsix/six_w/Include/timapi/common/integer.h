/**
 * \file
 * \brief Integer value.
 * \details Object type \em integer.
 */

#ifndef TA_INTEGER_H
#define TA_INTEGER_H


#include <stdint.h>

#include "object.h"
#include "../constants/result_code.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create immutable 64-bit integer instance.
 * 
 * Caller retains a reference to the created integer. Different users can
 * individually retain the integer instance themselves by calling
 * ta_object_retain. Each call to \ref ta_object_retain and \ref ta_integer_create
 * has to be matched with a call to ta_object_release. The integer instance
 * is destroyed once nobody retains the integer instance anymore.
 * 
 * \param[out] integer Pointer to variable to write created object instance to.
 *                     Created object instance is retained.
 * \param[in] value Value of integer.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em integer.
 * \retval ta_c_rc_invalid_argument \em integer is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_integer_create(
	ta_object_t *integer,
	int64_t value );


/**
 * \brief Get value of integer.
 * 
 * \param[in] integer Object instance of type [integer](\ref integer.h).
 * \param[out] value Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em value.
 * \retval ta_c_rc_invalid_argument \em integer is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em integer is not of type [integer](\ref integer.h).
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 */
extern ta_e_result_code_t ta_integer_get_value(
	ta_object_t integer,
	int64_t *value );


#ifdef __cplusplus
}
#endif

#endif
