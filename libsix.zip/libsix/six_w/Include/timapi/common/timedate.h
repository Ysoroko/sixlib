/**
 * \file
 * \brief Time-Date value.
 * \details Object type \em timedate.
 */

#ifndef TA_TIMEDATE_H
#define TA_TIMEDATE_H

#include <stdarg.h>

#include "object.h"
#include "../constants/result_code.h"


/**
 * \brief Time-date.
 */
typedef struct ta_s_timedate{
	/** \brief Year since 0. */
	int year;
	
	/** \brief Month since January - [0,11]. */
	int month;
	
	/** \brief Day of the month - [1,31]. */
	int day;
	
	/** \brief Hour since midnight - [0,23]. */
	int hour;
	
	/** \brief Minute after the hour - [0,59]. */
	int minute;
	
	/** \brief Second after the minute - [0,59]. */
	int second;
} ta_s_timedate_t;


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Get values of time-date in struct.
 * 
 * Depending on the origin of the time-date not all values are used.
 * 
 * \param[in] timedate Object instance of type [timedate](\ref timedate.h).
 * \param[out] values Pointer to variable to write values to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em values.
 * \retval ta_c_rc_invalid_argument \em timedate is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em timedate is not of type [timedate](\ref timedate.h).
 * \retval ta_c_rc_invalid_argument \em values is \em null-pointer.
 */
extern ta_e_result_code_t ta_timedate_get_values(
	ta_object_t timedate,
	ta_s_timedate_t *values );

/**
 * \brief Create time date representing.
 * 
 * Caller retains a reference to the created timedate. Different users can individually
 * retain the timedate instance themselves by calling ta_object_retain. Each call to
 * \ref ta_object_retain and \ref ta_timedate_create has to be matched with a call to
 * \ref ta_object_release. The timedate instance is destroyed once nobody retains the
 * timedate instance anymore.
 * 
 * \param[out] timedate Pointer to variable to write created object instance to.
 *                      Created object instance is retained.
 * \param[in] values Pointers to struct with time and date values. Memory is not stored
 *                   by the object instance and can be released after the call returns.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em timedate.
 * \retval ta_c_rc_invalid_argument \em timedate is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em values is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_timedate_create(
	ta_object_t *timedate,
	const ta_s_timedate_t *values );


#ifdef __cplusplus
}
#endif

#endif
