/**
 * \file
 * \brief Boolean value.
 * \details Object type \em boolean.
 */

#ifndef TA_BOOLEAN_H
#define TA_BOOLEAN_H


#include "object.h"
#include "../constants/result_code.h"


#ifdef __cplusplus
extern "C" {
#endif

	
/** \brief Boolean value. */
typedef enum ta_e_boolean {
	/** \brief Invalid/undefined. */
	ta_c_b_undefined,
	
	/** \brief True value. */
	ta_c_b_true,
	
	/** \brief False value. */
	ta_c_b_false
} ta_e_boolean_t;


/**
 * \brief Create immutable boolean instance.
 * 
 * Caller retains a reference to the created boolean. Different users can
 * individually retain the boolean instance themselves by calling
 * ta_object_retain. Each call to \ref ta_object_retain and \ref ta_boolean_create
 * has to be matched with a call to \ref ta_object_release. The boolean instance
 * is destroyed once nobody retains the boolean instance anymore.
 * 
 * \param[out] boolean Pointer to variable to write created object instance to.
 *                     Created object instance is retained.
 * \param[in] value Value of boolean.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em boolean.
 * \retval ta_c_rc_invalid_argument \em boolean is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_boolean_create(
	ta_object_t *boolean,
	ta_e_boolean_t value );


/**
 * \brief Get value of boolean.
 * 
 * \param[in] boolean Object instance of type [boolean](\ref boolean.h).
 * \param[out] value Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em value.
 * \retval ta_c_rc_invalid_argument \em boolean is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em boolean is not of type [boolean](\ref boolean.h).
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 */
extern ta_e_result_code_t ta_boolean_get_value(
	ta_object_t boolean,
	ta_e_boolean_t *value );


#ifdef __cplusplus
}
#endif

#endif
