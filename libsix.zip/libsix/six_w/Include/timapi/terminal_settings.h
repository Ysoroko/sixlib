/**
 * \file
 * \brief Terminal settings.
 * \details Object type \em terminal_settings.
 */

#ifndef TA_TERMINAL_SETTINGS_H
#define TA_TERMINAL_SETTINGS_H

#include "common/object.h"
#include "common/boolean.h"
#include "constants/connection_mode.h"
#include "constants/protocol_type.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create terminal settings.
 * 
 * Caller retains a reference to the created instance. Different users can
 * individually retain the terminal instance themselves by calling
 * ta_object_retain. Each call to \ref ta_object_retain and \ref ta_terminal_settings_create
 * has to be matched with a call to \ref ta_object_release. The terminal instance
 * is destroyed once nobody retains the terminal instance anymore.
 * 
 * Newly created terminal settings instances are mutable. Use ta_terminal_settings_freeze
 * to turn terminal settings instances immutable. Frozen terminal instances return
 * an error if setter functions are called. Terminal settings returned by the API
 * are immutable by default.
 * 
 * \param[out] settings Pointer to variable to write created object instance to.
 *                    Created object instance is retained.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em null-pointer.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_terminal_settings_create(
	ta_object_t *settings );



/**
 * \brief Deprecated: Defines where the Log File has to be generated.
 * 
 * \deprecated Can not be used.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] log_dir Pointer to variable to write object instance to. Object
 *                     instance is of type [string](\ref string.h) and is not retained.
 *                     in \em settings.
 * 
 * \retval ta_c_rc_ok Object instance written to \em log_dir.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em log_dir is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_log_dir(
	ta_object_t settings,
	ta_object_t *log_dir );

/**
 * \brief Deprecated: Set where the Log File has to be generated.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] log_dir Object instance to set. Object instance has to be of type [string](\ref string.h).
 * 
 * \deprecated Can not be used.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em log_dir is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em log_dir is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_log_dir(
	ta_object_t settings,
	ta_object_t log_dir );



/**
 * \brief Deprecated: Number of log files to keep before archiving them.
 * 
 * 0 to disable using log files.
 * 
 * \deprecated Can not be used.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] file_count Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em file_count.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em file_count is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_log_retain_file_count(
	ta_object_t settings,
	int *file_count );

/**
 * \brief Deprecated: Set number of log files to keep before archiving them.
 * 
 * 0 to disable using log files.
 * 
 * \deprecated Can not be used.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] retain_file_count Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em retain_file_count is less than 0.
 */
extern ta_e_result_code_t ta_terminal_settings_set_log_retain_file_count(
	ta_object_t settings,
	int retain_file_count );



/**
 * \brief Deprecated: Number of log files to keep before per archive file.
 * 
 * \deprecated Can not be used.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] file_count_per_archive Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em file_count_per_archive.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em file_count_per_archive is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_log_file_count_per_archive(
	ta_object_t settings,
	int *file_count_per_archive );

/**
 * \brief Deprecated: Set number of log files to keep before per archive file.
 * 
 * \deprecated Can not be used.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] log_file_count_per_archive Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em log_file_count_per_archive is less than 0.
 */
extern ta_e_result_code_t ta_terminal_settings_set_log_file_count_per_archive(
	ta_object_t settings,
	int log_file_count_per_archive );



/**
 * \brief Deprecated: Number of log file archives to keep before deleting them.
 * 
 * 0 to disable using archive files.
 * 
 * \deprecated Can not be used.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] archive_count Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em archive_count.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em archive_count is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_log_retain_archive_count(
	ta_object_t settings,
	int *archive_count );

/**
 * \brief Deprecated: Set number of log file archives to keep before deleting them.
 * 
 * 0 to disable using archive files.
 * 
 * \deprecated Can not be used.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] log_retain_archive_count Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em log_retain_archive_count is less than 0.
 */
extern ta_e_result_code_t ta_terminal_settings_set_log_retain_archive_count(
	ta_object_t settings,
	int log_retain_archive_count );



/**
 * \brief Terminal ID to be broadcasted in case of ConnectionMode Broadcast.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] terminal_id Pointer to variable to write object instance to. Object
 *                         instance is of type [string](\ref string.h) and is not retained.
 *                         in \em settings.
 * 
 * \retval ta_c_rc_ok Object instance written to \em terminal_id.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em terminal_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_terminal_id(
	ta_object_t settings,
	ta_object_t *terminal_id );

/**
 * \brief Set terminal ID to be broadcasted in case of ConnectionMode Broadcast.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] terminal_id Object instance to set. Object instance has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em terminal_id is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal_id is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_terminal_id(
	ta_object_t settings,
	ta_object_t terminal_id );



/**
 * \brief Broadcast (default) or OnFixIP.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] connection_mode Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em connection_mode.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em connection_mode is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_connection_mode(
	ta_object_t settings,
	ta_e_connection_mode_t *connection_mode );

/**
 * \brief Set broadcast (default) or OnFixIP.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] connection_mode Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_connection_mode(
	ta_object_t settings,
	ta_e_connection_mode_t connection_mode );



/**
 * \brief IP address of the EFT terminal in case of ConnectionMode OnFixIP.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] connection_ip_string Pointer to variable to write object instance to. Object
 *                                  instance is of type [string](\ref string.h) and is not retained.
 *                                  in \em settings.
 * 
 * \retval ta_c_rc_ok Object instance written to \em connection_ip_string.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em connection_ip_string is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_connection_ip_string(
	ta_object_t settings,
	ta_object_t *connection_ip_string );

/**
 * \brief Set IP address of the EFT terminal in case of ConnectionMode OnFixIP.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] connection_ip_string Object instance to set. Object instance has to be of type
 *                                 \em string.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em connection_ip_string is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_connection_ip_string(
	ta_object_t settings,
	ta_object_t connection_ip_string );



/**
 * \brief Listening Port of the EFT terminal in case of ConnectionMode OnFixIP.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] connection_ip_port Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em connection_ip_port.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em connection_ip_port is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_connection_ip_port(
	ta_object_t settings,
	int *connection_ip_port );

/**
 * \brief Listening Port of the EFT terminal in case of ConnectionMode OnFixIP.
 * 
 * \param[in] settings Value of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] connection_ip_port Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_connection_ip_port(
	ta_object_t settings,
	int connection_ip_port );



/**
 * \brief IP address of the ECR if listening.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] ip_string Pointer to variable to write object instance to. Object
 *                       instance is of type [string](\ref string.h) and is not retained.
 *                       in \em settings.
 * 
 * \retval ta_c_rc_ok Object instance written to \em ip_string.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em ip_string is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_connection_listen_ip_string(
	ta_object_t settings,
	ta_object_t *ip_string );

/**
 * \brief Set IP address of the ECR if listening.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] ip_string Object instance to set. Object instance has to be of type \em string.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em ip_string is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_connection_listen_ip_string(
	ta_object_t settings,
	ta_object_t ip_string );



/**
 * \brief Listening Port of the ECR if listening.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] ip_port Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em connection_ip_port.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em ip_port is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_connection_listen_ip_port(
	ta_object_t settings,
	int *ip_port );

/**
 * \brief Listening Port of the ECR if listening.
 * 
 * \param[in] settings Value of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] ip_port Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_connection_listen_ip_port(
	ta_object_t settings,
	int ip_port );



/**
 * \brief Interface to use for broadcasting or empty string to broadcast on all
 *        available interfaces.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] broadcast_interface Pointer to variable to write object instance to. Object
 *                                 instance is of type [string](\ref string.h) and is not retained.
 *                                 in \em settings.
 * 
 * \retval ta_c_rc_ok Object instance written to \em broadcast_interface.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em broadcast_interface is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_broadcast_interface(
	ta_object_t settings,
	ta_object_t *broadcast_interface );

/**
 * \brief Set Interface to use for broadcasting or empty string to broadcast on all
 *        available interfaces.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] broadcast_interface Object instance to set. Object instance has to be of type
 *                                \em string.
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em broadcast_interface is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em broadcast_interface is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_broadcast_interface(
	ta_object_t settings,
	ta_object_t broadcast_interface );



/**
 * \brief EFT connects to ECR instead of ECR connecting to EFT, which is the default way to connect..
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] connection_listen Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em connection_listen.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em connection_listen is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_connection_listen(
	ta_object_t settings,
	ta_e_boolean_t *connection_listen );

/**
 * \brief EFT connects to ECR instead of ECR connecting to EFT, which is the default way to connect..
 * 
 * \param[in] settings Value of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] connection_listen Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_connection_listen(
	ta_object_t settings,
	ta_e_boolean_t connection_ip_port );



/**
 * \brief Protocol type.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] protocol_type Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em protocol_type.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em protocol_type is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_protocol_type(
	ta_object_t settings,
	ta_e_protocol_type_t *protocol_type );

/**
 * \brief Set protocol type.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] protocol_type Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_protocol_type(
	ta_object_t settings,
	ta_e_protocol_type_t protocol_type );



/**
 * \brief Integrator identifier.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] integrator_id Pointer to variable to write object instance to. Object
 *                           instance is of type [string](\ref string.h) and is not retained.
 *                           in \em settings.
 * 
 * \retval ta_c_rc_ok Object instance written to \em integrator_id.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em integrator_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_integrator_id(
	ta_object_t settings,
	ta_object_t *integrator_id );

/**
 * \brief Set integrator identifier.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] integrator_id Object instance to set. Object instance has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em integrator_id is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em integrator_id is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_integrator_id(
	ta_object_t settings,
	ta_object_t integrator_id );



/**
 * \brief Required guides.
 * 
 * Login succeeds only if the terminal is able to provide all requested guides.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] guides Pointer to variable to write value to. OR combination of values
 *                    from \em ta_e_guides_t.
 * 
 * \retval ta_c_rc_ok Object instance written to \em guides.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em guides is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_guides(
	ta_object_t settings,
	int *guides );

/**
 * \brief Required guides.
 * 
 * Login succeeds only if the terminal is able to provide all requested guides.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] guides Value to set. OR combination of values from \em ta_e_guides_t.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_guides(
	ta_object_t settings,
	int guides );



/**
 * \brief Manufacturer flags.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] manufacturer_flags Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em manufacturer_flags.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em manufacturer_flags is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_manufacturer_flags(
	ta_object_t settings,
	int *manufacturer_flags );

/**
 * \brief Set manufacturer flags.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] manufacturer_flags Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_manufacturer_flags(
	ta_object_t settings,
	int manufacturer_flags );



/**
 * \brief Automatically retrieves application information during logging in.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] is_fetch_brands Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em is_fetch_brands.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em is_fetch_brands is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_is_fetch_brands(
	ta_object_t settings,
	ta_e_boolean_t *is_fetch_brands );

/**
 * \brief Automatically retrieves application information during logging in.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] fetch_brands Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_fetch_brands(
	ta_object_t settings,
	ta_e_boolean_t fetch_brands );



/**
 * \brief After executing the Transaction- function the API commits the transaction automatically.
 * 
 * If \em ta_c_b_undefined uses \em ta_c_b_true/ta_c_b_false depending on the other settings, namely:
 * <ul>
 * <li>If Unattended Guide is enabled: \em ta_c_b_false</li>
 * <li>Otherwise: \em ta_c_b_true</li>
 * </ul>
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] is_auto_commit Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em is_auto_commit.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em is_auto_commit is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_is_auto_commit(
	ta_object_t settings,
	ta_e_boolean_t *is_auto_commit );

/**
 * \brief After executing the Transaction- function the API commits the transaction automatically.
 * 
 * If \em auto_commit is \em ta_c_b_undefined uses \em ta_c_b_true/ta_c_b_false depending
 * on the other settings, namely:
 * <ul>
 * <li>If Unattended Guide is enabled: \em ta_c_b_false</li>
 * <li>Otherwise: \em ta_c_b_true</li>
 * </ul>
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] auto_commit Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_auto_commit(
	ta_object_t settings,
	ta_e_boolean_t auto_commit );



/**
 * \brief Shift management is handled automatically.
 * 
 * Required if device does not support Activate and Deactivate functions.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] is_auto_shift_management Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em is_auto_shift_management.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em is_auto_shift_management is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_is_auto_shift_management(
	ta_object_t settings,
	ta_e_boolean_t *is_auto_shift_management );

/**
 * \brief Shift management is handled automatically.
 * 
 * Required if device does not support Activate and Deactivate functions.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] auto_shift_management Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_auto_shift_management(
	ta_object_t settings,
	ta_e_boolean_t auto_shift_management );



/**
 * \brief Shutter management is handled automatically.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] is_auto_shutter_management Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em is_auto_shutter_management.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em is_auto_shutter_management is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_is_auto_shutter_management(
	ta_object_t settings,
	ta_e_boolean_t *is_auto_shutter_management );

/**
 * \brief Shutter management is handled automatically.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] auto_shutter_management Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_auto_shutter_management(
	ta_object_t settings,
	ta_e_boolean_t auto_shutter_management );



/**
 * \brief Automatically retrieves system information during logging in.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] is_auto_sys_info Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em is_auto_sys_info.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em is_auto_shutter_management is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_is_auto_sys_info(
	ta_object_t settings,
	ta_e_boolean_t *is_auto_sys_info );

/**
 * \brief Automatically retrieves system information during logging in.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] auto_sys_info Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_auto_sys_info(
	ta_object_t settings,
	ta_e_boolean_t auto_sys_info );



/**
 * \brief Timeout in seconds the terminal waits for a card to be inserted before
 *        canceling an open transaction request.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] card_insertion_timeout Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_insertion_timeout.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em card_insertion_timeout is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_card_insertion_timeout(
	ta_object_t settings,
	int *card_insertion_timeout );

/**
 * \brief Timeout in seconds the terminal waits for a card to be inserted before
 *        canceling an open transaction request.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] card_insertion_timeout Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em card_insertion_timeout is less than 0.
 */
extern ta_e_result_code_t ta_terminal_settings_set_card_insertion_timeout(
	ta_object_t settings,
	int card_insertion_timeout );



/**
 * \brief Timeout in seconds the terminal waits for a card to be removed before
 *        requesting attendant interaction.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] card_removal_timeout Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_removal_timeout.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em card_removal_timeout is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_card_removal_timeout(
	ta_object_t settings,
	int *card_removal_timeout );

/**
 * \brief Timeout in seconds the terminal waits for a card to be removed before
 *        requesting attendant interaction.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] card_removal_timeout Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em card_removal_timeout is less than 0.
 */
extern ta_e_result_code_t ta_terminal_settings_set_card_removal_timeout(
	ta_object_t settings,
	int card_removal_timeout );



/**
 * \brief Timeout in seconds the terminal waits until the technical auto-reversal
 *        is processed, if no commit received.
 * 
 * Timer starts with response and is reset in case client enters information
 * in the terminal. 
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] commit_timeout Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em commit_timeout.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em commit_timeout is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_commit_timeout(
	ta_object_t settings,
	int *commit_timeout );

/**
 * \brief Timeout in seconds the terminal waits until the technical auto-reversal
 *        is processed, if no commit received.
 * 
 * Timer starts with response and is reset in case client enters information
 * in the terminal. 
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] commit_timeout Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em commit_timeout is less than 0.
 */
extern ta_e_result_code_t ta_terminal_settings_set_commit_timeout(
	ta_object_t settings,
	int commit_timeout );



/**
 * \brief Dcc shall be supported.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] is_dcc Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em is_dcc.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em is_dcc is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_is_dcc(
	ta_object_t settings,
	ta_e_boolean_t *is_dcc );

/**
 * \brief Set if Dcc shall be supported. 
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] dcc Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_dcc(
	ta_object_t settings,
	ta_e_boolean_t dcc );



/**
 * \brief Partial approval shall be supported.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] is_partial_approval Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em is_partial_approval.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em is_partial_approval is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_is_partial_approval(
	ta_object_t settings,
	ta_e_boolean_t *is_partial_approval );

/**
 * \brief Set if partial approval shall be supported. 
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] partial_approval Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_partial_approval(
	ta_object_t settings,
	ta_e_boolean_t partial_approval );



/**
 * \brief Timeout in seconds the terminal waits in WaitForProceed state
 *        for an additional function until an error is returned. 
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] proceed_timeout Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em proceed_timeout.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em proceed_timeout is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_proceed_timeout(
	ta_object_t settings,
	int *proceed_timeout );

/**
 * \brief Set timeout in seconds the terminal waits in WaitForProceed state
 *        for an additional function until an error is returned. 
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] proceed_timeout Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em proceed_timeout is less than 0.
 */
extern ta_e_result_code_t ta_terminal_settings_set_proceed_timeout(
	ta_object_t settings,
	int proceed_timeout );



/**
 * \brief Allow card to be inserted before activation. 
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] is_allow_closed_card_insert Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em is_allow_closed_card_insert.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em is_allow_closed_card_insert is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_is_allow_closed_card_insert(
	ta_object_t settings,
	ta_e_boolean_t *is_allow_closed_card_insert );

/**
 * \brief Set allow card to be inserted before activation.  
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] allow_closed_card_insert Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_allow_closed_card_insert(
	ta_object_t settings,
	ta_e_boolean_t allow_closed_card_insert );



/**
 * \brief Tip is allowed for purchase transactions.
 * 
 * This parameter is only used if gastro guide is enabled.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] is_tip_allowed Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em is_tip_allowed.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em is_tip_allowed is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_is_tip_allowed(
	ta_object_t settings,
	ta_e_boolean_t *is_tip_allowed );

/**
 * \brief Set tip is allowed for purchase transactions.
 * 
 * This parameter is only used if gastro guide is enabled. 
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] tip_allowed Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_tip_allowed(
	ta_object_t settings,
	ta_e_boolean_t tip_allowed );



/**
 * \brief Enable fast notification mode.
 * 
 * This parameter is only used if austrian use cases guide is enabled.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] is_fast_ntf_mode Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em is_fast_ntf_mode.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em is_fast_ntf_mode is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_is_fast_ntf_mode(
	ta_object_t settings,
	ta_e_boolean_t *is_fast_ntf_mode );

/**
 * \brief Set enable fast notification mode.
 * 
 * This parameter is only used if austrian use cases guide is enabled.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] fast_ntf_mode Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_fast_ntf_mode(
	ta_object_t settings,
	ta_e_boolean_t fast_ntf_mode );



/**
 * \brief Timeout in seconds the terminal displays the loyalty QR code after a "StartCheckout" call
 *        before returning to its "Idle" screen. Numeric number that specifies the QRCTimeout in
 *        seconds.
 * 
 * This parameter is only used if value added services guide is enabled.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] timeout Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em timeout.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em timeout is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_qrctimeout(
	ta_object_t settings,
	int *timeout );

/**
 * \brief Timeout in seconds the terminal displays the loyalty QR code after a "StartCheckout" call
 *        before returning to its "Idle" screen. Numeric number that specifies the QRCTimeout in
 *        seconds.
 * 
 * This parameter is only used if value added services guide is enabled.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] timeout Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_qrctimeout(
	ta_object_t settings,
	int timeout );



/**
 * \brief This timeout indicates how long a terminal shall wait in seconds for an
 *        AmtAdjustment notification from the ECR in case of a late-checkin.
 * 
 * This parameter is only used if value added services guide is enabled.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] timeout Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em is_fast_ntf_mode.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em is_fast_ntf_mode is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_late_checkin_timeout(
	ta_object_t settings,
	int *timeout );

/**
 * \brief This timeout indicates how long a terminal shall wait in seconds for an
 *        AmtAdjustment notification from the ECR in case of a late-checkin.
 * 
 * This parameter is only used if value added services guide is enabled.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] timeout Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_late_checkin_timeout(
	ta_object_t settings,
	int timeout );



/**
 * \brief Number of send request repetitions or 0 to disable.
 * 
 * Default is 0. Affects these functions:
 * - Commit
 * - Rollback
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] request_repetition Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em request_repetition.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em request_repetition is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_request_repetition(
	ta_object_t settings,
	int *request_repetition );

/**
 * \brief Set number of send request repetitions or 0 to disable.
 * 
 * Default is 0. Affects these functions:
 * - Commit
 * - Rollback
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] request_repetition Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em request_repetition is less than 0.
 */
extern ta_e_result_code_t ta_terminal_settings_set_request_repetition(
	ta_object_t settings,
	int request_repetition );



/**
 * \brief Keep-Alive handling is enabled.
 * 
 * Default is true.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] is_enabled_keep_alive Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em is_enabled_keep_alive.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em is_enabled_keep_alive is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_is_enabled_keep_alive(
	ta_object_t settings,
	ta_e_boolean_t *is_enabled_keep_alive );

/**
 * \brief Set Keep-Alive handling is enabled.
 * 
 * Default is true.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] enabled_keep_alive Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em enabled_keep_alive is less than 0.
 */
extern ta_e_result_code_t ta_terminal_settings_set_enabled_keep_alive(
	ta_object_t settings,
	ta_e_boolean_t enabled_keep_alive );



/**
 * \brief Enable persistent state if supported.
 * 
 * Default is false.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] persistent_state Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em persistent_state.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em persistent_state is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_persistent_state(
	ta_object_t settings,
	ta_e_boolean_t *persistent_state );

/**
 * \brief Set Enable persistent state if supported.
 * 
 * Default is false.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] persistent_state Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em persistent_state is less than 0.
 */
extern ta_e_result_code_t ta_terminal_settings_set_persistent_state(
	ta_object_t settings,
	ta_e_boolean_t persistent_state );



/**
 * \brief Returns the timeout for terminal wake-up operations.
 *
 * Wake up is only possible on terminals that support wake-up via ECR interface.
 * The wake-up process is transparent to the user and is triggered by calling a
 * function that needs the terminal.
 *
 * Default timeout is 20s.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] wakeup_timeout Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em wakeup_timeout.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em wakeup_timeout is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_wakeup_timeout(
	ta_object_t settings,
	int *wakeup_timeout );

/**
 * \brief Sets the timeout for terminal wake-up operations.
 *
 * Wake up is only possible on terminals that support wake-up via ECR interface.
 * The wake-up process is transparent to the user and is triggered by calling a
 * function that needs the terminal.
 *
 * Default timeout is 20s.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] wakeup_timeout Value to set.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em wakeup_timeout is less than 0.
 */
extern ta_e_result_code_t ta_terminal_settings_set_wakeup_timeout(
	ta_object_t settings,
	int wakeup_timeout );



/**
 * \brief Saferpay: Terminal Id.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] terminal_id Pointer to variable to write object instance to. Object instance
 *                         is of type [string](\ref string.h) and is not retained. Object instance is
 *                         \em ta_object_invalid if value is not set in \em settings.
 * 
 * \retval ta_c_rc_ok Object instance written to \em terminal_id.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_get_saferpay_terminal_id(
	ta_object_t settings,
	ta_object_t *terminal_id );

/**
 * \brief Set saferpay: Terminal Id.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] terminal_id Object instance to set.Object instance can be \em ta_object_invalid
 *                        to clear the value in \em settings. If object instance is not
 *                        ta_object_invalid is has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em terminal_id is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em terminal_id is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_saferpay_terminal_id(
	ta_object_t settings,
	ta_object_t terminal_id );



/**
 * \brief Saferpay: Base64 encoded user name + password.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] credentials Pointer to variable to write object instance to. Object instance
 *                         is of type [string](\ref string.h) and is not retained. Object instance is
 *                         \em ta_object_invalid if value is not set in \em settings.
 * 
 * \retval ta_c_rc_ok Object instance written to \em credentials.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_get_saferpay_credentials(
	ta_object_t settings,
	ta_object_t *credentials );

/**
 * \brief Saferpay: Base64 encoded user name + password.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] credentials Object instance to set.Object instance can be \em ta_object_invalid
 *                        to clear the value in \em settings. If object instance is not
 *                        ta_object_invalid is has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em credentials is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em credentials is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_saferpay_credentials(
	ta_object_t settings,
	ta_object_t credentials );



/**
 * \brief Saferpay: Customer ID.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] customer_id Pointer to variable to write object instance to. Object instance
 *                         is of type [string](\ref string.h) and is not retained. Object instance is
 *                         \em ta_object_invalid if value is not set in \em settings.
 * 
 * \retval ta_c_rc_ok Object instance written to \em customer_id.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_get_saferpay_customer_id(
	ta_object_t settings,
	ta_object_t *customer_id );

/**
 * \brief Saferpay: Customer ID.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] customer_id Object instance to set.Object instance can be \em ta_object_invalid
 *                        to clear the value in \em settings. If object instance is not
 *                        ta_object_invalid is has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em customer_id is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em customer_id is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_saferpay_customer_id(
	ta_object_t settings,
	ta_object_t customer_id );



/**
 * \brief Saferpay: Base URL.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] base_url Pointer to variable to write object instance to. Object instance
 *                      is of type [string](\ref string.h) and is not retained. Object instance is
 *                      \em ta_object_invalid if value is not set in \em settings.
 * 
 * \retval ta_c_rc_ok Object instance written to \em base_url.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_get_saferpay_base_url(
	ta_object_t settings,
	ta_object_t *base_url );

/**
 * \brief Saferpay: Base URL.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] base_url Object instance to set.Object instance can be \em ta_object_invalid
 *                     to clear the value in \em settings. If object instance is not
 *                     ta_object_invalid is has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em base_url is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em base_url is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_saferpay_base_url(
	ta_object_t settings,
	ta_object_t base_url );



/**
 * \brief Prefer OmniChannel for these functions.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] trx_types Pointer to variable to write value to. OR combination of values
 *                       from \em ta_e_transaction_type_t.
 * 
 * \retval ta_c_rc_ok Object instance written to \em trx_types.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em trx_types is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_prefer_omni_channel(
	ta_object_t settings,
	int *trx_types );

/**
 * \brief Prefer OmniChannel for these functions.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] trx_types Value to set. OR combination of values from \em ta_e_transaction_type_t.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_prefer_omni_channel(
	ta_object_t settings,
	int trx_types );



/**
 * \brief Omnichannel: Key for API access.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] api_key Pointer to variable to write object instance to. Object instance
 *                     is of type [string](\ref string.h) and is not retained. Object instance is
 *                     \em ta_object_invalid if value is not set in \em settings.
 * 
 * \retval ta_c_rc_ok Object instance written to \em api_key.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_get_omnichannel_api_key(
	ta_object_t settings,
	ta_object_t *api_key );

/**
 * \brief Omnichannel: Key for API access.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] api_key Object instance to set.Object instance can be \em ta_object_invalid
 *                    to clear the value in \em settings. If object instance is not
 *                    ta_object_invalid is has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em api_key is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em api_key is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_omnichannel_api_key(
	ta_object_t settings,
	ta_object_t api_key );



/**
 * \brief Omnichannel: Secret key for API access.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] api_secret Pointer to variable to write object instance to. Object instance
 *                        is of type [string](\ref string.h) and is not retained. Object instance is
 *                        \em ta_object_invalid if value is not set in \em settings.
 * 
 * \retval ta_c_rc_ok Object instance written to \em api_secret.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_get_omnichannel_api_secret(
	ta_object_t settings,
	ta_object_t *api_secret );

/**
 * \brief Omnichannel: Secret key for API access.
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] api_secret Object instance to set.Object instance can be \em ta_object_invalid
 *                       to clear the value in \em settings. If object instance is not
 *                       ta_object_invalid is has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em api_secret is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em api_secret is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_omnichannel_api_secret(
	ta_object_t settings,
	ta_object_t api_secret );



/**
 * \brief Omnichannel: Host-URL (for example Ogone's Direct API URL).
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] host_url Pointer to variable to write object instance to. Object instance
 *                      is of type [string](\ref string.h) and is not retained. Object instance is
 *                      \em ta_object_invalid if value is not set in \em settings.
 * 
 * \retval ta_c_rc_ok Object instance written to \em host_url.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_get_omnichannel_host_url(
	ta_object_t settings,
	ta_object_t *host_url );

/**
 * \brief Omnichannel: Host-URL (for example Ogone's Direct API URL).
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] host_url Object instance to set.Object instance can be \em ta_object_invalid
 *                     to clear the value in \em settings. If object instance is not
 *                     ta_object_invalid is has to be of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em host_url is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em host_url is not \em ta_object_invalid and
 *                                  is not of type [string](\ref string.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_omnichannel_host_url(
	ta_object_t settings,
	ta_object_t host_url );



/**
 * \brief Omnichannel: Timeout of Omnichannel host communication (in seconds).
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[out] host_timeout Pointer to variable to write value to. OR combination of values
 *                          from \em ta_e_transaction_type_t.
 * 
 * \retval ta_c_rc_ok Object instance written to \em host_timeout.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 * \retval ta_c_rc_invalid_argument \em host_timeout is \em null-pointer.
 */
extern ta_e_result_code_t ta_terminal_settings_get_omnichannel_host_timeout(
	ta_object_t settings,
	int *host_timeout );

/**
 * \brief Omnichannel: Timeout of Omnichannel host communication (in seconds).
 * 
 * \param[in] settings Object instance of type [terminal_settings](\ref terminal_settings.h).
 * \param[in] host_timeout Value to set. OR combination of values from \em ta_e_transaction_type_t.
 * 
 * \retval ta_c_rc_ok Value assigned to \em settings.
 * \retval ta_c_rc_invalid_argument \em settings is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em settings is not of type [terminal_settings](\ref terminal_settings.h).
 */
extern ta_e_result_code_t ta_terminal_settings_set_omnichannel_host_timeout(
	ta_object_t settings,
	int host_timeout );


#ifdef __cplusplus
}
#endif

#endif
