/**
 * \file
 * \brief Merchant option.
 * \details Object type \em merchant_option.
 */

#ifndef TA_MERCHANT_OPTION_H
#define TA_MERCHANT_OPTION_H

#include "common/object.h"
#include "common/boolean.h"
#include "constants/merchant_option_type.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create object of type [merchant_option](\ref merchant_option.h).
 * 
 * \param[out] merchant_option Pointer to variable to write created object instance to.
 *                             Created object instance is retained.
 * \param[in] type Merchant option type.
 * \param[in] value Option value of type [string](\ref string.h).
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em merchant_option.
 * \retval ta_c_rc_invalid_argument \em merchant_option is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em type has invalid value.
 * \retval ta_c_rc_invalid_argument \em value is \em ta_object_invalid.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_merchant_option_create(
	ta_object_t *merchant_option,
	ta_e_merchant_option_type_t type,
	ta_object_t value );


/**
 * \brief Type of merchant option.
 * 
 * \param[in] merchant_option Object instance of type [merchant_option](\ref merchant_option.h).
 * \param[out] type Pointer to variable to write value to. Value is \em ta_c_mot_undefined
 *                  if value is not set in \em merchant_option.
 * 
 * \retval ta_c_rc_ok Object instance written to \em type.
 * \retval ta_c_rc_invalid_argument \em merchant_option is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em merchant_option is not of type [merchant_option](\ref merchant_option.h).
 * \retval ta_c_rc_invalid_argument \em type is \em null-pointer.
 */
extern ta_e_result_code_t ta_merchant_option_get_type(
	ta_object_t merchant_option,
	ta_e_merchant_option_type_t *type );

/**
 * \brief Option value.
 * 
 * \param[in] merchant_option Object instance of type [merchant_option](\ref merchant_option.h).
 * \param[out] value Pointer to variable to write object instance to. Object instance is
 *                   of type [string](\ref string.h) and is not retained. Object instance is
 *                   \em ta_object_invalid if value is not set in \em merchant_option.
 * 
 * \retval ta_c_rc_ok Object instance written to \em value.
 * \retval ta_c_rc_invalid_argument \em merchant_option is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em merchant_option is not of type [merchant_option](\ref merchant_option.h).
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 */
extern ta_e_result_code_t ta_merchant_option_get_value(
	ta_object_t merchant_option,
	ta_object_t *value );


#ifdef __cplusplus
}
#endif

#endif
