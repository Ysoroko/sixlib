/**
 * \file
 * \brief Contains information about a counter for a brand.
 * \details Object type \em counter.
 */

#ifndef TA_COUNTER_H
#define TA_COUNTER_H

#include "common/object.h"
#include "common/integer.h"
#include "constants/card_product_type.h"
#include "constants/payment_protocol.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Name of brand the counter contains information for.
 * 
 * \param[in] counter Object instance of type [counter](\ref counter.h).
 * \param[out] brand_name Pointer to variable to write object instance to. Object
 *                        instance is of type [string](\ref string.h) and is not retained.
 * 
 * \retval ta_c_rc_ok Object instance written to \em brand_name.
 * \retval ta_c_rc_invalid_argument \em counter is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em counter is not of type [counter](\ref counter.h).
 * \retval ta_c_rc_invalid_argument \em brand_name is \em null-pointer.
 */
extern ta_e_result_code_t ta_counter_get_brand_name(
	ta_object_t counter,
	ta_object_t* brand_name );

/**
 * \brief Payment protocol linked to the brand.
 * 
 * \param[in] counter Object instance of type [counter](\ref counter.h).
 * \param[out] payment_protocol Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em payment_protocol.
 * \retval ta_c_rc_invalid_argument \em counter is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em counter is not of type [counter](\ref counter.h).
 * \retval ta_c_rc_invalid_argument \em payment_protocol is \em null-pointer.
 */
extern ta_e_result_code_t ta_counter_get_payment_protocol(
	ta_object_t counter,
	ta_e_payment_protocol_t* payment_protocol );

/**
 * \brief Card product type or ta_c_cpt_undefined.
 * 
 * \param[in] counter Object instance of type [counter](\ref counter.h).
 * \param[out] card_product_type Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em card_product_type.
 * \retval ta_c_rc_invalid_argument \em counter is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em counter is not of type [counter](\ref counter.h).
 * \retval ta_c_rc_invalid_argument \em card_product_type is \em null-pointer.
 */
extern ta_e_result_code_t ta_counter_get_card_product_type(
	ta_object_t counter,
	ta_e_card_product_type_t* card_product_type );

/**
 * \brief Acquirer identifier. Uniquely identifies the acquirer.
 * 
 * \param[in] counter Object instance of type [counter](\ref counter.h).
 * \param[out] acq_id Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em acq_id.
 * \retval ta_c_rc_invalid_argument \em counter is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em counter is not of type [counter](\ref counter.h).
 * \retval ta_c_rc_invalid_argument \em acq_id is \em null-pointer.
 */
extern ta_e_result_code_t ta_counter_get_acq_id(
	ta_object_t counter,
	int64_t* acq_id );

/**
 * \brief Counter number of transactions.
 * 
 * \param[in] counter Object instance of type [counter](\ref counter.h).
 * \param[out] count Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em count.
 * \retval ta_c_rc_invalid_argument \em counter is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em counter is not of type [counter](\ref counter.h).
 * \retval ta_c_rc_invalid_argument \em count is \em null-pointer.
 */
extern ta_e_result_code_t ta_counter_get_count(
	ta_object_t counter,
	int* count );

/**
 * \brief Number of DCC related transactions.
 * 
 * \param[in] counter Object instance of type [counter](\ref counter.h).
 * \param[out] count_dcc Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em count_dcc.
 * \retval ta_c_rc_invalid_argument \em counter is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em counter is not of type [counter](\ref counter.h).
 * \retval ta_c_rc_invalid_argument \em count_dcc is \em null-pointer.
 */
extern ta_e_result_code_t ta_counter_get_count_dcc(
	ta_object_t counter,
	int* count_dcc );

/**
 * \brief Number of foreign currency related transactions.
 * 
 * \param[in] counter Object instance of type [counter](\ref counter.h).
 * \param[out] count_foreign Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em count_foreign.
 * \retval ta_c_rc_invalid_argument \em counter is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em counter is not of type [counter](\ref counter.h).
 * \retval ta_c_rc_invalid_argument \em count_foreign is \em null-pointer.
 */
extern ta_e_result_code_t ta_counter_get_count_foreign(
	ta_object_t counter,
	int* count_foreign );

/**
 * \brief Number of totals to break down the counter amount in more detail.
 * 
 * \param[in] counter Object instance of type [counter](\ref counter.h).
 * \param[out] totals Pointer to variable to write object instance to. Object instance
 *                    is of type [list](\ref list.h) and is not retained. The list contains elements
 *                    of type [total](\ref total.h).
 * 
 * \retval ta_c_rc_ok Object instance written to \em totals.
 * \retval ta_c_rc_invalid_argument \em counter is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em counter is not of type [counter](\ref counter.h).
 * \retval ta_c_rc_invalid_argument \em totals is \em null-pointer.
 */
extern ta_e_result_code_t ta_counter_get_totals(
	ta_object_t counter,
	ta_object_t* totals );


#ifdef __cplusplus
}
#endif

#endif
