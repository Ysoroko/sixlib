/**
 * \file
 * \brief Print option.
 * \details Object type \em print_option.
 */

#ifndef TA_PRINT_OPTION_H
#define TA_PRINT_OPTION_H

#include "common/object.h"
#include "common/boolean.h"
#include "constants/recipient.h"
#include "constants/print_format.h"
#include "constants/print_flag.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Create print option.
 * 
 * \param[out] print_option Pointer to variable to write created object instance to.
 *                          Created object instance is retained.
 * \param[in] recipient Recipient.
 * \param[in] print_format Print format.
 * \param[in] print_width Print width in characters.
 * \param[in] print_flags Print flags using OR combined values from \em ta_e_print_flag_t.
 * 
 * \retval ta_c_rc_ok Object instance has been created and written to \em print_option.
 * \retval ta_c_rc_invalid_argument \em print_option is \em null-pointer.
 * \retval ta_c_rc_invalid_argument \em print_width is less than 1.
 * \retval ta_c_rc_out_of_memory Failed allocating memory.
 */
extern ta_e_result_code_t ta_print_option_create(
	ta_object_t *print_option,
	ta_e_recipient_t recipient,
	ta_e_print_format_t print_format,
	int print_width,
	int print_flags );


/**
 * \brief Target of the print option. Can be Merchant or Cardholder.
 * 
 * \param[in] print_option Object instance of type [print_option](\ref print_option.h).
 * \param[out] recipient Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em recipient.
 * \retval ta_c_rc_invalid_argument \em print_option is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em print_option is not of type [print_option](\ref print_option.h).
 * \retval ta_c_rc_invalid_argument \em recipient is \em null-pointer.
 */
extern ta_e_result_code_t ta_print_option_get_recipient(
	ta_object_t print_option,
	ta_e_recipient_t *recipient );

/**
 * \brief Specifies the print format.
 * 
 * \param[in] print_option Object instance of type [print_option](\ref print_option.h).
 * \param[out] print_format Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em print_format.
 * \retval ta_c_rc_invalid_argument \em print_option is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em print_option is not of type [print_option](\ref print_option.h).
 * \retval ta_c_rc_invalid_argument \em print_format is \em null-pointer.
 */
extern ta_e_result_code_t ta_print_option_get_print_format(
	ta_object_t print_option,
	ta_e_print_format_t *print_format );

/**
 * \brief Specifies the print width of the receipt (default = 40).
 * 
 * \param[in] print_option Object instance of type [print_option](\ref print_option.h).
 * \param[out] print_width Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em print_width.
 * \retval ta_c_rc_invalid_argument \em print_option is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em print_option is not of type [print_option](\ref print_option.h).
 * \retval ta_c_rc_invalid_argument \em print_width is \em null-pointer.
 */
extern ta_e_result_code_t ta_print_option_get_print_width(
	ta_object_t print_option,
	int *print_width );

/**
 * \brief Print flags as OR combined values from \em ta_e_print_flag_t.
 * 
 * \param[in] print_option Object instance of type [print_option](\ref print_option.h).
 * \param[out] print_flags Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em print_flags.
 * \retval ta_c_rc_invalid_argument \em print_option is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em print_option is not of type [print_option](\ref print_option.h).
 * \retval ta_c_rc_invalid_argument \em print_flags is \em null-pointer.
 */
extern ta_e_result_code_t ta_print_option_get_print_flags(
	ta_object_t print_option,
	int *print_flags );


#ifdef __cplusplus
}
#endif

#endif
