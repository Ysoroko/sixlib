/**
 * \file
 * \brief Tim error.
 * \details Object type \em tim_error.
 */

#ifndef TA_TIM_ERROR_H
#define TA_TIM_ERROR_H

#include "common/object.h"
#include "common/boolean.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Result code.
 * 
 * \param[in] response Object instance of type [tim_error](\ref tim_error.h).
 * \param[out] result_code Pointer to variable to write result code to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em error_message.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [tim_error](\ref tim_error.h).
 * \retval ta_c_rc_invalid_argument \em result_code is \em null-pointer.
 */
extern ta_e_result_code_t ta_tim_error_get_result_code(
	ta_object_t response,
	ta_e_result_code_t *result_code );

/**
 * \brief Returns the error message as transmitted from the terminal.
 * 
 * The message language depends on the terminal but will generally be in English.
 *
 * An empty string is returned if the terminal does not send a message.
 * 
 * \param[in] response Object instance of type [tim_error](\ref tim_error.h).
 * \param[out] error_message Pointer to variable to write object instance to. Object instance
 *                           is of type [string](\ref string.h) and is not retained. Object instance
 *                           is \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em error_message.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [tim_error](\ref tim_error.h).
 * \retval ta_c_rc_invalid_argument \em error_message is \em null-pointer.
 */
extern ta_e_result_code_t ta_tim_error_get_error_message(
	ta_object_t response,
	ta_object_t *error_message );

/**
 * \brief Returns the localised error message in human readable form derived from the
 *        error code sent by the terminal.
 * 
 * The message will be in the merchant language of the terminal provided
 * systemInformation() has been executed (English otherwise).
 * 
 * \note In contrary to \em ta_tim_error_get_error_message the string written to
 *       \em error_message "is" retained. This is due to this method generating
 *       an error message if no appropriate error message is present.
 * 
 * \param[in] response Object instance of type [tim_error](\ref tim_error.h).
 * \param[out] error_message Pointer to variable to write object instance to. Object instance
 *                           is of type [string](\ref string.h) and is retained. Object instance
 *                           is \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em error_message.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [tim_error](\ref tim_error.h).
 * \retval ta_c_rc_invalid_argument \em error_message is \em null-pointer.
 */
extern ta_e_result_code_t ta_tim_error_get_localized_message(
	ta_object_t response,
	ta_object_t *localized_message );

/**
 * \brief Returns the localised error message in human readable form derived from the
 *        error code sent by the terminal.
 *
 * The message will be in the language supplied in the parameter.
 *
 * Valid language strings are currently: "en","de","de-AT","de-CH","fr","fr-BE",
 * "fr-CH","it","bg","hr","cs","nl","nl-BE","nl-NL","el","hu","lt","pl","pt",
 * "ro","sk","sl","es","sv","fi","no","da"
 * 
 * "de" defaults to "de-CH"
 * "fr" defaults to "fr-CH"
 * "nl" defaults to "nl-BE"
 * 
 * \note In contrary to \em ta_tim_error_get_error_message the string written to
 *       \em error_message "is" retained. This is due to this method generating
 *       an error message if no appropriate error message is present.
 * 
 * \param[in] response Object instance of type [tim_error](\ref tim_error.h).
 * \param[in] language Language.
 * \param[out] error_message Pointer to variable to write object instance to. Object instance
 *                           is of type [string](\ref string.h) and is retained. Object instance
 *                           is \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em error_message.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [tim_error](\ref tim_error.h).
 * \retval ta_c_rc_invalid_argument \em language is \em 0.
 * \retval ta_c_rc_invalid_argument \em error_message is \em null-pointer.
 */
extern ta_e_result_code_t ta_tim_error_get_localized_message2(
	ta_object_t response,
	const char *language,
	ta_object_t *localized_message );

/**
 * \brief Native error if present or \em ta_object_invalid if not present.
 * 
 * \param[in] response Object instance of type [tim_error](\ref tim_error.h).
 * \param[out] native_error Pointer to variable to write object instance to. Object instance
 *                          is of type [native_error](\ref native_error.h) and is not retained.
 *                          Object instance is \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em native_error.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [tim_error](\ref tim_error.h).
 * \retval ta_c_rc_invalid_argument \em native_error is \em null-pointer.
 */
extern ta_e_result_code_t ta_tim_error_get_native_error(
	ta_object_t response,
	ta_object_t *native_error );

/**
 * \brief Payment protocol specific information.
 * 
 * Mandatory if any information is given by the underlying payment protocol.
 * 
 * \param[in] response Object instance of type [tim_error](\ref tim_error.h).
 * \param[out] ppinfo Pointer to variable to write object instance to. Object instance
 *                    is of type [ppinfo](\ref ppinfo.h) and is not retained.
 *                    Object instance is \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em ppinfo.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [tim_error](\ref tim_error.h).
 * \retval ta_c_rc_invalid_argument \em ppinfo is \em null-pointer.
 */
extern ta_e_result_code_t ta_tim_error_get_ppinfo(
	ta_object_t response,
	ta_object_t *ppinfo );

/**
 * \brief Additional error information mapping item text to item text code.
 * 
 * Mandatory if any additional error information available. 
 * 
 * \param[in] response Object instance of type [tim_error](\ref tim_error.h).
 * \param[out] additional_error_info Pointer to variable to write object instance to.
 *                                   Object instance is of type [map](\ref map.h) and is not
 *                                   retained. Keys and values are of type [string](\ref string.h)
 *                                   and are retained by the map. Object instance is
 *                                   \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em additional_error_info.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [tim_error](\ref tim_error.h).
 * \retval ta_c_rc_invalid_argument \em additional_error_info is \em null-pointer.
 */
extern ta_e_result_code_t ta_tim_error_get_additional_error_info(
	ta_object_t response,
	ta_object_t *additional_error_info );

/**
 * \brief Print data or \em ta_object_invalid if absent.
 * 
 * \param[in] response Object instance of type [tim_error](\ref tim_error.h).
 * \param[out] print_data Pointer to variable to write object instance to. Object instance
 *                        is of type [print_data](\ref print_data.h) and is not retained.
 *                        Object instance is \em ta_object_invalid if value is not set in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em print_data.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [tim_error](\ref tim_error.h).
 * \retval ta_c_rc_invalid_argument \em print_data is \em null-pointer.
 */
extern ta_e_result_code_t ta_tim_error_get_print_data(
	ta_object_t response,
	ta_object_t *print_data );

/**
 * \brief Rejected basket as modified by host or null if absent.
 * 
 * Used for ta_c_guide_petrol only.
 * 
 * \param[in] response Object instance of type [tim_error](\ref tim_error.h).
 * \param[out] rejected_basket Pointer to variable to write object instance to. Object instance
 *                             is of type [basket](\ref basket.h) and is not retained.
 *                             Object instance is \em ta_object_invalid if value is not set
 *                             in \em response.
 * 
 * \retval ta_c_rc_ok Object instance written to \em rejected_basket.
 * \retval ta_c_rc_invalid_argument \em response is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em response is not of type [tim_error](\ref tim_error.h).
 * \retval ta_c_rc_invalid_argument \em rejected_basket is \em null-pointer.
 */
extern ta_e_result_code_t ta_tim_error_get_rejected_basket(
	ta_object_t response,
	ta_object_t *rejected_basket );


#ifdef __cplusplus
}
#endif

#endif
