/**
 * \file
 * \brief Loalty discount amount.
 * \details Object type \em loyalty_discount.
 */

#ifndef TA_AMOUNT_DISCOUNT_H
#define TA_AMOUNT_DISCOUNT_H

#include <stdint.h>

#include "common/object.h"
#include "constants/currency.h"


#ifdef __cplusplus
extern "C" {
#endif

/**
 * \brief Discount amount in minor units.
 * 
 * \param[in] amount Object instance of type [loyalty_discount](\ref loyalty_discount.h).
 * \param[out] value Pointer to variable to write value to. Use
 *                   \em ta_loyalty_discount_get_exponent to get the used exponent. This can
 *                   be a different exponent than the one defined by the used currency.
 * 
 * \retval ta_c_rc_ok Value written to \em value.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [loyalty_discount](\ref loyalty_discount.h).
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_discount_get_value(
	ta_object_t amount,
	int64_t *value );

/**
 * \brief Discount amount in major units as double precision floating point value.
 * 
 * \note Double precision floating point values can not provide the same level of numerical
 *       accuracy as int64_t. It is recommended to use the integer based methods.
 * 
 * \param[in] amount Object instance of type [loyalty_discount](\ref loyalty_discount.h).
 * \param[out] value Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Value written to \em value.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [loyalty_discount](\ref loyalty_discount.h).
 * \retval ta_c_rc_invalid_argument \em value is \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_discount_get_decimal_value(
	ta_object_t amount,
	double *value );

/**
 * \brief Discount currency.
 * 
 * \param[in] amount Object instance of type [loyalty_discount](\ref loyalty_discount.h).
 * \param[out] currency Pointer to variable to write currency to.
 * 
 * \retval ta_c_rc_ok Value written to \em currency.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [loyalty_discount](\ref loyalty_discount.h).
 * \retval ta_c_rc_invalid_argument \em currency is \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_discount_get_currency(
	ta_object_t amount,
	ta_e_currency_t *currency );

/**
 * \brief Discount exponent.
 * 
 * \param[in] amount Object instance of type [loyalty_discount](\ref loyalty_discount.h).
 * \param[out] exponent Pointer to variable to write exponent to.
 * 
 * \retval ta_c_rc_ok Value written to \em exponent.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [loyalty_discount](\ref loyalty_discount.h).
 * \retval ta_c_rc_invalid_argument \em exponent is \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_discount_get_exponent(
	ta_object_t amount,
	int *exponent );

/**
 * \brief Discount identifier.
 * 
 * \param[in] amount Object instance of type [loyalty_discount](\ref loyalty_discount.h).
 * \param[out] identifier Pointer to variable to write object instance to. Object instance
 *                        is of type [string](\ref string.h) and is not retained. Object instance is
 *                        \em ta_object_invalid if identifier is not set in \em loyalty_discount.
 * 
 * \retval ta_c_rc_ok Object instance written to \em identifier.
 * \retval ta_c_rc_invalid_argument \em amount is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em amount is not of type [loyalty_discount](\ref loyalty_discount.h).
 * \retval ta_c_rc_invalid_argument \em identifier is \em null-pointer.
 */
extern ta_e_result_code_t ta_loyalty_discount_get_discount_description(
	ta_object_t amount,
	ta_object_t *identifier );

#ifdef __cplusplus
}
#endif

#endif
