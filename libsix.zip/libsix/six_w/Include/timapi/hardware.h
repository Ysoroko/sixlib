/**
 * \file
 * \brief Contains information about a piece of hardware in the terminal or devices attached to it.
 * \details Object type \em hardware.
 */

#ifndef TA_HARDWARE_H
#define TA_HARDWARE_H

#include "common/object.h"
#include "constants/hardware_type.h"
#include "constants/security_status.h"


#ifdef __cplusplus
extern "C" {
#endif


/**
 * \brief Specifies the hardware.
 * 
 * \param[in] hardware Object instance of type [hardware](\ref hardware.h).
 * \param[out] hardware_type Pointer to variable to write value to.
 * 
 * \retval ta_c_rc_ok Object instance written to \em hardware_type.
 * \retval ta_c_rc_invalid_argument \em hardware is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em hardware is not of type [hardware](\ref hardware.h).
 * \retval ta_c_rc_invalid_argument \em hardware_type is \em null-pointer.
 */
extern ta_e_result_code_t ta_hardware_get_hardware_type(
	ta_object_t hardware,
	ta_e_hardware_type_t* hardware_type );

/**
 * \brief Serial number of the specified hardware.
 * 
 * \param[in] hardware Object instance of type [hardware](\ref hardware.h).
 * \param[out] serial_number Pointer to variable to write object instance to. Object
 *                           instance is of type [string](\ref string.h) and is not retained. Object
 *                           instance is \em ta_object_invalid if value is not set
 *                           in \em hardware.
 * 
 * \retval ta_c_rc_ok Object instance written to \em serial_number.
 * \retval ta_c_rc_invalid_argument \em hardware is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em hardware is not of type [hardware](\ref hardware.h).
 * \retval ta_c_rc_invalid_argument \em serial_number is \em null-pointer.
 */
extern ta_e_result_code_t ta_hardware_get_serial_number(
	ta_object_t hardware,
	ta_object_t* serial_number );

/**
 * \brief Production date of the specified hardware.
 * 
 * \param[in] hardware Object instance of type [hardware](\ref hardware.h).
 * \param[out] production_date Pointer to variable to write object instance to. Object
 *                             instance is of type [timedate](\ref timedate.h) and is not retained. Object
 *                             instance is \em ta_object_invalid if value is not set
 *                             in \em hardware.
 * 
 * \retval ta_c_rc_ok Object instance written to \em production_date.
 * \retval ta_c_rc_invalid_argument \em hardware is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em hardware is not of type [hardware](\ref hardware.h).
 * \retval ta_c_rc_invalid_argument \em production_date is \em null-pointer.
 */
extern ta_e_result_code_t ta_hardware_get_production_date(
	ta_object_t hardware,
	ta_object_t* production_date );

/**
 * \brief Product version of the specified hardware.
 * 
 * \param[in] hardware Object instance of type [hardware](\ref hardware.h).
 * \param[out] product_version Pointer to variable to write object instance to. Object
 *                             instance is of type [string](\ref string.h) and is not retained. Object
 *                             instance is \em ta_object_invalid if value is not set
 *                             in \em hardware.
 * 
 * \retval ta_c_rc_ok Object instance written to \em product_version.
 * \retval ta_c_rc_invalid_argument \em hardware is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em hardware is not of type [hardware](\ref hardware.h).
 * \retval ta_c_rc_invalid_argument \em product_version is \em null-pointer.
 */
extern ta_e_result_code_t ta_hardware_get_product_version(
	ta_object_t hardware,
	ta_object_t* product_version );

/**
 * \brief Firmware version of the specified hardware.
 * 
 * \param[in] hardware Object instance of type [hardware](\ref hardware.h).
 * \param[out] firmware_version Pointer to variable to write object instance to. Object
 *                              instance is of type [string](\ref string.h) and is not retained. Object
 *                              instance is \em ta_object_invalid if value is not set
 *                              in \em hardware.
 * 
 * \retval ta_c_rc_ok Object instance written to \em firmware_version.
 * \retval ta_c_rc_invalid_argument \em hardware is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em hardware is not of type [hardware](\ref hardware.h).
 * \retval ta_c_rc_invalid_argument \em firmware_version is \em null-pointer.
 */
extern ta_e_result_code_t ta_hardware_get_firmware_version(
	ta_object_t hardware,
	ta_object_t* firmware_version );

/**
 * \brief Security status of the specified hardware.
 * 
 * \param[in] hardware Object instance of type [hardware](\ref hardware.h).
 * \param[out] security_status Pointer to variable to write value to. value is
 *                             \em ta_c_ss_undefined if value is not set in \em hardware.
 * 
 * \retval ta_c_rc_ok Object instance written to \em security_status.
 * \retval ta_c_rc_invalid_argument \em hardware is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em hardware is not of type [hardware](\ref hardware.h).
 * \retval ta_c_rc_invalid_argument \em security_status is \em null-pointer.
 */
extern ta_e_result_code_t ta_hardware_get_security_status(
	ta_object_t hardware,
	ta_e_security_status_t* security_status );

/**
 * \brief Available if HardwareType is ContactReader or MagStripeReader.
 * 
 * \param[in] hardware Object instance of type [hardware](\ref hardware.h).
 * \param[out] last_cleaning_date Pointer to variable to write object instance to. Object
 *                                instance is of type [timedate](\ref timedate.h) and is not retained. Object
 *                                instance is \em ta_object_invalid if value is not set
 *                                in \em hardware.
 * 
 * \retval ta_c_rc_ok Object instance written to \em last_cleaning_date.
 * \retval ta_c_rc_invalid_argument \em hardware is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em hardware is not of type [hardware](\ref hardware.h).
 * \retval ta_c_rc_invalid_argument \em last_cleaning_date is \em null-pointer.
 */
extern ta_e_result_code_t ta_hardware_get_last_cleaning_date(
	ta_object_t hardware,
	ta_object_t* last_cleaning_date );

/**
 * \brief Imsi.
 * 
 * \param[in] hardware Object instance of type [hardware](\ref hardware.h).
 * \param[out] imsi Pointer to variable to write object instance to. Object
 *                  instance is of type [string](\ref string.h) and is not retained. Object
 *                  instance is \em ta_object_invalid if value is not set
 *                  in \em hardware.
 * 
 * \retval ta_c_rc_ok Object instance written to \em last_cleaning_date.
 * \retval ta_c_rc_invalid_argument \em hardware is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em hardware is not of type [hardware](\ref hardware.h).
 * \retval ta_c_rc_invalid_argument \em imsi is \em null-pointer.
 */
extern ta_e_result_code_t ta_hardware_get_imsi(
	ta_object_t hardware,
	ta_object_t* imsi );

/**
 * \brief Imei.
 * 
 * \param[in] hardware Object instance of type [hardware](\ref hardware.h).
 * \param[out] imei Pointer to variable to write object instance to. Object
 *                  instance is of type [string](\ref string.h) and is not retained. Object
 *                  instance is \em ta_object_invalid if value is not set
 *                  in \em hardware.
 * 
 * \retval ta_c_rc_ok Object instance written to \em last_cleaning_date.
 * \retval ta_c_rc_invalid_argument \em hardware is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em hardware is not of type [hardware](\ref hardware.h).
 * \retval ta_c_rc_invalid_argument \em imei is \em null-pointer.
 */
extern ta_e_result_code_t ta_hardware_get_imei(
	ta_object_t hardware,
	ta_object_t* imei );

/**
 * \brief Iccid.
 * 
 * \param[in] hardware Object instance of type [hardware](\ref hardware.h).
 * \param[out] iccid Pointer to variable to write object instance to. Object
 *                   instance is of type [string](\ref string.h) and is not retained. Object
 *                   instance is \em ta_object_invalid if value is not set
 *                   in \em hardware.
 * 
 * \retval ta_c_rc_ok Object instance written to \em last_cleaning_date.
 * \retval ta_c_rc_invalid_argument \em hardware is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em hardware is not of type [hardware](\ref hardware.h).
 * \retval ta_c_rc_invalid_argument \em iccid is \em null-pointer.
 */
extern ta_e_result_code_t ta_hardware_get_iccid(
	ta_object_t hardware,
	ta_object_t* iccid );

/**
 * \brief Hardware address.
 * 
 * \param[in] hardware Object instance of type [hardware](\ref hardware.h).
 * \param[out] hardware_address Pointer to variable to write object instance to. Object
 *                              instance is of type [string](\ref string.h) and is not retained. Object
 *                              instance is \em ta_object_invalid if value is not set
 *                              in \em hardware.
 * 
 * \retval ta_c_rc_ok Object instance written to \em last_cleaning_date.
 * \retval ta_c_rc_invalid_argument \em hardware is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em hardware is not of type [hardware](\ref hardware.h).
 * \retval ta_c_rc_invalid_argument \em hardware_address is \em null-pointer.
 */
extern ta_e_result_code_t ta_hardware_get_hardware_address(
	ta_object_t hardware,
	ta_object_t* hardware_address );

/**
 * \brief Hardware description.
 * 
 * \param[in] hardware Object instance of type [hardware](\ref hardware.h).
 * \param[out] hardware_description Pointer to variable to write object instance to. Object
 *                                  instance is of type [string](\ref string.h) and is not retained. Object
 *                                  instance is \em ta_object_invalid if value is not set
 *                                  in \em hardware.
 * 
 * \retval ta_c_rc_ok Object instance written to \em last_cleaning_date.
 * \retval ta_c_rc_invalid_argument \em hardware is \em ta_object_invalid.
 * \retval ta_c_rc_invalid_argument \em hardware is not of type [hardware](\ref hardware.h).
 * \retval ta_c_rc_invalid_argument \em hardware_description is \em null-pointer.
 */
extern ta_e_result_code_t ta_hardware_get_hardware_description(
	ta_object_t hardware,
	ta_object_t* hardware_description );


#ifdef __cplusplus
}
#endif

#endif
